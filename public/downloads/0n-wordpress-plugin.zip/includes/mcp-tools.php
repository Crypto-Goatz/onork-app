<?php
/**
 * Extended MCP Tool Registry
 * Required by 0ncore.php
 *
 * 31 additional tools for taxonomy, comments, menus, themes, plugins,
 * media, search, SEO, WooCommerce, and maintenance operations.
 *
 * @package 0nCore
 * @since 1.1.0
 */

if (!defined('ABSPATH')) exit;

/**
 * Return all extended MCP tool definitions.
 *
 * Each entry: description, inputSchema (JSON Schema), handler (callable name).
 *
 * @return array<string, array{description: string, inputSchema: array, handler: string}>
 */
function on_mcp_extended_tools() {
    $tools = [

        // ──────────────────────────────────────────────
        // TAXONOMY TOOLS
        // ──────────────────────────────────────────────

        'wp_list_taxonomies' => [
            'description' => 'List all registered taxonomies with labels and associated post types.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => new \stdClass(),
            ],
            'handler' => 'on_handle_list_taxonomies',
        ],

        'wp_list_terms' => [
            'description' => 'List terms in a taxonomy with optional search and pagination.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'taxonomy'  => ['type' => 'string', 'description' => 'Taxonomy slug (e.g. category, post_tag)'],
                    'per_page'  => ['type' => 'integer', 'description' => 'Number of terms to return', 'default' => 50],
                    'search'    => ['type' => 'string', 'description' => 'Search terms by name'],
                ],
                'required' => ['taxonomy'],
            ],
            'handler' => 'on_handle_list_terms',
        ],

        'wp_create_term' => [
            'description' => 'Create a new term in a taxonomy.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'taxonomy'    => ['type' => 'string', 'description' => 'Taxonomy slug'],
                    'name'        => ['type' => 'string', 'description' => 'Term name'],
                    'slug'        => ['type' => 'string', 'description' => 'Term slug (auto-generated if omitted)'],
                    'parent'      => ['type' => 'integer', 'description' => 'Parent term ID for hierarchical taxonomies'],
                    'description' => ['type' => 'string', 'description' => 'Term description'],
                ],
                'required' => ['taxonomy', 'name'],
            ],
            'handler' => 'on_handle_create_term',
        ],

        'wp_assign_terms' => [
            'description' => 'Assign terms to a post.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'post_id'  => ['type' => 'integer', 'description' => 'Post ID'],
                    'taxonomy' => ['type' => 'string', 'description' => 'Taxonomy slug'],
                    'term_ids' => ['type' => 'array', 'items' => ['type' => 'integer'], 'description' => 'Array of term IDs to assign'],
                ],
                'required' => ['post_id', 'taxonomy', 'term_ids'],
            ],
            'handler' => 'on_handle_assign_terms',
        ],

        // ──────────────────────────────────────────────
        // COMMENT TOOLS
        // ──────────────────────────────────────────────

        'wp_list_comments' => [
            'description' => 'List comments with optional filters for post and status.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'post_id'  => ['type' => 'integer', 'description' => 'Filter by post ID'],
                    'status'   => ['type' => 'string', 'description' => 'Comment status: approve, hold, spam, trash, all', 'default' => 'all'],
                    'per_page' => ['type' => 'integer', 'description' => 'Number of comments to return', 'default' => 50],
                ],
            ],
            'handler' => 'on_handle_list_comments',
        ],

        'wp_create_comment' => [
            'description' => 'Create a new comment on a post.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'post_id'      => ['type' => 'integer', 'description' => 'Post ID to comment on'],
                    'content'      => ['type' => 'string', 'description' => 'Comment content'],
                    'author_name'  => ['type' => 'string', 'description' => 'Comment author display name'],
                    'author_email' => ['type' => 'string', 'description' => 'Comment author email'],
                ],
                'required' => ['post_id', 'content', 'author_name', 'author_email'],
            ],
            'handler' => 'on_handle_create_comment',
        ],

        'wp_update_comment_status' => [
            'description' => 'Update a comment status (approve, spam, or trash).',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'comment_id' => ['type' => 'integer', 'description' => 'Comment ID'],
                    'status'     => ['type' => 'string', 'enum' => ['approve', 'spam', 'trash'], 'description' => 'New status'],
                ],
                'required' => ['comment_id', 'status'],
            ],
            'handler' => 'on_handle_update_comment_status',
        ],

        // ──────────────────────────────────────────────
        // MENU TOOLS
        // ──────────────────────────────────────────────

        'wp_list_menus' => [
            'description' => 'List all registered navigation menus and their locations.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => new \stdClass(),
            ],
            'handler' => 'on_handle_list_menus',
        ],

        'wp_get_menu_items' => [
            'description' => 'Get all items in a navigation menu.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'menu_id' => ['type' => 'integer', 'description' => 'Menu term ID'],
                ],
                'required' => ['menu_id'],
            ],
            'handler' => 'on_handle_get_menu_items',
        ],

        // ──────────────────────────────────────────────
        // THEME TOOLS
        // ──────────────────────────────────────────────

        'wp_list_themes' => [
            'description' => 'List all installed themes with name, version, status, and screenshot.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => new \stdClass(),
            ],
            'handler' => 'on_handle_list_themes',
        ],

        'wp_get_active_theme' => [
            'description' => 'Get detailed information about the currently active theme.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => new \stdClass(),
            ],
            'handler' => 'on_handle_get_active_theme',
        ],

        'wp_switch_theme' => [
            'description' => 'Switch the active theme.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'stylesheet' => ['type' => 'string', 'description' => 'Theme directory name (stylesheet slug)'],
                ],
                'required' => ['stylesheet'],
            ],
            'handler' => 'on_handle_switch_theme',
        ],

        // ──────────────────────────────────────────────
        // PLUGIN TOOLS
        // ──────────────────────────────────────────────

        'wp_list_plugins' => [
            'description' => 'List all installed plugins with name, version, active status, and description.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => new \stdClass(),
            ],
            'handler' => 'on_handle_list_plugins',
        ],

        'wp_activate_plugin' => [
            'description' => 'Activate an installed plugin.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'plugin' => ['type' => 'string', 'description' => 'Plugin file path relative to plugins dir (e.g. akismet/akismet.php)'],
                ],
                'required' => ['plugin'],
            ],
            'handler' => 'on_handle_activate_plugin',
        ],

        'wp_deactivate_plugin' => [
            'description' => 'Deactivate an active plugin.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'plugin' => ['type' => 'string', 'description' => 'Plugin file path relative to plugins dir (e.g. akismet/akismet.php)'],
                ],
                'required' => ['plugin'],
            ],
            'handler' => 'on_handle_deactivate_plugin',
        ],

        // ──────────────────────────────────────────────
        // MEDIA TOOLS
        // ──────────────────────────────────────────────

        'wp_list_media' => [
            'description' => 'List media library items with optional type filter and search.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'per_page'  => ['type' => 'integer', 'description' => 'Number of items to return', 'default' => 50],
                    'mime_type' => ['type' => 'string', 'description' => 'Filter by MIME type (e.g. image, image/jpeg, video)'],
                    'search'    => ['type' => 'string', 'description' => 'Search media by title'],
                ],
            ],
            'handler' => 'on_handle_list_media',
        ],

        'wp_delete_media' => [
            'description' => 'Delete a media item from the library.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'id'    => ['type' => 'integer', 'description' => 'Attachment ID'],
                    'force' => ['type' => 'boolean', 'description' => 'Skip trash and permanently delete', 'default' => false],
                ],
                'required' => ['id'],
            ],
            'handler' => 'on_handle_delete_media',
        ],

        // ──────────────────────────────────────────────
        // SEARCH TOOLS
        // ──────────────────────────────────────────────

        'wp_search' => [
            'description' => 'Global search across posts, pages, products, and custom post types.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'query'     => ['type' => 'string', 'description' => 'Search query'],
                    'post_type' => ['type' => 'string', 'description' => 'Post type to search (post, page, product, any). Default: any'],
                    'per_page'  => ['type' => 'integer', 'description' => 'Number of results', 'default' => 20],
                ],
                'required' => ['query'],
            ],
            'handler' => 'on_handle_search',
        ],

        'wp_search_replace' => [
            'description' => 'Search and replace text in the database. DANGEROUS — use dry_run first.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'search'  => ['type' => 'string', 'description' => 'String to search for'],
                    'replace' => ['type' => 'string', 'description' => 'Replacement string'],
                    'table'   => ['type' => 'string', 'description' => 'Limit to specific table (e.g. posts, postmeta, options). Default: posts'],
                    'dry_run' => ['type' => 'boolean', 'description' => 'Preview changes without applying', 'default' => true],
                ],
                'required' => ['search', 'replace'],
            ],
            'handler' => 'on_handle_search_replace',
        ],

        // ──────────────────────────────────────────────
        // SEO TOOLS
        // ──────────────────────────────────────────────

        'wp_get_meta' => [
            'description' => 'Get a specific post meta value.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'post_id' => ['type' => 'integer', 'description' => 'Post ID'],
                    'key'     => ['type' => 'string', 'description' => 'Meta key to retrieve'],
                ],
                'required' => ['post_id', 'key'],
            ],
            'handler' => 'on_handle_get_meta',
        ],

        'wp_update_meta' => [
            'description' => 'Update or create a post meta value.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'post_id' => ['type' => 'integer', 'description' => 'Post ID'],
                    'key'     => ['type' => 'string', 'description' => 'Meta key'],
                    'value'   => ['type' => 'string', 'description' => 'Meta value'],
                ],
                'required' => ['post_id', 'key', 'value'],
            ],
            'handler' => 'on_handle_update_meta',
        ],

        'wp_get_seo_data' => [
            'description' => 'Get SEO data for a post: title, description, canonical URL, and Open Graph fields. Checks Yoast, Rank Math, and raw meta.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'post_id' => ['type' => 'integer', 'description' => 'Post ID'],
                ],
                'required' => ['post_id'],
            ],
            'handler' => 'on_handle_get_seo_data',
        ],

        // ──────────────────────────────────────────────
        // MAINTENANCE TOOLS
        // ──────────────────────────────────────────────

        'wp_flush_cache' => [
            'description' => 'Flush the WordPress object cache and rewrite rules.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => new \stdClass(),
            ],
            'handler' => 'on_handle_flush_cache',
        ],

        'wp_get_cron_events' => [
            'description' => 'List all scheduled WP-Cron events.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => new \stdClass(),
            ],
            'handler' => 'on_handle_get_cron_events',
        ],

        'wp_get_transients' => [
            'description' => 'List transients stored in the database, optionally filtered by search.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'search' => ['type' => 'string', 'description' => 'Filter transients by name pattern'],
                ],
            ],
            'handler' => 'on_handle_get_transients',
        ],

        'wp_delete_transient' => [
            'description' => 'Delete a transient by name.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'name' => ['type' => 'string', 'description' => 'Transient name (without _transient_ prefix)'],
                ],
                'required' => ['name'],
            ],
            'handler' => 'on_handle_delete_transient',
        ],
    ];

    // ──────────────────────────────────────────────
    // WOOCOMMERCE TOOLS — only if WooCommerce is active
    // ──────────────────────────────────────────────

    if (class_exists('WooCommerce')) {
        $tools['wc_list_products'] = [
            'description' => 'List WooCommerce products with basic details.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'per_page' => ['type' => 'integer', 'description' => 'Number of products', 'default' => 50],
                    'status'   => ['type' => 'string', 'description' => 'Product status: publish, draft, pending, private', 'default' => 'publish'],
                    'search'   => ['type' => 'string', 'description' => 'Search products by title'],
                ],
            ],
            'handler' => 'on_handle_wc_list_products',
        ];

        $tools['wc_get_product'] = [
            'description' => 'Get detailed information about a single WooCommerce product.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'id' => ['type' => 'integer', 'description' => 'Product ID'],
                ],
                'required' => ['id'],
            ],
            'handler' => 'on_handle_wc_get_product',
        ];

        $tools['wc_list_orders'] = [
            'description' => 'List WooCommerce orders with optional status filter.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'status'   => ['type' => 'string', 'description' => 'Order status: processing, completed, on-hold, cancelled, refunded, pending, failed', 'default' => 'any'],
                    'per_page' => ['type' => 'integer', 'description' => 'Number of orders', 'default' => 50],
                ],
            ],
            'handler' => 'on_handle_wc_list_orders',
        ];

        $tools['wc_get_order'] = [
            'description' => 'Get detailed information about a single WooCommerce order.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'id' => ['type' => 'integer', 'description' => 'Order ID'],
                ],
                'required' => ['id'],
            ],
            'handler' => 'on_handle_wc_get_order',
        ];

        $tools['wc_update_order_status'] = [
            'description' => 'Update the status of a WooCommerce order.',
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'id'     => ['type' => 'integer', 'description' => 'Order ID'],
                    'status' => ['type' => 'string', 'description' => 'New status: processing, completed, on-hold, cancelled, refunded'],
                ],
                'required' => ['id', 'status'],
            ],
            'handler' => 'on_handle_wc_update_order_status',
        ];
    }

    return $tools;
}


// ═══════════════════════════════════════════════════════
// TAXONOMY HANDLERS
// ═══════════════════════════════════════════════════════

function on_handle_list_taxonomies($params) {
    $taxonomies = get_taxonomies([], 'objects');
    $result = [];

    foreach ($taxonomies as $slug => $tax) {
        $result[] = [
            'slug'        => $slug,
            'name'        => $tax->labels->name,
            'singular'    => $tax->labels->singular_name,
            'hierarchical' => $tax->hierarchical,
            'public'      => $tax->public,
            'post_types'  => $tax->object_type,
            'count'       => wp_count_terms(['taxonomy' => $slug]),
        ];
    }

    return ['taxonomies' => $result, 'total' => count($result)];
}

function on_handle_list_terms($params) {
    $taxonomy = sanitize_key($params['taxonomy'] ?? '');
    if (!taxonomy_exists($taxonomy)) {
        return ['error' => 'Taxonomy does not exist: ' . $taxonomy];
    }

    $args = [
        'taxonomy'   => $taxonomy,
        'number'     => min(absint($params['per_page'] ?? 50), 200),
        'hide_empty' => false,
    ];

    if (!empty($params['search'])) {
        $args['search'] = sanitize_text_field($params['search']);
    }

    $terms = get_terms($args);
    if (is_wp_error($terms)) {
        return ['error' => $terms->get_error_message()];
    }

    $result = [];
    foreach ($terms as $term) {
        $result[] = [
            'id'          => $term->term_id,
            'name'        => $term->name,
            'slug'        => $term->slug,
            'description' => $term->description,
            'parent'      => $term->parent,
            'count'       => $term->count,
        ];
    }

    return ['terms' => $result, 'total' => count($result), 'taxonomy' => $taxonomy];
}

function on_handle_create_term($params) {
    $taxonomy = sanitize_key($params['taxonomy'] ?? '');
    $name     = sanitize_text_field($params['name'] ?? '');

    if (!taxonomy_exists($taxonomy)) {
        return ['error' => 'Taxonomy does not exist: ' . $taxonomy];
    }
    if (empty($name)) {
        return ['error' => 'Term name is required'];
    }

    $args = [];
    if (!empty($params['slug']))        $args['slug']        = sanitize_title($params['slug']);
    if (!empty($params['parent']))      $args['parent']      = absint($params['parent']);
    if (!empty($params['description'])) $args['description'] = sanitize_textarea_field($params['description']);

    $result = wp_insert_term($name, $taxonomy, $args);
    if (is_wp_error($result)) {
        return ['error' => $result->get_error_message()];
    }

    $term = get_term($result['term_id'], $taxonomy);
    return [
        'created' => true,
        'term'    => [
            'id'          => $term->term_id,
            'name'        => $term->name,
            'slug'        => $term->slug,
            'description' => $term->description,
            'parent'      => $term->parent,
            'taxonomy'    => $taxonomy,
        ],
    ];
}

function on_handle_assign_terms($params) {
    $post_id  = absint($params['post_id'] ?? 0);
    $taxonomy = sanitize_key($params['taxonomy'] ?? '');
    $term_ids = array_map('absint', $params['term_ids'] ?? []);

    if (!$post_id || !get_post($post_id)) {
        return ['error' => 'Invalid post ID'];
    }
    if (!taxonomy_exists($taxonomy)) {
        return ['error' => 'Taxonomy does not exist: ' . $taxonomy];
    }
    if (empty($term_ids)) {
        return ['error' => 'term_ids array is required'];
    }

    $result = wp_set_object_terms($post_id, $term_ids, $taxonomy);
    if (is_wp_error($result)) {
        return ['error' => $result->get_error_message()];
    }

    return [
        'assigned' => true,
        'post_id'  => $post_id,
        'taxonomy' => $taxonomy,
        'term_ids' => $result,
    ];
}


// ═══════════════════════════════════════════════════════
// COMMENT HANDLERS
// ═══════════════════════════════════════════════════════

function on_handle_list_comments($params) {
    $args = [
        'number' => min(absint($params['per_page'] ?? 50), 200),
        'orderby' => 'comment_date_gmt',
        'order'   => 'DESC',
    ];

    if (!empty($params['post_id'])) {
        $args['post_id'] = absint($params['post_id']);
    }

    $status_map = [
        'approve' => 'approve',
        'hold'    => 'hold',
        'spam'    => 'spam',
        'trash'   => 'trash',
        'all'     => 'all',
    ];
    $status = sanitize_key($params['status'] ?? 'all');
    $args['status'] = $status_map[$status] ?? 'all';

    $comments = get_comments($args);
    $result = [];

    foreach ($comments as $comment) {
        $result[] = [
            'id'           => (int) $comment->comment_ID,
            'post_id'      => (int) $comment->comment_post_ID,
            'author_name'  => $comment->comment_author,
            'author_email' => $comment->comment_author_email,
            'content'      => $comment->comment_content,
            'status'       => wp_get_comment_status($comment),
            'date'         => $comment->comment_date_gmt,
            'parent'       => (int) $comment->comment_parent,
        ];
    }

    return ['comments' => $result, 'total' => count($result)];
}

function on_handle_create_comment($params) {
    $post_id = absint($params['post_id'] ?? 0);
    if (!$post_id || !get_post($post_id)) {
        return ['error' => 'Invalid post ID'];
    }

    $content      = sanitize_textarea_field($params['content'] ?? '');
    $author_name  = sanitize_text_field($params['author_name'] ?? '');
    $author_email = sanitize_email($params['author_email'] ?? '');

    if (empty($content)) {
        return ['error' => 'Comment content is required'];
    }
    if (empty($author_name)) {
        return ['error' => 'Author name is required'];
    }
    if (!is_email($author_email)) {
        return ['error' => 'Valid author email is required'];
    }

    $comment_id = wp_insert_comment([
        'comment_post_ID'      => $post_id,
        'comment_content'      => $content,
        'comment_author'       => $author_name,
        'comment_author_email' => $author_email,
        'comment_approved'     => 1,
        'comment_type'         => 'comment',
    ]);

    if (!$comment_id) {
        return ['error' => 'Failed to create comment'];
    }

    return [
        'created'    => true,
        'comment_id' => $comment_id,
        'post_id'    => $post_id,
    ];
}

function on_handle_update_comment_status($params) {
    $comment_id = absint($params['comment_id'] ?? 0);
    $status     = sanitize_key($params['status'] ?? '');

    if (!$comment_id || !get_comment($comment_id)) {
        return ['error' => 'Invalid comment ID'];
    }

    $allowed = ['approve', 'spam', 'trash'];
    if (!in_array($status, $allowed, true)) {
        return ['error' => 'Status must be one of: approve, spam, trash'];
    }

    $status_map = [
        'approve' => '1',
        'spam'    => 'spam',
        'trash'   => 'trash',
    ];

    $result = wp_set_comment_status($comment_id, $status_map[$status]);
    if (!$result) {
        return ['error' => 'Failed to update comment status'];
    }

    return [
        'updated'    => true,
        'comment_id' => $comment_id,
        'status'     => $status,
    ];
}


// ═══════════════════════════════════════════════════════
// MENU HANDLERS
// ═══════════════════════════════════════════════════════

function on_handle_list_menus($params) {
    $menus     = wp_get_nav_menus();
    $locations = get_nav_menu_locations();
    $registered = get_registered_nav_menus();

    $result = [];
    foreach ($menus as $menu) {
        $assigned_locations = [];
        foreach ($locations as $loc_slug => $menu_id) {
            if ($menu_id === $menu->term_id) {
                $assigned_locations[] = [
                    'slug' => $loc_slug,
                    'name' => $registered[$loc_slug] ?? $loc_slug,
                ];
            }
        }

        $result[] = [
            'id'         => $menu->term_id,
            'name'       => $menu->name,
            'slug'       => $menu->slug,
            'count'      => $menu->count,
            'locations'  => $assigned_locations,
        ];
    }

    return [
        'menus'              => $result,
        'total'              => count($result),
        'registered_locations' => $registered,
    ];
}

function on_handle_get_menu_items($params) {
    $menu_id = absint($params['menu_id'] ?? 0);
    if (!$menu_id) {
        return ['error' => 'menu_id is required'];
    }

    $menu = wp_get_nav_menu_object($menu_id);
    if (!$menu) {
        return ['error' => 'Menu not found: ' . $menu_id];
    }

    $items = wp_get_nav_menu_items($menu_id);
    if (!$items) {
        return ['menu_id' => $menu_id, 'menu_name' => $menu->name, 'items' => [], 'total' => 0];
    }

    $result = [];
    foreach ($items as $item) {
        $result[] = [
            'id'        => (int) $item->ID,
            'title'     => $item->title,
            'url'       => $item->url,
            'type'      => $item->type,
            'object'    => $item->object,
            'object_id' => (int) $item->object_id,
            'parent'    => (int) $item->menu_item_parent,
            'order'     => (int) $item->menu_order,
            'classes'   => array_filter($item->classes),
            'target'    => $item->target,
        ];
    }

    return ['menu_id' => $menu_id, 'menu_name' => $menu->name, 'items' => $result, 'total' => count($result)];
}


// ═══════════════════════════════════════════════════════
// THEME HANDLERS
// ═══════════════════════════════════════════════════════

function on_handle_list_themes($params) {
    $themes      = wp_get_themes();
    $active_slug = get_stylesheet();
    $result      = [];

    foreach ($themes as $slug => $theme) {
        $result[] = [
            'stylesheet'  => $slug,
            'name'        => $theme->get('Name'),
            'version'     => $theme->get('Version'),
            'author'      => $theme->get('Author'),
            'description' => $theme->get('Description'),
            'active'      => ($slug === $active_slug),
            'parent'      => $theme->parent() ? $theme->parent()->get_stylesheet() : null,
            'screenshot'  => $theme->get_screenshot(),
        ];
    }

    return ['themes' => $result, 'total' => count($result), 'active' => $active_slug];
}

function on_handle_get_active_theme($params) {
    $theme = wp_get_theme();

    return [
        'stylesheet'   => $theme->get_stylesheet(),
        'template'     => $theme->get_template(),
        'name'         => $theme->get('Name'),
        'version'      => $theme->get('Version'),
        'author'       => $theme->get('Author'),
        'author_uri'   => $theme->get('AuthorURI'),
        'description'  => $theme->get('Description'),
        'theme_uri'    => $theme->get('ThemeURI'),
        'text_domain'  => $theme->get('TextDomain'),
        'tags'         => $theme->get('Tags'),
        'is_child'     => $theme->parent() !== false,
        'parent_theme' => $theme->parent() ? $theme->parent()->get('Name') : null,
        'screenshot'   => $theme->get_screenshot(),
        'theme_root'   => $theme->get_theme_root(),
        'block_theme'  => $theme->is_block_theme(),
    ];
}

function on_handle_switch_theme($params) {
    $stylesheet = sanitize_file_name($params['stylesheet'] ?? '');
    if (empty($stylesheet)) {
        return ['error' => 'stylesheet is required'];
    }

    $theme = wp_get_theme($stylesheet);
    if (!$theme->exists()) {
        return ['error' => 'Theme not found: ' . $stylesheet];
    }

    switch_theme($stylesheet);

    $active = get_stylesheet();
    return [
        'switched'   => ($active === $stylesheet),
        'stylesheet' => $active,
        'name'       => wp_get_theme($active)->get('Name'),
    ];
}


// ═══════════════════════════════════════════════════════
// PLUGIN HANDLERS
// ═══════════════════════════════════════════════════════

function on_handle_list_plugins($params) {
    if (!function_exists('get_plugins')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $all_plugins    = get_plugins();
    $active_plugins = get_option('active_plugins', []);
    $result         = [];

    foreach ($all_plugins as $file => $data) {
        $result[] = [
            'file'        => $file,
            'name'        => $data['Name'] ?? '',
            'version'     => $data['Version'] ?? '',
            'author'      => $data['Author'] ?? '',
            'description' => $data['Description'] ?? '',
            'active'      => in_array($file, $active_plugins, true),
            'network'     => is_plugin_active_for_network($file),
            'plugin_uri'  => $data['PluginURI'] ?? '',
        ];
    }

    return ['plugins' => $result, 'total' => count($result), 'active_count' => count($active_plugins)];
}

function on_handle_activate_plugin($params) {
    if (!function_exists('activate_plugin')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $plugin = sanitize_text_field($params['plugin'] ?? '');
    if (empty($plugin)) {
        return ['error' => 'plugin path is required'];
    }

    if (is_plugin_active($plugin)) {
        return ['error' => 'Plugin is already active: ' . $plugin];
    }

    $result = activate_plugin($plugin);
    if (is_wp_error($result)) {
        return ['error' => $result->get_error_message()];
    }

    return ['activated' => true, 'plugin' => $plugin];
}

function on_handle_deactivate_plugin($params) {
    if (!function_exists('deactivate_plugins')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $plugin = sanitize_text_field($params['plugin'] ?? '');
    if (empty($plugin)) {
        return ['error' => 'plugin path is required'];
    }

    if (!is_plugin_active($plugin)) {
        return ['error' => 'Plugin is not active: ' . $plugin];
    }

    deactivate_plugins($plugin);

    return ['deactivated' => true, 'plugin' => $plugin];
}


// ═══════════════════════════════════════════════════════
// MEDIA HANDLERS
// ═══════════════════════════════════════════════════════

function on_handle_list_media($params) {
    $args = [
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'posts_per_page' => min(absint($params['per_page'] ?? 50), 200),
        'orderby'        => 'date',
        'order'          => 'DESC',
    ];

    if (!empty($params['mime_type'])) {
        $args['post_mime_type'] = sanitize_text_field($params['mime_type']);
    }
    if (!empty($params['search'])) {
        $args['s'] = sanitize_text_field($params['search']);
    }

    $query = new WP_Query($args);
    $result = [];

    foreach ($query->posts as $post) {
        $meta = wp_get_attachment_metadata($post->ID);
        $result[] = [
            'id'        => $post->ID,
            'title'     => $post->post_title,
            'url'       => wp_get_attachment_url($post->ID),
            'mime_type' => $post->post_mime_type,
            'date'      => $post->post_date_gmt,
            'file_size' => filesize(get_attached_file($post->ID)) ?: null,
            'width'     => $meta['width'] ?? null,
            'height'    => $meta['height'] ?? null,
            'alt'       => get_post_meta($post->ID, '_wp_attachment_image_alt', true),
        ];
    }

    return ['media' => $result, 'total' => $query->found_posts];
}

function on_handle_delete_media($params) {
    $id    = absint($params['id'] ?? 0);
    $force = !empty($params['force']);

    if (!$id) {
        return ['error' => 'Attachment ID is required'];
    }

    $attachment = get_post($id);
    if (!$attachment || $attachment->post_type !== 'attachment') {
        return ['error' => 'Attachment not found: ' . $id];
    }

    $title  = $attachment->post_title;
    $result = wp_delete_attachment($id, $force);

    if (!$result) {
        return ['error' => 'Failed to delete attachment: ' . $id];
    }

    return ['deleted' => true, 'id' => $id, 'title' => $title, 'force' => $force];
}


// ═══════════════════════════════════════════════════════
// SEARCH HANDLERS
// ═══════════════════════════════════════════════════════

function on_handle_search($params) {
    $query     = sanitize_text_field($params['query'] ?? '');
    $post_type = sanitize_key($params['post_type'] ?? 'any');
    $per_page  = min(absint($params['per_page'] ?? 20), 100);

    if (empty($query)) {
        return ['error' => 'Search query is required'];
    }

    $args = [
        's'              => $query,
        'post_type'      => $post_type,
        'posts_per_page' => $per_page,
        'post_status'    => 'publish',
        'orderby'        => 'relevance',
    ];

    $wp_query = new WP_Query($args);
    $results  = [];

    foreach ($wp_query->posts as $post) {
        $results[] = [
            'id'        => $post->ID,
            'title'     => $post->post_title,
            'type'      => $post->post_type,
            'status'    => $post->post_status,
            'date'      => $post->post_date_gmt,
            'url'       => get_permalink($post->ID),
            'excerpt'   => wp_trim_words($post->post_content, 30),
            'author'    => get_the_author_meta('display_name', $post->post_author),
        ];
    }

    return ['results' => $results, 'total' => $wp_query->found_posts, 'query' => $query];
}

function on_handle_search_replace($params) {
    global $wpdb;

    $search  = $params['search'] ?? '';
    $replace = $params['replace'] ?? '';
    $table   = sanitize_key($params['table'] ?? 'posts');
    $dry_run = $params['dry_run'] ?? true;

    if (empty($search)) {
        return ['error' => 'search string is required'];
    }

    // Whitelist allowed tables to prevent arbitrary table access
    $allowed_tables = [
        'posts'       => ['post_content', 'post_title', 'post_excerpt'],
        'postmeta'    => ['meta_value'],
        'options'     => ['option_value'],
        'comments'    => ['comment_content', 'comment_author'],
        'commentmeta' => ['meta_value'],
    ];

    if (!isset($allowed_tables[$table])) {
        return ['error' => 'Table not allowed. Use one of: ' . implode(', ', array_keys($allowed_tables))];
    }

    $full_table = $wpdb->prefix . $table;
    $columns    = $allowed_tables[$table];
    $total      = 0;
    $preview    = [];

    foreach ($columns as $column) {
        // Count matches
        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM `{$full_table}` WHERE `{$column}` LIKE %s",
            '%' . $wpdb->esc_like($search) . '%'
        ));
        $total += $count;

        // Collect preview rows (up to 5 per column)
        if ($count > 0) {
            $id_col = $table === 'options' ? 'option_id' : ($table === 'comments' || $table === 'commentmeta' ? 'comment_ID' : 'ID');
            if ($table === 'postmeta') $id_col = 'meta_id';
            if ($table === 'commentmeta') $id_col = 'meta_id';

            $sample_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT `{$id_col}`, `{$column}` FROM `{$full_table}` WHERE `{$column}` LIKE %s LIMIT 5",
                '%' . $wpdb->esc_like($search) . '%'
            ));

            foreach ($sample_rows as $row) {
                $preview[] = [
                    'table'  => $table,
                    'column' => $column,
                    'id'     => $row->$id_col,
                    'before' => mb_substr($row->$column, 0, 200),
                    'after'  => mb_substr(str_replace($search, $replace, $row->$column), 0, 200),
                ];
            }
        }
    }

    // Only apply if not dry run
    $affected = 0;
    if (!$dry_run && $total > 0) {
        foreach ($columns as $column) {
            $affected += (int) $wpdb->query($wpdb->prepare(
                "UPDATE `{$full_table}` SET `{$column}` = REPLACE(`{$column}`, %s, %s) WHERE `{$column}` LIKE %s",
                $search,
                $replace,
                '%' . $wpdb->esc_like($search) . '%'
            ));
        }

        // Clear caches after modification
        wp_cache_flush();
    }

    return [
        'dry_run'      => $dry_run,
        'search'       => $search,
        'replace'      => $replace,
        'table'        => $table,
        'matches'      => $total,
        'rows_updated' => $dry_run ? 0 : $affected,
        'preview'      => array_slice($preview, 0, 10),
    ];
}


// ═══════════════════════════════════════════════════════
// SEO HANDLERS
// ═══════════════════════════════════════════════════════

function on_handle_get_meta($params) {
    $post_id = absint($params['post_id'] ?? 0);
    $key     = sanitize_text_field($params['key'] ?? '');

    if (!$post_id || !get_post($post_id)) {
        return ['error' => 'Invalid post ID'];
    }
    if (empty($key)) {
        return ['error' => 'Meta key is required'];
    }

    $value = get_post_meta($post_id, $key, true);

    return [
        'post_id' => $post_id,
        'key'     => $key,
        'value'   => $value,
        'exists'  => metadata_exists('post', $post_id, $key),
    ];
}

function on_handle_update_meta($params) {
    $post_id = absint($params['post_id'] ?? 0);
    $key     = sanitize_text_field($params['key'] ?? '');
    $value   = sanitize_text_field($params['value'] ?? '');

    if (!$post_id || !get_post($post_id)) {
        return ['error' => 'Invalid post ID'];
    }
    if (empty($key)) {
        return ['error' => 'Meta key is required'];
    }

    $result = update_post_meta($post_id, $key, $value);

    return [
        'updated' => $result !== false,
        'post_id' => $post_id,
        'key'     => $key,
        'value'   => $value,
    ];
}

function on_handle_get_seo_data($params) {
    $post_id = absint($params['post_id'] ?? 0);
    if (!$post_id || !get_post($post_id)) {
        return ['error' => 'Invalid post ID'];
    }

    $post = get_post($post_id);
    $seo  = [
        'post_id'   => $post_id,
        'title'     => $post->post_title,
        'url'       => get_permalink($post_id),
        'canonical' => null,
        'meta_title'       => null,
        'meta_description' => null,
        'og_title'         => null,
        'og_description'   => null,
        'og_image'         => null,
        'twitter_title'    => null,
        'twitter_description' => null,
        'robots'           => null,
        'schema'           => null,
        'seo_plugin'       => 'none',
    ];

    // Check Yoast SEO
    if (defined('WPSEO_VERSION')) {
        $seo['seo_plugin']        = 'yoast';
        $seo['meta_title']        = get_post_meta($post_id, '_yoast_wpseo_title', true) ?: null;
        $seo['meta_description']  = get_post_meta($post_id, '_yoast_wpseo_metadesc', true) ?: null;
        $seo['canonical']         = get_post_meta($post_id, '_yoast_wpseo_canonical', true) ?: null;
        $seo['og_title']          = get_post_meta($post_id, '_yoast_wpseo_opengraph-title', true) ?: null;
        $seo['og_description']    = get_post_meta($post_id, '_yoast_wpseo_opengraph-description', true) ?: null;
        $seo['og_image']          = get_post_meta($post_id, '_yoast_wpseo_opengraph-image', true) ?: null;
        $seo['twitter_title']     = get_post_meta($post_id, '_yoast_wpseo_twitter-title', true) ?: null;
        $seo['twitter_description'] = get_post_meta($post_id, '_yoast_wpseo_twitter-description', true) ?: null;
        $seo['robots']            = get_post_meta($post_id, '_yoast_wpseo_meta-robots-noindex', true) ?: null;
        $seo['schema']            = get_post_meta($post_id, '_yoast_wpseo_schema_page_type', true) ?: null;
    }
    // Check Rank Math
    elseif (class_exists('RankMath')) {
        $seo['seo_plugin']        = 'rankmath';
        $seo['meta_title']        = get_post_meta($post_id, 'rank_math_title', true) ?: null;
        $seo['meta_description']  = get_post_meta($post_id, 'rank_math_description', true) ?: null;
        $seo['canonical']         = get_post_meta($post_id, 'rank_math_canonical_url', true) ?: null;
        $seo['og_title']          = get_post_meta($post_id, 'rank_math_facebook_title', true) ?: null;
        $seo['og_description']    = get_post_meta($post_id, 'rank_math_facebook_description', true) ?: null;
        $seo['og_image']          = get_post_meta($post_id, 'rank_math_facebook_image', true) ?: null;
        $seo['twitter_title']     = get_post_meta($post_id, 'rank_math_twitter_title', true) ?: null;
        $seo['twitter_description'] = get_post_meta($post_id, 'rank_math_twitter_description', true) ?: null;
        $seo['robots']            = get_post_meta($post_id, 'rank_math_robots', true) ?: null;
        $seo['schema']            = get_post_meta($post_id, 'rank_math_rich_snippet', true) ?: null;
    }
    // Check All in One SEO
    elseif (function_exists('aioseo')) {
        $seo['seo_plugin']        = 'aioseo';
        $seo['meta_title']        = get_post_meta($post_id, '_aioseo_title', true) ?: null;
        $seo['meta_description']  = get_post_meta($post_id, '_aioseo_description', true) ?: null;
        $seo['canonical']         = get_post_meta($post_id, '_aioseo_canonical_url', true) ?: null;
        $seo['og_title']          = get_post_meta($post_id, '_aioseo_og_title', true) ?: null;
        $seo['og_description']    = get_post_meta($post_id, '_aioseo_og_description', true) ?: null;
        $seo['og_image']          = get_post_meta($post_id, '_aioseo_og_image_url', true) ?: null;
        $seo['twitter_title']     = get_post_meta($post_id, '_aioseo_twitter_title', true) ?: null;
        $seo['twitter_description'] = get_post_meta($post_id, '_aioseo_twitter_description', true) ?: null;
    }

    // Fallback: check raw meta for description and og tags
    if (!$seo['meta_description']) {
        $seo['meta_description'] = get_post_meta($post_id, 'description', true)
            ?: get_post_meta($post_id, '_description', true)
            ?: null;
    }

    // Featured image as OG fallback
    if (!$seo['og_image'] && has_post_thumbnail($post_id)) {
        $seo['og_image'] = get_the_post_thumbnail_url($post_id, 'large');
    }

    return $seo;
}


// ═══════════════════════════════════════════════════════
// MAINTENANCE HANDLERS
// ═══════════════════════════════════════════════════════

function on_handle_flush_cache($params) {
    $flushed = [];

    // Object cache
    wp_cache_flush();
    $flushed[] = 'object_cache';

    // Rewrite rules
    flush_rewrite_rules(false);
    $flushed[] = 'rewrite_rules';

    // OPcache if available
    if (function_exists('opcache_reset')) {
        opcache_reset();
        $flushed[] = 'opcache';
    }

    return ['flushed' => $flushed, 'timestamp' => gmdate('c')];
}

function on_handle_get_cron_events($params) {
    $crons  = _get_cron_array();
    $result = [];

    if (!is_array($crons)) {
        return ['events' => [], 'total' => 0];
    }

    foreach ($crons as $timestamp => $hooks) {
        foreach ($hooks as $hook => $events) {
            foreach ($events as $key => $event) {
                $result[] = [
                    'hook'       => $hook,
                    'next_run'   => gmdate('c', $timestamp),
                    'timestamp'  => (int) $timestamp,
                    'schedule'   => $event['schedule'] ?: 'single',
                    'interval'   => $event['interval'] ?? null,
                    'args'       => $event['args'] ?? [],
                ];
            }
        }
    }

    // Sort by next run
    usort($result, fn($a, $b) => $a['timestamp'] <=> $b['timestamp']);

    return ['events' => $result, 'total' => count($result)];
}

function on_handle_get_transients($params) {
    global $wpdb;

    $search = sanitize_text_field($params['search'] ?? '');
    $where  = '';

    if (!empty($search)) {
        $where = $wpdb->prepare(
            " AND option_name LIKE %s",
            '%_transient_' . $wpdb->esc_like($search) . '%'
        );
    }

    $rows = $wpdb->get_results(
        "SELECT option_name, option_value FROM {$wpdb->options}
         WHERE option_name LIKE '_transient_%'
         AND option_name NOT LIKE '_transient_timeout_%'
         {$where}
         ORDER BY option_name
         LIMIT 200"
    );

    $result = [];
    foreach ($rows as $row) {
        $name    = str_replace('_transient_', '', $row->option_name);
        $timeout = get_option('_transient_timeout_' . $name);

        $result[] = [
            'name'    => $name,
            'value'   => mb_substr($row->option_value, 0, 500),
            'expires' => $timeout ? gmdate('c', (int) $timeout) : 'never',
            'expired' => $timeout ? (time() > (int) $timeout) : false,
        ];
    }

    return ['transients' => $result, 'total' => count($result)];
}

function on_handle_delete_transient($params) {
    $name = sanitize_text_field($params['name'] ?? '');
    if (empty($name)) {
        return ['error' => 'Transient name is required'];
    }

    $existed = get_transient($name);
    $deleted = delete_transient($name);

    return [
        'deleted' => $deleted,
        'name'    => $name,
        'existed' => $existed !== false,
    ];
}


// ═══════════════════════════════════════════════════════
// WOOCOMMERCE HANDLERS
// ═══════════════════════════════════════════════════════

function on_handle_wc_list_products($params) {
    if (!class_exists('WooCommerce')) {
        return ['error' => 'WooCommerce is not active'];
    }

    $per_page = min(absint($params['per_page'] ?? 50), 200);
    $status   = sanitize_key($params['status'] ?? 'publish');
    $search   = sanitize_text_field($params['search'] ?? '');

    $args = [
        'limit'  => $per_page,
        'status' => $status,
        'return' => 'objects',
    ];

    if (!empty($search)) {
        // WC product query doesn't natively support search — use WP_Query fallback
        $wp_args = [
            'post_type'      => 'product',
            'post_status'    => $status,
            'posts_per_page' => $per_page,
            's'              => $search,
            'fields'         => 'ids',
        ];
        $ids = get_posts($wp_args);
        if (empty($ids)) {
            return ['products' => [], 'total' => 0];
        }
        $args['include'] = $ids;
    }

    $products = wc_get_products($args);
    $result   = [];

    foreach ($products as $product) {
        $result[] = [
            'id'            => $product->get_id(),
            'name'          => $product->get_name(),
            'slug'          => $product->get_slug(),
            'type'          => $product->get_type(),
            'status'        => $product->get_status(),
            'sku'           => $product->get_sku(),
            'price'         => $product->get_price(),
            'regular_price' => $product->get_regular_price(),
            'sale_price'    => $product->get_sale_price(),
            'stock_status'  => $product->get_stock_status(),
            'stock_quantity' => $product->get_stock_quantity(),
            'categories'    => wp_list_pluck($product->get_category_ids() ? get_terms(['term_taxonomy_id' => $product->get_category_ids(), 'hide_empty' => false]) : [], 'name'),
            'url'           => $product->get_permalink(),
            'image'         => wp_get_attachment_url($product->get_image_id()),
            'date_created'  => $product->get_date_created() ? $product->get_date_created()->date('c') : null,
        ];
    }

    return ['products' => $result, 'total' => count($result)];
}

function on_handle_wc_get_product($params) {
    if (!class_exists('WooCommerce')) {
        return ['error' => 'WooCommerce is not active'];
    }

    $id = absint($params['id'] ?? 0);
    if (!$id) {
        return ['error' => 'Product ID is required'];
    }

    $product = wc_get_product($id);
    if (!$product) {
        return ['error' => 'Product not found: ' . $id];
    }

    $data = [
        'id'              => $product->get_id(),
        'name'            => $product->get_name(),
        'slug'            => $product->get_slug(),
        'type'            => $product->get_type(),
        'status'          => $product->get_status(),
        'description'     => $product->get_description(),
        'short_description' => $product->get_short_description(),
        'sku'             => $product->get_sku(),
        'price'           => $product->get_price(),
        'regular_price'   => $product->get_regular_price(),
        'sale_price'      => $product->get_sale_price(),
        'on_sale'         => $product->is_on_sale(),
        'stock_status'    => $product->get_stock_status(),
        'stock_quantity'  => $product->get_stock_quantity(),
        'manage_stock'    => $product->get_manage_stock(),
        'weight'          => $product->get_weight(),
        'length'          => $product->get_length(),
        'width'           => $product->get_width(),
        'height'          => $product->get_height(),
        'virtual'         => $product->is_virtual(),
        'downloadable'    => $product->is_downloadable(),
        'tax_status'      => $product->get_tax_status(),
        'tax_class'       => $product->get_tax_class(),
        'url'             => $product->get_permalink(),
        'image'           => wp_get_attachment_url($product->get_image_id()),
        'gallery_images'  => array_map('wp_get_attachment_url', $product->get_gallery_image_ids()),
        'categories'      => [],
        'tags'            => [],
        'attributes'      => [],
        'date_created'    => $product->get_date_created() ? $product->get_date_created()->date('c') : null,
        'date_modified'   => $product->get_date_modified() ? $product->get_date_modified()->date('c') : null,
        'total_sales'     => $product->get_total_sales(),
        'average_rating'  => $product->get_average_rating(),
        'review_count'    => $product->get_review_count(),
    ];

    // Categories
    $cat_ids = $product->get_category_ids();
    if ($cat_ids) {
        foreach ($cat_ids as $cat_id) {
            $term = get_term($cat_id, 'product_cat');
            if ($term && !is_wp_error($term)) {
                $data['categories'][] = ['id' => $term->term_id, 'name' => $term->name, 'slug' => $term->slug];
            }
        }
    }

    // Tags
    $tag_ids = $product->get_tag_ids();
    if ($tag_ids) {
        foreach ($tag_ids as $tag_id) {
            $term = get_term($tag_id, 'product_tag');
            if ($term && !is_wp_error($term)) {
                $data['tags'][] = ['id' => $term->term_id, 'name' => $term->name, 'slug' => $term->slug];
            }
        }
    }

    // Attributes
    foreach ($product->get_attributes() as $attr) {
        $data['attributes'][] = [
            'name'    => $attr->get_name(),
            'options' => $attr->get_options(),
            'visible' => $attr->get_visible(),
        ];
    }

    // Variations (for variable products)
    if ($product->is_type('variable')) {
        $data['variations'] = [];
        foreach ($product->get_available_variations() as $var) {
            $data['variations'][] = [
                'id'            => $var['variation_id'],
                'sku'           => $var['sku'],
                'price'         => $var['display_price'],
                'regular_price' => $var['display_regular_price'],
                'attributes'    => $var['attributes'],
                'in_stock'      => $var['is_in_stock'],
                'image'         => $var['image']['url'] ?? null,
            ];
        }
    }

    return $data;
}

function on_handle_wc_list_orders($params) {
    if (!class_exists('WooCommerce')) {
        return ['error' => 'WooCommerce is not active'];
    }

    $status   = sanitize_key($params['status'] ?? 'any');
    $per_page = min(absint($params['per_page'] ?? 50), 200);

    // Prefix with wc- if needed
    if ($status !== 'any' && !str_starts_with($status, 'wc-')) {
        $status = 'wc-' . $status;
    }

    $orders = wc_get_orders([
        'limit'  => $per_page,
        'status' => $status,
        'orderby' => 'date',
        'order'   => 'DESC',
    ]);

    $result = [];
    foreach ($orders as $order) {
        $result[] = [
            'id'              => $order->get_id(),
            'status'          => $order->get_status(),
            'total'           => $order->get_total(),
            'currency'        => $order->get_currency(),
            'payment_method'  => $order->get_payment_method_title(),
            'customer_name'   => $order->get_formatted_billing_full_name(),
            'customer_email'  => $order->get_billing_email(),
            'items_count'     => $order->get_item_count(),
            'date_created'    => $order->get_date_created() ? $order->get_date_created()->date('c') : null,
            'date_completed'  => $order->get_date_completed() ? $order->get_date_completed()->date('c') : null,
        ];
    }

    return ['orders' => $result, 'total' => count($result)];
}

function on_handle_wc_get_order($params) {
    if (!class_exists('WooCommerce')) {
        return ['error' => 'WooCommerce is not active'];
    }

    $id = absint($params['id'] ?? 0);
    if (!$id) {
        return ['error' => 'Order ID is required'];
    }

    $order = wc_get_order($id);
    if (!$order) {
        return ['error' => 'Order not found: ' . $id];
    }

    $items = [];
    foreach ($order->get_items() as $item) {
        $product = $item->get_product();
        $items[] = [
            'id'       => $item->get_id(),
            'name'     => $item->get_name(),
            'sku'      => $product ? $product->get_sku() : '',
            'quantity' => $item->get_quantity(),
            'subtotal' => $item->get_subtotal(),
            'total'    => $item->get_total(),
            'product_id' => $item->get_product_id(),
            'variation_id' => $item->get_variation_id(),
        ];
    }

    return [
        'id'               => $order->get_id(),
        'status'           => $order->get_status(),
        'total'            => $order->get_total(),
        'subtotal'         => $order->get_subtotal(),
        'discount_total'   => $order->get_discount_total(),
        'shipping_total'   => $order->get_shipping_total(),
        'tax_total'        => $order->get_total_tax(),
        'currency'         => $order->get_currency(),
        'payment_method'   => $order->get_payment_method(),
        'payment_title'    => $order->get_payment_method_title(),
        'transaction_id'   => $order->get_transaction_id(),
        'billing'          => [
            'first_name' => $order->get_billing_first_name(),
            'last_name'  => $order->get_billing_last_name(),
            'email'      => $order->get_billing_email(),
            'phone'      => $order->get_billing_phone(),
            'address_1'  => $order->get_billing_address_1(),
            'address_2'  => $order->get_billing_address_2(),
            'city'       => $order->get_billing_city(),
            'state'      => $order->get_billing_state(),
            'postcode'   => $order->get_billing_postcode(),
            'country'    => $order->get_billing_country(),
        ],
        'shipping'         => [
            'first_name' => $order->get_shipping_first_name(),
            'last_name'  => $order->get_shipping_last_name(),
            'address_1'  => $order->get_shipping_address_1(),
            'address_2'  => $order->get_shipping_address_2(),
            'city'       => $order->get_shipping_city(),
            'state'      => $order->get_shipping_state(),
            'postcode'   => $order->get_shipping_postcode(),
            'country'    => $order->get_shipping_country(),
        ],
        'items'            => $items,
        'customer_note'    => $order->get_customer_note(),
        'date_created'     => $order->get_date_created() ? $order->get_date_created()->date('c') : null,
        'date_modified'    => $order->get_date_modified() ? $order->get_date_modified()->date('c') : null,
        'date_completed'   => $order->get_date_completed() ? $order->get_date_completed()->date('c') : null,
        'date_paid'        => $order->get_date_paid() ? $order->get_date_paid()->date('c') : null,
        'order_notes'      => array_map(function($note) {
            return [
                'id'      => $note->id,
                'content' => $note->content,
                'date'    => $note->date_created->date('c'),
                'author'  => $note->added_by,
            ];
        }, wc_get_order_notes(['order_id' => $id, 'limit' => 20])),
    ];
}

function on_handle_wc_update_order_status($params) {
    if (!class_exists('WooCommerce')) {
        return ['error' => 'WooCommerce is not active'];
    }

    $id     = absint($params['id'] ?? 0);
    $status = sanitize_key($params['status'] ?? '');

    if (!$id) {
        return ['error' => 'Order ID is required'];
    }

    $allowed = ['processing', 'completed', 'on-hold', 'cancelled', 'refunded', 'pending', 'failed'];
    if (!in_array($status, $allowed, true)) {
        return ['error' => 'Invalid status. Allowed: ' . implode(', ', $allowed)];
    }

    $order = wc_get_order($id);
    if (!$order) {
        return ['error' => 'Order not found: ' . $id];
    }

    $old_status = $order->get_status();
    $order->update_status($status, 'Status updated via 0nCore MCP.');

    return [
        'updated'    => true,
        'order_id'   => $id,
        'old_status' => $old_status,
        'new_status' => $status,
    ];
}
