/**
 * End-to-end verification for the 0nTask panel — REAL API, REAL DOM.
 *
 * Loads src/sidebar/tasks.js into a jsdom document with a stubbed chrome.* and
 * the device key from ~/.0n/ontask-key, then drives the panel the way a person
 * would: add a task, tick it, reopen it, delete it — checking after every step
 * that app.0ntask.com actually agrees, rather than that the panel merely redrew.
 *
 * WHY THIS EXISTS. It is the only thing that caught either of the two bugs this
 * panel shipped with: a newly added task sorting off the end of a capped list
 * (created fine, invisible — the panel looked like it had eaten it), and the
 * More fields never hiding because a class-level `display` beats the UA
 * `[hidden]` rule. Both pass every unit-shaped test you could write.
 *
 * It creates and then deletes one task on the live account. If it dies halfway
 * it leaves one titled "[harness] verify …" behind — delete it.
 *
 * Run (the repo has no package.json on purpose, so jsdom is installed ad hoc):
 *
 *     mkdir -p /tmp/0n-harness && cd /tmp/0n-harness && npm i jsdom
 *     node --experimental-vm-modules \
 *       ~/Github/0n-extension/scripts/verify-tasks-panel.mjs
 *
 * NOTE: run it from the directory jsdom was installed into, so the import
 * resolves; the script finds the extension by absolute path either way.
 */
import { JSDOM } from 'jsdom'
import fs from 'node:fs'
import os from 'node:os'

const KEY = fs.readFileSync(`${os.homedir()}/.0n/ontask-key`, 'utf8').trim()
const EXT = `${os.homedir()}/Github/0n-extension`

const dom = new JSDOM(`<!doctype html><html><body><div id="tasksRoot"></div></body></html>`, {
  url: 'chrome-extension://harness/sidebar.html',
  pretendToBeVisual: true,
})

const store = { on_token: KEY }
const listeners = []
const chrome = {
  storage: {
    local: {
      get: async (k) => {
        const keys = Array.isArray(k) ? k : typeof k === 'string' ? [k] : Object.keys(k || {})
        const out = {}; keys.forEach((x) => { if (x in store) out[x] = store[x] }); return out
      },
      set: async (o) => Object.assign(store, o),
      remove: async (k) => (Array.isArray(k) ? k : [k]).forEach((x) => delete store[x]),
    },
  },
  runtime: { onMessage: { addListener: (f) => listeners.push(f) } },
}

globalThis.window = dom.window
globalThis.document = dom.window.document
globalThis.chrome = chrome
globalThis.confirm = () => true          // the delete confirm; harness always says yes
globalThis.HTMLElement = dom.window.HTMLElement
globalThis.Node = dom.window.Node
globalThis.Event = dom.window.Event
globalThis.CustomEvent = dom.window.CustomEvent
globalThis.getComputedStyle = dom.window.getComputedStyle

const $ = (s) => document.querySelector(s)
const click = (el) => el.dispatchEvent(new dom.window.MouseEvent('click', { bubbles: true, cancelable: true }))
const tick = (ms = 60) => new Promise((r) => setTimeout(r, ms))

let pass = 0, fail = 0
const check = (name, cond, extra = '') => {
  if (cond) { pass++; console.log(`  PASS  ${name}`) }
  else { fail++; console.log(`  FAIL  ${name} ${extra}`) }
}

const { initTasks } = await import(`file://${EXT}/src/sidebar/tasks.js`)

console.log('\n── 1. Panel boots and lists real tasks ──')
await initTasks($('#tasksRoot'))
await tick(4000)

const count = $('#ot-count').textContent
console.log(`  count line: "${count}"`)
check('list rendered rows', $('#ot-list').querySelectorAll('.ot-task').length > 0)
check('count line shows open/total', /\d+ open · \d+ total/.test(count), `got "${count}"`)
check('no auth warning', !$('#ot-list').querySelector('.ot-warn'),
  $('#ot-list').querySelector('.ot-warn')?.textContent || '')

console.log('\n── 2. Quick-add creates a REAL task ──')
const marker = `[harness] verify ${Date.now()}`
$('#ot-title').value = marker
click($('#ot-more'))                       // open the More fields
$('#ot-notes').value = 'created by the extension panel harness'
$('#ot-priority').value = 'low'
$('#ot-category').value = 'harness'
$('#ot-add').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }))
await tick(5000)

const rows = [...$('#ot-list').querySelectorAll('.ot-task')]
const added = rows.find((r) => r.querySelector('.ot-title').textContent === marker)
check('new task appears in the list', !!added)
check('title box cleared after add', $('#ot-title').value === '')
check('category tag rendered', added?.textContent.includes('harness'))
const newId = added?.dataset.id
console.log(`  created id: ${newId}`)

// Independent confirmation: ask the API directly, not the panel's own memory.
const verify = await (await fetch('https://app.0ntask.com/api/v1/tasks',
  { headers: { Authorization: `Bearer ${KEY}` } })).json()
const server = verify.tasks.find((t) => t.id === newId)
check('server confirms the task exists', !!server)
check('server has our title', server?.title === marker, server?.title)
check('server stamped source=0n-extension', server?.source === '0n-extension', server?.source)
check('server has priority=low', server?.priority === 'low', server?.priority)

console.log('\n── 3. Tick completes it (server-side, not just visually) ──')
click(added.querySelector('.ot-tick'))
await tick(5000)
const afterRows = [...$('#ot-list').querySelectorAll('.ot-task')]
check('completed task left the Open filter',
  !afterRows.some((r) => r.dataset.id === newId))

const v2 = await (await fetch('https://app.0ntask.com/api/v1/tasks',
  { headers: { Authorization: `Bearer ${KEY}` } })).json()
const s2 = v2.tasks.find((t) => t.id === newId)
check('server status is completed', s2?.status === 'completed', s2?.status)
check('completing did NOT wipe the title', s2?.title === marker, s2?.title)
check('completing did NOT wipe the notes',
  s2?.notes === 'created by the extension panel harness', s2?.notes)

console.log('\n── 4. Done filter shows it, and reopen works ──')
click([...document.querySelectorAll('.ot-chip')].find((c) => c.dataset.filter === 'done'))
await tick(120)
const doneRow = [...$('#ot-list').querySelectorAll('.ot-task')].find((r) => r.dataset.id === newId)
check('task visible under Done', !!doneRow)
check('rendered with the done class', doneRow?.classList.contains('done'))
click(doneRow.querySelector('.ot-tick'))
await tick(5000)
const v3 = await (await fetch('https://app.0ntask.com/api/v1/tasks',
  { headers: { Authorization: `Bearer ${KEY}` } })).json()
check('server status back to todo', v3.tasks.find((t) => t.id === newId)?.status === 'todo')

console.log('\n── 5. Context-menu prefill drains from storage ──')
await chrome.storage.local.set({ pendingTask: { title: 'from a right-click', notes: 'https://example.com', at: Date.now() } })
$('#tasksRoot').innerHTML = ''
await initTasks($('#tasksRoot'))
await tick(4000)
check('title prefilled from parked message', $('#ot-title').value === 'from a right-click', $('#ot-title').value)
check('notes prefilled', $('#ot-notes').value === 'https://example.com')
check('prefill consumed from storage', !('pendingTask' in store))

console.log('\n── 6. A stale prefill is ignored ──')
await chrome.storage.local.set({ pendingTask: { title: 'last week', at: Date.now() - 60 * 60_000 } })
$('#tasksRoot').innerHTML = ''
await initTasks($('#tasksRoot'))
await tick(4000)
check('stale prefill not applied', $('#ot-title').value === '', $('#ot-title').value)

console.log('\n── 7. Delete removes it for real ──')
click([...document.querySelectorAll('.ot-chip')].find((c) => c.dataset.filter === 'all'))
await tick(150)
const delRow = [...$('#ot-list').querySelectorAll('.ot-task')].find((r) => r.dataset.id === newId)
  || ($('.ot-showall') && (click($('.ot-showall')), await tick(150),
      [...$('#ot-list').querySelectorAll('.ot-task')].find((r) => r.dataset.id === newId)))
check('task findable under All', !!delRow)
if (delRow) {
  click(delRow.querySelector('.ot-del'))
  await tick(5000)
  const v4 = await (await fetch('https://app.0ntask.com/api/v1/tasks',
    { headers: { Authorization: `Bearer ${KEY}` } })).json()
  check('server no longer has the task', !v4.tasks.some((t) => t.id === newId))
}

console.log('\n── 8. No key → honest "connect" state, no crash ──')
delete store.on_token
$('#tasksRoot').innerHTML = ''
await initTasks($('#tasksRoot'))
await tick(1500)
const warn = $('#ot-list').querySelector('.ot-warn')?.textContent || ''
check('shows a connect prompt instead of a blank panel', /No 0n key/i.test(warn), warn)

console.log(`\n${fail === 0 ? 'ALL GREEN' : 'FAILURES'} — ${pass} passed, ${fail} failed\n`)
process.exit(fail === 0 ? 0 : 1)
