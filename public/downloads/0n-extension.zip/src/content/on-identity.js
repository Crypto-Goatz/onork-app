// on-identity.js — the universal 0n glue.
// Runs only on your 0n account domains (0nmcp.com / 0ncore.com). When you're
// signed in, it grabs your one 0n_ token (same-origin, using your live session)
// and stores it in the extension — so the extension can carry your identity to
// every other domain, and offer "Login with 0n" everywhere.
(async () => {
  const ENDPOINTS = ['/api/token?full=1', '/api/hub/inside']
  for (const ep of ENDPOINTS) {
    try {
      const r = await fetch(ep, { credentials: 'include', headers: { accept: 'application/json' } })
      if (!r.ok) continue
      const d = await r.json().catch(() => null)
      const token = d && d.token
      if (token && String(token).startsWith('0n_')) {
        const connected = (d.connectedServices && d.connectedServices.length) || d.connected || 0
        await chrome.storage.local.set({
          on_token: token,
          on_connected: connected,
          on_token_origin: location.host,
          on_token_at: Date.now(),
        })
        // Let the popup/sidebar refresh live if open.
        try { chrome.runtime.sendMessage({ type: 'ON_TOKEN_CAPTURED', connected }) } catch { /* no receiver */ }
        break
      }
    } catch { /* not signed in on this endpoint — try the next */ }
  }
})()
