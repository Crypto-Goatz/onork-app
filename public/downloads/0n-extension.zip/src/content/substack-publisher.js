// ============================================================
// 0nTask — Substack publisher helper
// ============================================================
// Substack has no publish API, so 0nTask drafts posts and this content script
// pastes them into Substack's composer. Flow: in 0nTask (/substack) click
// "Copy full draft" → open your Substack post editor → click the "0nTask" bar's
// "Fill from clipboard" button. Best-effort against Substack's editor DOM.
(() => {
  if (window.__ontaskSubstackHelper) return
  window.__ontaskSubstackHelper = true

  const onEditor = () =>
    /\/publish\/post|\/p\/.*\/edit|\/publish\/home/.test(location.pathname) ||
    !!document.querySelector('.ProseMirror')

  // ---- fill helpers -------------------------------------------------------
  function setNativeValue(el, value) {
    const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set
    if (setter) setter.call(el, value)
    else el.value = value
    el.dispatchEvent(new Event('input', { bubbles: true }))
    el.dispatchEvent(new Event('change', { bubbles: true }))
  }

  function findTitle() {
    return (
      document.querySelector('textarea[placeholder="Title"]') ||
      document.querySelector('textarea[data-testid="post-title"]') ||
      document.querySelector('.editor-title textarea, .post-title textarea') ||
      [...document.querySelectorAll('textarea')].find((t) => /title/i.test(t.placeholder || ''))
    )
  }
  function findSubtitle() {
    return (
      document.querySelector('textarea[placeholder*="subtitle" i]') ||
      [...document.querySelectorAll('textarea')].find((t) => /subtitle|description/i.test(t.placeholder || ''))
    )
  }

  function fillBody(text) {
    const pm = document.querySelector('.ProseMirror')
    if (!pm) return false
    pm.focus()
    try {
      const sel = window.getSelection()
      sel.selectAllChildren(pm)
      // insert paragraph by paragraph so ProseMirror creates real blocks
      const paras = text.split(/\n{2,}/)
      document.execCommand('insertText', false, paras[0] || '')
      for (let i = 1; i < paras.length; i++) {
        document.execCommand('insertParagraph')
        document.execCommand('insertText', false, paras[i])
      }
      return true
    } catch {
      return false
    }
  }

  // Parse the draft copied from 0nTask: "# Title\n\n_Subtitle_\n\nbody…"
  function parseDraft(raw) {
    const lines = raw.replace(/\r/g, '').split('\n')
    let title = '', subtitle = '', rest = raw
    if (lines[0]?.startsWith('# ')) {
      title = lines[0].slice(2).trim()
      let i = 1
      while (i < lines.length && !lines[i].trim()) i++
      if (/^_.*_$/.test(lines[i]?.trim() || '')) { subtitle = lines[i].trim().replace(/^_|_$/g, ''); i++ }
      while (i < lines.length && !lines[i].trim()) i++
      rest = lines.slice(i).join('\n').trim()
    }
    return { title, subtitle, body: rest }
  }

  async function fillFromClipboard(statusEl) {
    let raw = ''
    try { raw = await navigator.clipboard.readText() } catch { statusEl.textContent = 'Clipboard blocked — click the page first, then retry.'; return }
    if (!raw.trim()) { statusEl.textContent = 'Clipboard is empty. Copy your draft in 0nTask first.'; return }
    const { title, subtitle, body } = parseDraft(raw)
    let done = []
    const t = findTitle(); if (t && title) { setNativeValue(t, title); done.push('title') }
    const s = findSubtitle(); if (s && subtitle) { setNativeValue(s, subtitle); done.push('subtitle') }
    if (body && fillBody(body)) done.push('body')
    statusEl.textContent = done.length ? `Filled ${done.join(', ')}. Review & publish.` : 'Could not find the editor fields on this page.'
  }

  // ---- floating bar -------------------------------------------------------
  function mountBar() {
    if (document.getElementById('ontask-substack-bar') || !onEditor()) return
    const bar = document.createElement('div')
    bar.id = 'ontask-substack-bar'
    bar.style.cssText = [
      'position:fixed', 'right:18px', 'bottom:18px', 'z-index:2147483000',
      'display:flex', 'align-items:center', 'gap:10px',
      'background:#14171a', 'color:#eef4ef', 'border:1px solid rgba(22,163,74,.4)',
      'border-radius:14px', 'padding:10px 12px', 'box-shadow:0 10px 30px rgba(0,0,0,.4)',
      'font-family:Inter,system-ui,sans-serif', 'font-size:13px',
    ].join(';')
    bar.innerHTML =
      '<span style="display:flex;align-items:center;gap:6px;font-weight:700">' +
      '<span style="width:8px;height:8px;border-radius:50%;background:#16a34a;box-shadow:0 0 8px #16a34a"></span>0nTask</span>' +
      '<button id="ontask-fill" style="background:#16a34a;color:#fff;border:none;border-radius:9px;padding:7px 12px;font-weight:700;font-size:12.5px;cursor:pointer">Fill from clipboard</button>' +
      '<span id="ontask-status" style="color:#9fb4a8;max-width:220px"></span>' +
      '<button id="ontask-close" style="background:transparent;border:none;color:#7fa08e;cursor:pointer;font-size:16px;line-height:1">×</button>'
    document.body.appendChild(bar)
    const status = bar.querySelector('#ontask-status')
    bar.querySelector('#ontask-fill').addEventListener('click', () => fillFromClipboard(status))
    bar.querySelector('#ontask-close').addEventListener('click', () => bar.remove())
  }

  // Substack is an SPA — watch for the editor appearing.
  mountBar()
  const obs = new MutationObserver(() => mountBar())
  obs.observe(document.documentElement, { childList: true, subtree: true })
})()
