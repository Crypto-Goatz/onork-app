// ============================================================
// Content script — runs detectors on the current page, returns hits
// ============================================================
// Listens for { action: 'SCAN_RUN' } messages from the sidebar/service
// worker, runs the detector engine in the page context, and sends the
// hit list back. The scanner's network-host channel comes from the
// service worker (chrome.webRequest), already aggregated.
//
// THIS FILE IS A CLASSIC SCRIPT AND MUST STAY ONE.
//
// It is injected with chrome.scripting.executeScript({ files: [...] }), which
// has no module option — an `import` here is a SyntaxError at parse time. The
// script then never runs, this listener never registers, and the sendMessage
// that follows resolves to undefined, which the worker reports as the
// tragically uninformative "no response". That was the state of this file from
// the day it was written, so the Stack Scanner had never once worked.
//
// The engine arrives instead as `globalThis.__0nRunDetectors`, from the
// generated classic bundle injected immediately before this file. See
// scripts/build-detector-bundle.mjs.

if (!globalThis.__0nScanInjectorReady) {
  globalThis.__0nScanInjectorReady = true

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.action !== 'SCAN_RUN') return false
    try {
      const run = globalThis.__0nRunDetectors
      if (typeof run !== 'function') {
        // Name the real cause. A missing engine is a packaging fault, not a
        // page that happens to have nothing on it.
        sendResponse({ ok: false, error: 'Detector engine missing (bundle.js did not load) — rebuild the extension.' })
        return true
      }
      const { networkHosts = [] } = message.payload || {}
      const result = run({ networkHosts })
      sendResponse({
        ok: true,
        url: location.href,
        hostname: location.hostname,
        title: document.title,
        detected: result.by_category,
        hits: result.hits,
        ts: Date.now(),
      })
    } catch (e) {
      sendResponse({ ok: false, error: e?.message || String(e) })
    }
    return true // async response
  })
}
