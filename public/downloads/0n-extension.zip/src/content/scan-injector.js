// ============================================================
// Content script — runs detectors on the current page, returns hits
// ============================================================
// Listens for { action: 'SCAN_RUN' } messages from the sidebar/service
// worker, runs the detector engine in the page context, and sends the
// hit list back. The scanner's network-host channel comes from the
// service worker (chrome.webRequest), already aggregated.

import { runDetectors } from '../lib/detectors/index.js'

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.action !== 'SCAN_RUN') return false
  try {
    const { networkHosts = [] } = message.payload || {}
    const result = runDetectors({ networkHosts })
    sendResponse({
      ok: true,
      url: location.href,
      hostname: location.hostname,
      title: document.title,
      detected: result.by_category,
      hits: result.hits,
      ts: Date.now(),
    })
  } catch (e) {
    sendResponse({ ok: false, error: e?.message || String(e) })
  }
  return true // async response
})
