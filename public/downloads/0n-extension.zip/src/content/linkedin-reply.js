/**
 * LinkedIn message assistant — drafts the reply, never sends it.
 *
 * IT PUTS TEXT IN THE BOX AND STOPS. Pressing send is a human action, on
 * purpose: automated sending from an unapproved extension is what gets
 * LinkedIn accounts restricted, and that penalty lands on the agency and their
 * client. Drafting is the slow part and the part worth automating; the click
 * costs a second and keeps the account alive.
 *
 * IT READS THE THREAD, IT DOES NOT SCRAPE THE SITE. Only the conversation
 * currently open on screen — the message the user is already looking at and is
 * about to answer. Nothing is crawled, enumerated or stored in bulk.
 *
 * DOM SELECTORS ARE GUESSES AND ARE TREATED AS SUCH. LinkedIn changes its
 * markup without notice, so every lookup has fallbacks and every failure is
 * visible ("could not find the message box") rather than silent — a button
 * that quietly does nothing is worse than one that says it broke.
 */

const SEL = {
  // Most recent inbound bubble, in likely order of survival.
  incoming: [
    '.msg-s-event-listitem--other .msg-s-event-listitem__body',
    '.msg-s-event__content .msg-s-event-listitem__body',
    '[class*="msg-s-event-listitem"] p',
  ],
  box: [
    '.msg-form__contenteditable[contenteditable="true"]',
    'div[role="textbox"][contenteditable="true"]',
    '.msg-form__msg-content-container [contenteditable="true"]',
  ],
  name: ['.msg-entity-lockup__entity-title', '.msg-thread__link-to-profile', 'h2.msg-entity-lockup__entity-title'],
  headline: ['.msg-entity-lockup__entity-info', '.msg-entity-lockup__subtitle'],
}

const pick = (list) => {
  for (const s of list) {
    const els = document.querySelectorAll(s)
    if (els.length) return els[els.length - 1]
  }
  return null
}

const textOf = (el) => (el?.innerText || el?.textContent || '').trim()

function readThread() {
  const msgEl = pick(SEL.incoming)
  return {
    message: textOf(msgEl),
    name: textOf(pick(SEL.name)),
    headline: textOf(pick(SEL.headline)),
    profileUrl: location.href.split('?')[0],
  }
}

/**
 * Write into LinkedIn's contenteditable so its own editor notices.
 *
 * Setting textContent alone leaves the send button disabled — the editor tracks
 * state through input events, so the text appears and cannot be sent, which
 * looks exactly like the feature is broken.
 */
function insertDraft(text) {
  const box = pick(SEL.box)
  if (!box) return false
  box.focus()
  const p = box.querySelector('p') || box
  p.textContent = text
  box.dispatchEvent(new InputEvent('input', { bubbles: true, data: text, inputType: 'insertText' }))
  box.dispatchEvent(new Event('change', { bubbles: true }))
  return true
}

function toast(msg, bad = false) {
  const t = document.createElement('div')
  t.textContent = msg
  t.style.cssText = `position:fixed;bottom:20px;right:20px;z-index:99999;padding:10px 14px;
    border-radius:10px;font:600 13px/1.3 system-ui;color:${bad ? '#0d1117' : '#0d1117'};
    background:${bad ? '#e0a33a' : '#6EE05A'};box-shadow:0 6px 24px rgba(0,0,0,.35)`
  document.body.appendChild(t)
  setTimeout(() => t.remove(), 4000)
}

async function draftReply(btn) {
  const thread = readThread()
  if (!thread.message) { toast('Could not read the message — open the conversation first.', true); return }

  btn.disabled = true
  const original = btn.textContent
  btn.textContent = 'Drafting…'

  const res = await chrome.runtime.sendMessage({ type: 'LI_DRAFT_REPLY', thread }).catch(() => null)

  btn.disabled = false
  btn.textContent = original

  if (!res?.ok) { toast(res?.error || 'Could not draft a reply.', true); return }

  if (!insertDraft(res.draft)) {
    // Never lose the draft because the box moved. The clipboard is the fallback.
    navigator.clipboard?.writeText(res.draft).catch(() => {})
    toast('Message box not found — draft copied to your clipboard.', true)
    return
  }

  toast(res.emailFound ? 'Draft ready — they already gave an email.' : 'Draft ready — read it before sending.')

  // Offer the CRM push separately. It is a WRITE, so it goes to the panel for
  // approval rather than happening because a draft appeared.
  chrome.runtime.sendMessage({
    type: 'LI_OFFER_CONTACT',
    contact: res.contact,
  }).catch(() => {})
}

function mountButton() {
  if (document.getElementById('on-li-draft')) return
  const box = pick(SEL.box)
  if (!box) return

  const btn = document.createElement('button')
  btn.id = 'on-li-draft'
  btn.type = 'button'
  btn.textContent = '0n — Draft reply'
  btn.style.cssText = `position:fixed;bottom:20px;left:50%;transform:translateX(-50%);z-index:99998;
    padding:9px 16px;border:0;border-radius:999px;background:#6EE05A;color:#0d1117;
    font:700 13px system-ui;cursor:pointer;box-shadow:0 6px 20px rgba(0,0,0,.3)`
  btn.addEventListener('click', () => draftReply(btn))
  document.body.appendChild(btn)
}

// LinkedIn is a single-page app: the thread changes without a navigation, so a
// one-shot mount on load would attach to the first conversation and never again.
const obs = new MutationObserver(() => mountButton())
obs.observe(document.body, { childList: true, subtree: true })
mountButton()
