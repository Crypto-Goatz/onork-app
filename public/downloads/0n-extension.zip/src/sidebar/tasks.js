/**
 * The 0nTask panel — quick-add, list, complete, on the one 0n key.
 *
 * QUICK-ADD IS THE TOP OF THE PANEL AND IT IS ONE FIELD. The reason to put a
 * task list inside a browser side panel at all is that the thought arrives
 * while you are looking at something else; anything that makes capture cost
 * more than a sentence and Enter defeats the point. Priority, notes and the
 * rest live behind "More" — available, never in the way.
 *
 * OPEN TASKS FIRST, AND DONE ONES OUT OF SIGHT. The account here has 251 tasks.
 * A flat dump of all of them is a wall, so the default filter is what is still
 * outstanding and the list is capped, with the remainder one click away rather
 * than silently missing.
 *
 * WRITES ARE OPTIMISTIC AND ROLL BACK. A checkbox that waits ~400ms on a
 * network round trip before moving feels broken, so the row updates at once and
 * reverts loudly if the server refused. What it must never do is show a tick
 * for a write that failed.
 */
import { listTasks, createTask, completeTask, reopenTask, deleteTask, ONTASK_APP } from '../lib/ontask.js'

const $ = (sel, root = document) => root.querySelector(sel)
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
))

/** How many rows to draw before "show all". Kept well above a normal day's list. */
const PAGE = 40

let tasks = []
/**
 * Ids added from this panel in this session, pinned to the top of the list.
 *
 * WITHOUT THIS, ADDING A TASK LOOKS LIKE LOSING IT. The list is sorted by
 * priority and capped, and this account has 204 open tasks — so a new low-
 * priority one sorts to somewhere past row 40 and is not on screen at all. The
 * add succeeded, the server has it, and the panel appears to have swallowed it,
 * which is the single most alarming thing a capture box can do. Caught by the
 * end-to-end harness, 2026-08-19.
 *
 * Pinned, not re-sorted: the ordering is still priority-first for everything
 * else, and this only lasts as long as the panel is open.
 */
const justAdded = new Set()
let filter = 'open'   // open | done | all
let expanded = false  // is the More panel showing
let showAll = false
let loaded = false
let busy = false

export async function initTasks(root) {
  if (!root) return
  root.innerHTML = `
    <div class="ot">
      <form class="ot-add" id="ot-add">
        <div class="ot-row">
          <input id="ot-title" class="ot-input" placeholder="Add a task and press Enter" autocomplete="off" />
          <button type="submit" id="ot-submit" class="ot-btn">Add</button>
        </div>
        <button type="button" class="ot-more" id="ot-more" aria-expanded="false">More</button>
        <div class="ot-fields" id="ot-fields" hidden>
          <textarea id="ot-notes" class="ot-input" rows="2" placeholder="Notes"></textarea>
          <div class="ot-row">
            <select id="ot-priority" class="ot-input ot-select">
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="low">Low</option>
            </select>
            <input id="ot-category" class="ot-input" placeholder="Category" autocomplete="off" />
          </div>
          <div class="ot-row">
            <input id="ot-due" class="ot-input" type="date" />
            <label class="ot-check" title="Hand this to the AI instead of yourself">
              <input type="checkbox" id="ot-ai" /> <span>Assign to AI</span>
            </label>
          </div>
        </div>
      </form>

      <div class="ot-bar">
        <div class="ot-filters" role="tablist">
          <button class="ot-chip active" data-filter="open" role="tab">Open</button>
          <button class="ot-chip" data-filter="done" role="tab">Done</button>
          <button class="ot-chip" data-filter="all" role="tab">All</button>
        </div>
        <button class="ot-refresh" id="ot-refresh" title="Refresh from 0nTask" aria-label="Refresh">&#8635;</button>
      </div>

      <div id="ot-list" class="ot-list"><span class="ot-dim">Loading tasks&hellip;</span></div>
      <div class="ot-foot">
        <a href="${ONTASK_APP}" target="_blank" rel="noopener" class="ot-link">Open 0nTask &rarr;</a>
        <span class="ot-dim" id="ot-count"></span>
      </div>
    </div>`

  $('#ot-add', root).addEventListener('submit', (e) => { e.preventDefault(); onAdd() })
  $('#ot-more', root).addEventListener('click', toggleMore)
  $('#ot-refresh', root).addEventListener('click', () => load())

  root.querySelectorAll('.ot-chip').forEach((c) => {
    c.addEventListener('click', () => {
      filter = c.dataset.filter
      showAll = false
      root.querySelectorAll('.ot-chip').forEach((x) => x.classList.toggle('active', x === c))
      render()
    })
  })

  // One delegated listener rather than one per row: the list is re-rendered on
  // every change, and per-row handlers would leak with it.
  $('#ot-list', root).addEventListener('click', onListClick)

  // A right-click anywhere on the web fills the box in and focuses it. It does
  // NOT auto-submit — capturing a selection is the user's sentence to edit, and
  // a right-click that silently writes a record has no undo.
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'PANEL_ACTION' && msg.action === 'ontask-add') prefill(msg)
  })

  await drainPendingTask()
  await load()
}

/**
 * Take the prefill the context menu parked, if it is still fresh.
 *
 * WHY STORAGE AND NOT JUST THE MESSAGE. Right-clicking with the side panel shut
 * opens it and broadcasts in the same breath; the broadcast loses, because this
 * listener does not exist yet. The parked copy is the one that survives.
 *
 * WHY IT EXPIRES. A prefill that outlives its moment is worse than none: open
 * the panel next week and there is a sentence from an unrelated page sitting in
 * the box, one Enter away from becoming a task. Five minutes covers the panel
 * taking its time to open and nothing else.
 */
const PREFILL_TTL_MS = 5 * 60_000

async function drainPendingTask() {
  try {
    const { pendingTask } = await chrome.storage.local.get('pendingTask')
    if (!pendingTask) return
    await chrome.storage.local.remove('pendingTask')
    if (Date.now() - (pendingTask.at || 0) > PREFILL_TTL_MS) return
    prefill(pendingTask)
  } catch { /* no prefill is a fine outcome */ }
}

function prefill({ title, notes } = {}) {
  const box = $('#ot-title')
  if (!box) return
  // Never overwrite something already typed — the person in front of the panel
  // outranks a message from a menu click.
  if (title && !box.value.trim()) box.value = title
  if (notes) {
    const n = $('#ot-notes')
    if (n && !n.value.trim()) { n.value = notes; if (!expanded) toggleMore() }
  }
  box.focus()
  box.setSelectionRange(box.value.length, box.value.length)
}

function toggleMore() {
  expanded = !expanded
  $('#ot-fields').hidden = !expanded
  const b = $('#ot-more')
  b.textContent = expanded ? 'Less' : 'More'
  b.setAttribute('aria-expanded', expanded ? 'true' : 'false')
}

async function load() {
  const box = $('#ot-list')
  if (!box) return
  if (loaded) box.classList.add('ot-busy')
  const r = await listTasks()
  box.classList.remove('ot-busy')

  if (!r.ok) {
    loaded = false
    box.innerHTML = `<p class="ot-warn">${esc(r.error)}</p>${
      r.needsConnect
        ? `<p class="ot-dim">Connect this browser in Settings, or <a class="ot-link" href="${ONTASK_APP}" target="_blank" rel="noopener">sign in to 0nTask</a>.</p>`
        : ''}`
    $('#ot-count').textContent = ''
    return
  }
  tasks = Array.isArray(r.data?.tasks) ? r.data.tasks : []
  loaded = true
  render()
}

const isDone = (t) => String(t?.status || '').toLowerCase() === 'completed'

/** High first, then medium, then low — within that, newest id first. */
const RANK = { high: 0, medium: 1, low: 2 }
function sortOpen(a, b) {
  const d = (RANK[a.priority] ?? 1) - (RANK[b.priority] ?? 1)
  return d !== 0 ? d : String(b.id).localeCompare(String(a.id))
}

function visible() {
  const rows = tasks.filter((t) => (filter === 'all' ? true : filter === 'done' ? isDone(t) : !isDone(t)))
  rows.sort(filter === 'done' ? (a, b) => String(b.id).localeCompare(String(a.id)) : sortOpen)
  if (!justAdded.size) return rows
  const mine = rows.filter((t) => justAdded.has(String(t.id)))
  return mine.length ? [...mine, ...rows.filter((t) => !justAdded.has(String(t.id)))] : rows
}

function render() {
  const box = $('#ot-list')
  if (!box) return
  const rows = visible()
  const open = tasks.filter((t) => !isDone(t)).length

  $('#ot-count').textContent = tasks.length
    ? `${open} open · ${tasks.length} total`
    : ''

  if (!rows.length) {
    box.innerHTML = `<p class="ot-dim">${
      filter === 'done' ? 'Nothing completed yet.'
      : filter === 'open' ? 'Nothing outstanding. Add one above.'
      : 'No tasks yet. Add one above.'}</p>`
    return
  }

  const shown = showAll ? rows : rows.slice(0, PAGE)
  box.innerHTML = shown.map(row).join('') + (
    rows.length > shown.length
      ? `<button class="ot-showall" data-act="showall">Show all ${rows.length}</button>`
      : '')
}

function row(t) {
  const done = isDone(t)
  const meta = [
    t.priority && t.priority !== 'medium' ? t.priority : '',
    t.category || '',
    t.project || '',
    t.dueDate ? `due ${String(t.dueDate).slice(0, 10)}` : '',
    t.assignee === 'ai' ? 'AI' : '',
  ].filter(Boolean)

  return `
    <div class="ot-task${done ? ' done' : ''}" data-id="${esc(t.id)}">
      <button class="ot-tick${done ? ' on' : ''}" data-act="toggle"
        aria-label="${done ? 'Reopen' : 'Complete'}" title="${done ? 'Reopen' : 'Complete'}">${done ? '&#10003;' : ''}</button>
      <div class="ot-body">
        <div class="ot-title">${esc(t.title || '(untitled)')}</div>
        ${t.notes ? `<div class="ot-notes">${esc(t.notes)}</div>` : ''}
        ${meta.length ? `<div class="ot-meta">${meta.map((m) => `<span class="ot-tag${
          m === 'high' ? ' high' : m === 'AI' ? ' ai' : ''}">${esc(m)}</span>`).join('')}</div>` : ''}
      </div>
      <button class="ot-del" data-act="delete" aria-label="Delete" title="Delete">&times;</button>
    </div>`
}

async function onListClick(e) {
  const btn = e.target.closest('[data-act]')
  if (!btn) return

  if (btn.dataset.act === 'showall') { showAll = true; render(); return }

  const el = btn.closest('.ot-task')
  const id = el?.dataset.id
  const t = tasks.find((x) => String(x.id) === String(id))
  if (!t || busy) return

  if (btn.dataset.act === 'toggle') return onToggle(t)
  if (btn.dataset.act === 'delete') return onDelete(t)
}

async function onToggle(t) {
  const was = t.status
  const next = isDone(t) ? 'todo' : 'completed'
  busy = true
  t.status = next            // optimistic — the row moves now
  render()

  const r = next === 'completed' ? await completeTask(t.id) : await reopenTask(t.id)
  busy = false

  if (!r.ok) {
    t.status = was           // put it back; a false tick is worse than a slow one
    render()
    warn(r.error)
    return
  }
  // Trust the server's row over ours: it may have normalised or changed fields
  // we did not send, and drifting from it is how a stale panel starts lying.
  if (r.data?.task) Object.assign(t, r.data.task)
  render()
}

async function onDelete(t) {
  // Deletion is the one irreversible action in this panel, so it asks.
  if (!confirm(`Delete "${t.title || 'this task'}"? This cannot be undone.`)) return
  busy = true
  const r = await deleteTask(t.id)
  busy = false
  if (!r.ok) { warn(r.error); return }
  tasks = tasks.filter((x) => String(x.id) !== String(t.id))
  render()
}

async function onAdd() {
  if (busy) return
  const titleEl = $('#ot-title')
  const title = titleEl.value.trim()
  if (!title) { titleEl.focus(); return }

  const btn = $('#ot-submit')
  busy = true
  btn.disabled = true
  btn.textContent = 'Adding…'

  const r = await createTask({
    title,
    notes: $('#ot-notes').value.trim(),
    priority: $('#ot-priority').value,
    category: $('#ot-category').value.trim(),
    dueDate: $('#ot-due').value,
    assignee: $('#ot-ai').checked ? 'ai' : '',
  })

  busy = false
  btn.disabled = false
  btn.textContent = 'Add'

  if (!r.ok) {
    // The typed title stays in the box. Clearing it on failure would throw away
    // the one thing the user actually wrote.
    warn(r.error)
    return
  }

  titleEl.value = ''
  $('#ot-notes').value = ''
  $('#ot-category').value = ''
  $('#ot-due').value = ''
  $('#ot-ai').checked = false
  titleEl.focus()

  if (r.data?.task) {
    tasks.unshift(r.data.task)
    justAdded.add(String(r.data.task.id))
  }
  // Land on a filter that can actually show it. Adding from the Done tab and
  // being shown nothing is the same disappearing act by another route.
  if (filter === 'done') { filter = 'open'; syncChips() }
  render()

  // The API writes to Supabase and mirrors to the store the app reads. A mirror
  // failure means the task exists but will not show up in 0nTask itself — the
  // server reports that honestly, so we pass it on rather than saying "Added".
  if (r.data?.synced_to_app === false) {
    warn('Saved, but it has not reached the 0nTask app yet.')
  }
}

function syncChips() {
  document.querySelectorAll('.ot-chip').forEach((x) => x.classList.toggle('active', x.dataset.filter === filter))
}

function warn(message) {
  const box = $('#ot-list')
  if (!box) return
  box.insertAdjacentHTML('afterbegin', `<p class="ot-warn">${esc(message)}</p>`)
  setTimeout(() => box.querySelector('.ot-warn')?.remove(), 6000)
}
