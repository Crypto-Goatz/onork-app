/**
 * The CRM panel — one brain dump, many tasks, many clients.
 *
 * THE APPROVAL STEP IS THE PRODUCT, so it is the loudest thing on screen. The
 * plan comes back grouped BY CLIENT rather than as a flat list, because the
 * question a person actually has before approving is never "how many steps" —
 * it is "which of my clients is this about to touch". A leg pointed at the
 * wrong account is invisible in a flat list and obvious in a grouped one.
 *
 * NOTHING RUNS WITHOUT A SIGNED PLAN. If the planner could not sign (no
 * session, or no runnable legs) the Approve button never appears — rather than
 * appearing and failing, which would teach people to click it twice.
 */
import { listClients, planCommand, runPlan, listReceipts, groupLegsByClient, lookupContact } from '../lib/oncore.js'

const $ = (sel, root = document) => root.querySelector(sel)
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
))

let clients = []
let plan = null      // { legs, planToken, runnableCount }
let busy = false

export async function initCrm(root) {
  if (!root) return
  root.innerHTML = `
    <div class="crm">
      <div class="crm-clients" id="crm-clients"><span class="crm-dim">Loading clients…</span></div>

      <label class="crm-label" for="crm-find">Find a person</label>
      <div class="crm-row">
        <input id="crm-find" class="crm-input" placeholder="Name, email or phone" autocomplete="off" />
      </div>
      <div id="crm-hits"></div>
      <div class="crm-sep"></div>

      <label class="crm-label" for="crm-command">What needs doing?</label>
      <textarea id="crm-command" class="crm-input" rows="5"
        placeholder="Tag every lead from the Harbor Dental webinar as warm, book Tom a call for Thursday, and send the In2sight list this week's recap."></textarea>
      <p class="crm-hint">Name your clients in the sentence. One dump can cover several at once.</p>

      <div class="crm-row">
        <button id="crm-plan" class="crm-btn">Plan it</button>
        <button id="crm-clear" class="crm-btn ghost">Clear</button>
      </div>

      <div id="crm-out"></div>
      <div class="crm-sep"></div>
      <div class="crm-label">Recent</div>
      <div id="crm-receipts"><span class="crm-dim">—</span></div>
    </div>`

  $('#crm-plan', root).addEventListener('click', onPlan)

  // Debounced so a name typed at speed is one request, not eight.
  let t = null
  $('#crm-find', root).addEventListener('input', (e) => {
    clearTimeout(t)
    const q = e.target.value.trim()
    if (q.length < 2) { $('#crm-hits', root).innerHTML = ''; return }
    t = setTimeout(() => runLookup(q), 300)
  })

  // A right-click elsewhere on the page fills this panel in.
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type !== 'PANEL_ACTION') return
    if (msg.action === 'crm-command' && msg.command) {
      $('#crm-command', root).value = msg.command
      onPlan()
    }
    if (msg.action === 'crm-lookup' && msg.query) {
      $('#crm-find', root).value = msg.query
      runLookup(msg.query)
    }
  })
  $('#crm-clear', root).addEventListener('click', () => {
    plan = null
    $('#crm-command', root).value = ''
    $('#crm-out', root).innerHTML = ''
  })

  await Promise.all([loadClients(), loadReceipts()])
}

async function loadClients() {
  const box = $('#crm-clients')
  const r = await listClients()
  if (!r.ok) {
    box.innerHTML = r.needsConnect
      ? `<span class="crm-warn">Not connected. Open Settings and connect this browser.</span>`
      : `<span class="crm-warn">${esc(r.error)}</span>`
    return
  }
  clients = r.data.clients || r.data.accounts || []
  const connected = clients.filter((c) => c.connected !== false)
  if (!connected.length) {
    box.innerHTML = `<span class="crm-warn">No clients connected yet — add a client key in 0nCORE first.</span>`
    return
  }
  box.innerHTML = connected
    .map((c) => `<span class="crm-chip${c.isFree ? ' free' : ''}">${esc(c.name || c.locationId)}</span>`)
    .join('')
}

async function onPlan() {
  if (busy) return
  const command = $('#crm-command').value.trim()
  const out = $('#crm-out')
  if (!command) { out.innerHTML = `<p class="crm-warn">Say what you want done.</p>`; return }

  busy = true
  out.innerHTML = `<p class="crm-dim">Planning…</p>`
  const r = await planCommand(command)
  busy = false

  if (!r.ok) {
    out.innerHTML = r.needsConnect
      ? `<p class="crm-warn">This browser is not connected to 0nCORE. Open Settings to connect it.</p>`
      : `<p class="crm-warn">${esc(r.error)}</p>`
    return
  }

  plan = r.data
  const legs = plan.legs || []
  if (!legs.length) {
    // The planner's own explanation, not a generic failure — it usually says
    // the client was not named or is not connected, which is fixable.
    out.innerHTML = `<p class="crm-warn">${esc(plan.message || 'Nothing runnable in that. Try naming the client.')}</p>`
    return
  }

  const groups = groupLegsByClient(legs, clients)
  const canRun = Boolean(plan.planToken) && (plan.runnableCount ?? legs.length) > 0

  out.innerHTML = `
    <div class="crm-plan">
      <div class="crm-planhead">
        <strong>${legs.length} step${legs.length === 1 ? '' : 's'}</strong>
        <span class="crm-dim">across ${groups.length} account${groups.length === 1 ? '' : 's'}</span>
      </div>
      ${groups.map((g) => `
        <div class="crm-group">
          <div class="crm-gname">${esc(g.name)}</div>
          ${g.legs.map((l) => `
            <div class="crm-leg">
              <span class="crm-cap">${esc(l.capability || '')}</span>
              <span>${esc(l.intent || '')}</span>
            </div>`).join('')}
        </div>`).join('')}
      ${canRun
        ? `<button id="crm-run" class="crm-btn run">Approve &amp; run</button>`
        : `<p class="crm-warn">This plan cannot be run from here — it was not signed. Open 0nCORE inside your CRM.</p>`}
    </div>`

  if (canRun) $('#crm-run').addEventListener('click', onRun)
}

async function onRun() {
  if (busy || !plan?.planToken) return
  busy = true
  const btn = $('#crm-run')
  btn.disabled = true
  btn.textContent = 'Running…'

  const r = await runPlan(plan.planToken)
  busy = false

  const out = $('#crm-out')
  if (!r.ok) {
    // A refused run leaves the plan on screen. Wiping it would make the user
    // retype the paragraph to try again.
    btn.disabled = false
    btn.textContent = 'Approve & run'
    out.insertAdjacentHTML('beforeend', `<p class="crm-warn">${esc(r.error)}</p>`)
    return
  }

  const results = r.data.results || r.data.legs || []
  const okCount = results.filter((x) => x.status === 'ok').length
  out.innerHTML = `
    <div class="crm-plan">
      <div class="crm-planhead"><strong>Done</strong>
        <span class="crm-dim">${okCount} of ${results.length || '—'} succeeded</span></div>
      ${results.map((x) => `
        <div class="crm-leg">
          <span class="crm-cap ${x.status === 'ok' ? 'ok' : 'bad'}">${esc(x.status || '')}</span>
          <span>${esc(x.detail || x.intent || '')}</span>
        </div>`).join('')}
    </div>`
  plan = null
  loadReceipts()
}

async function loadReceipts() {
  const box = $('#crm-receipts')
  if (!box) return
  const r = await listReceipts()
  if (!r.ok) { box.innerHTML = `<span class="crm-dim">—</span>`; return }
  const rows = (r.data.receipts || []).slice(0, 6)
  box.innerHTML = rows.length
    ? rows.map((x) => `
        <div class="crm-leg">
          <span class="crm-cap ${x.status === 'ok' ? 'ok' : 'bad'}">${esc(x.status || '')}</span>
          <span>${esc(x.intent || x.capability || '')}</span>
        </div>`).join('')
    : `<span class="crm-dim">Nothing yet.</span>`
}

export async function runLookup(q) {
  const box = document.getElementById('crm-hits')
  if (!box) return
  box.innerHTML = `<span class="crm-dim">Searching…</span>`
  const r = await lookupContact(q)
  if (!r.ok) {
    box.innerHTML = r.needsConnect
      ? `<span class="crm-warn">Not connected. Open Settings.</span>`
      : `<span class="crm-warn">${esc(r.error)}</span>`
    return
  }
  const hits = r.data.hits || []
  if (!hits.length) {
    // Says where it looked. "No results" without a scope reads as broken.
    box.innerHTML = `<span class="crm-dim">${esc(r.data.note || `No match across ${r.data.searched} account(s).`)}</span>`
    return
  }
  box.innerHTML = hits.map((h) => `
    <div class="crm-hit">
      <div class="crm-hitname">${esc(h.name)}</div>
      <div class="crm-hitmeta">${esc(h.email || h.phone || '—')}</div>
      <span class="crm-chip">${esc(h.locationName)}</span>
    </div>`).join('')
}
