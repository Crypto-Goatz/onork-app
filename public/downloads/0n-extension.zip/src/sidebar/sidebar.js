// ═══ 0n Sidebar — v5 (5-tab redesign) ═══
// Tabs: Home · LinkedIn · Compose · Flows · Settings
// Always-visible Jaxx input · token auth · live data via service worker.

// ───────────────────────────────────────────────────────
// helpers
// ───────────────────────────────────────────────────────

import { initCrm } from './crm.js'
import { initTasks } from './tasks.js'

const $ = (sel, root = document) => root.querySelector(sel)
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel))

function send(action, payload = {}, extra = {}) {
  return chrome.runtime.sendMessage({ action, payload, ...extra })
}

function toast(msg, kind = '') {
  const el = $('#toast')
  if (!el) return
  el.textContent = msg
  el.className = `toast ${kind}`
  el.hidden = false
  clearTimeout(toast._t)
  toast._t = setTimeout(() => { el.hidden = true }, 2400)
}

function setStatus(label, ok) {
  $('#statusDot').classList.toggle('offline', !ok)
  const t = $('#statusText')
  t.textContent = label
  t.classList.toggle('offline', !ok)
}

const state = {
  authed: false,
  user: null,
  flow: [],   // { id, type, label }
  saved: [],  // saved flows
  compose: { tone: 'professional', hook: 'declaration', type: 'post' },
  liType: 'post',
  currentProfile: null,
}

// ───────────────────────────────────────────────────────
// auth
// ───────────────────────────────────────────────────────

async function ensureAuth() {
  try {
    const res = await send('AUTH_CHECK')
    if (res?.authed) {
      state.authed = true
      state.user = res.user || null
      $('#authScreen').hidden = true
      $('#appShell').hidden = false
      return true
    }
  } catch {}
  // ── The glue: if the extension captured your 0n token while you were signed
  // into your 0n account on the web (0nmcp.com / 0ncore.com), connect silently —
  // no pasting. This is what patches the whole ecosystem together.
  try {
    const { on_token } = await chrome.storage.local.get('on_token')
    if (on_token) {
      const inp = $('#authToken')
      if (inp) inp.value = on_token
      await authConnect()
      if (state.authed) return true
    }
  } catch {}
  $('#authScreen').hidden = false
  $('#appShell').hidden = true
  return false
}

async function authConnect() {
  const tokenInput = $('#authToken').value.trim()
  if (!tokenInput) return
  const err = $('#authError')
  err.hidden = true
  $('#authConnect').disabled = true
  $('#authConnect').textContent = 'Connecting...'
  try {
    const res = await send('AUTH_LOGIN', { token: tokenInput })
    if (res?.ok) {
      state.authed = true
      state.user = res.user || null
      $('#authScreen').hidden = true
      $('#appShell').hidden = false
      await refreshAll()
    } else {
      err.textContent = res?.error || 'Token rejected'
      err.hidden = false
    }
  } catch (e) {
    err.textContent = e.message || 'Connection failed'
    err.hidden = false
  } finally {
    $('#authConnect').disabled = false
    $('#authConnect').textContent = 'Connect'
  }
}

async function signOut() {
  await send('AUTH_LOGOUT').catch(() => {})
  state.authed = false
  state.user = null
  $('#authScreen').hidden = false
  $('#appShell').hidden = true
}

// ───────────────────────────────────────────────────────
// tabs
// ───────────────────────────────────────────────────────

function switchTab(name) {
  $$('.tab').forEach((t) => {
    const on = t.dataset.tab === name
    t.classList.toggle('active', on)
    t.setAttribute('aria-selected', on ? 'true' : 'false')
  })
  $$('.tab-pane').forEach((p) => {
    p.classList.toggle('active', p.dataset.pane === name)
  })
  $('.content').scrollTop = 0
}

// ───────────────────────────────────────────────────────
// home tab
// ───────────────────────────────────────────────────────

async function loadHome() {
  // stats
  try {
    const res = await send('ANALYTICS_GET')
    const a = res?.analytics || {}
    if (a.vpisAvg != null) $('#statVPIS').textContent = Math.round(a.vpisAvg)
    if (a.postsCount != null) $('#statPosts').textContent = a.postsCount
    if (a.leadsCount != null) $('#statLeads').textContent = a.leadsCount
  } catch {}
  // active flow preview from the saved-flow array
  renderActiveFlowPreview()
}

function renderActiveFlowPreview() {
  const pillRoot = $('#activeFlowPills')
  const countEl = $('#activeFlowCount')
  const exec = $('#activeFlowExecute')
  if (!state.flow.length) {
    pillRoot.innerHTML = '<span class="flow-empty">No flow loaded</span>'
    countEl.textContent = 'Build one in the Flows tab'
    exec.disabled = true
    return
  }
  const colorByType = { contacts: 'green', filter: 'blue', email: 'amber', sms: 'amber', linkedin: 'blue', ai: 'purple', delay: 'purple', webhook: 'purple' }
  const pills = state.flow
    .map((b) => `<span class="flow-pill ${colorByType[b.type] || 'green'}">${escapeHtml(b.label || b.type)}</span>`)
    .join('<svg class="flow-arrow" viewBox="0 0 24 24" fill="none"><path d="M5 12h14M13 5l7 7-7 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>')
  pillRoot.innerHTML = pills
  countEl.textContent = `${state.flow.length} block${state.flow.length === 1 ? '' : 's'}`
  exec.disabled = false
}

function bindHome() {
  $$('.action-card').forEach((card) => {
    card.addEventListener('click', () => {
      const a = card.dataset.action
      if (a === 'open-tab') switchTab(card.dataset.tab)
      else if (a === 'scrape') { switchTab('linkedin'); $('#liScrapeBtn').click() }
      else if (a === 'score-text') { switchTab('compose'); $('#composePrompt').focus() }
    })
  })
  $('#activeFlowExecute').addEventListener('click', executeActiveFlow)
}

// ───────────────────────────────────────────────────────
// linkedin tab
// ───────────────────────────────────────────────────────

async function loadLinkedIn() {
  try {
    const res = await send('LEADS_GET')
    if (res?.leads) renderLeads(res.leads)
  } catch {}
}

function renderLeads(leads) {
  $('#liLeadCount').textContent = leads.length
  const list = $('#liLeadList')
  if (!leads.length) {
    list.innerHTML = '<div class="activity-empty">No leads saved yet.</div>'
    return
  }
  list.innerHTML = leads
    .slice(0, 50)
    .map((l) => `<div class="lead-row"><span>${escapeHtml(l.name || 'Unknown')}</span><span class="meta">${escapeHtml(l.headline ? l.headline.slice(0, 30) : '')}</span></div>`)
    .join('')
}

function bindLinkedIn() {
  $('#liScrapeBtn').addEventListener('click', async () => {
    setStatus('Scraping...', true)
    try {
      const res = await send('SCRAPE_PROFILE')
      if (res?.profile) {
        state.currentProfile = res.profile
        $('#liProfileCard').hidden = false
        $('#liProfileName').textContent = res.profile.name || 'Unknown'
        $('#liProfileHeadline').textContent = res.profile.headline || ''
        $('#liProfileMeta').textContent = [res.profile.location, res.profile.company].filter(Boolean).join(' · ')
        toast('Profile scraped', 'success')
      } else {
        toast(res?.error || 'No profile detected', 'error')
      }
    } catch (e) {
      toast(e.message || 'Scrape failed', 'error')
    } finally {
      setStatus('Connected', true)
    }
  })

  $('#liSaveLead').addEventListener('click', async () => {
    if (!state.currentProfile) return
    const r = await send('LEAD_SAVE', { lead: state.currentProfile })
    if (r?.ok) { toast('Lead saved', 'success'); loadLinkedIn() } else { toast('Save failed', 'error') }
  })

  $('#liComposeFor').addEventListener('click', () => {
    if (!state.currentProfile) return
    switchTab('compose')
    $('#composePrompt').value = `A LinkedIn DM to ${state.currentProfile.name} (${state.currentProfile.headline})`
    $('#composePrompt').focus()
  })

  $('#liCrmPush').addEventListener('click', async () => {
    if (!state.currentProfile) return
    const r = await send('CRM_SAVE', { profile: state.currentProfile })
    toast(r?.ok ? 'Pushed to CRM' : 'CRM push failed', r?.ok ? 'success' : 'error')
  })

  $('#liExportLeads').addEventListener('click', async () => {
    const r = await send('LEADS_GET')
    if (!r?.leads?.length) return toast('No leads to export', 'error')
    const csv = ['name,headline,company,location,url']
      .concat(r.leads.map((l) => [l.name, l.headline, l.company, l.location, l.url].map((v) => `"${(v || '').replace(/"/g, '""')}"`).join(',')))
      .join('\n')
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }))
    const a = document.createElement('a')
    a.href = url; a.download = `0n-leads-${Date.now()}.csv`; a.click()
    URL.revokeObjectURL(url)
    toast('CSV exported', 'success')
  })

  $('#liSyncLeads').addEventListener('click', async () => {
    const r = await send('LEADS_GET')
    if (!r?.leads?.length) return toast('No leads to sync', 'error')
    let ok = 0
    for (const lead of r.leads) {
      const sr = await send('CRM_SAVE', { profile: lead })
      if (sr?.ok) ok++
    }
    toast(`Synced ${ok}/${r.leads.length} to CRM`, ok ? 'success' : 'error')
  })

  $('#liScanFeed').addEventListener('click', async () => {
    const r = await send('SCRAPE_FEED').catch(() => null)
    if (!r?.posts?.length) return toast('No feed posts detected', 'error')
    $('#liFeedList').innerHTML = r.posts
      .slice(0, 10)
      .map((p) => `<div class="lead-row"><span>${escapeHtml(p.author || 'Unknown')}</span><span class="meta c-green">${p.score || ''}</span></div>`)
      .join('')
  })

  $$('#liContentTypes .pill').forEach((p) => {
    p.addEventListener('click', () => {
      $$('#liContentTypes .pill').forEach((x) => x.classList.remove('active'))
      p.classList.add('active')
      state.liType = p.dataset.type
    })
  })
}

// ───────────────────────────────────────────────────────
// compose tab
// ───────────────────────────────────────────────────────

function bindCompose() {
  $$('.pill-row').forEach((row) => {
    if (!row.dataset.pillgroup) return
    row.querySelectorAll('.pill').forEach((p) => {
      p.addEventListener('click', () => {
        row.querySelectorAll('.pill').forEach((x) => x.classList.remove('active'))
        p.classList.add('active')
        state.compose[row.dataset.pillgroup] = p.dataset.value
      })
    })
  })
  $('#composeType').addEventListener('change', (e) => { state.compose.type = e.target.value })

  $('#composeGenerate').addEventListener('click', async () => {
    const topic = $('#composePrompt').value.trim()
    if (!topic) return toast('Type a prompt first', 'error')
    $('#composeGenerate').disabled = true
    $('#composeGenerate').textContent = 'Generating...'
    try {
      const res = await send('AI_COMPOSE', {
        type: state.compose.type,
        tone: state.compose.tone,
        hook: state.compose.hook,
        topic,
      })
      if (res?.text) {
        $('#composeOutput').hidden = false
        $('#composeText').value = res.text
        const score = Math.max(0, Math.min(100, res.vpis ?? 0))
        $('#composeVpisNum').textContent = score
        const fill = $('#composeVpisFill')
        fill.style.width = `${score}%`
        fill.className = 'vpis-fill ' + (score >= 80 ? 'high' : score >= 60 ? 'mid' : 'low')
        $('#composePatterns').innerHTML = (res.patterns || [])
          .slice(0, 6)
          .map((p) => `<span class="pattern-tag">${escapeHtml(p)}</span>`)
          .join('')
      } else {
        toast(res?.error || 'Generation failed', 'error')
      }
    } catch (e) {
      toast(e.message || 'Generation failed', 'error')
    } finally {
      $('#composeGenerate').disabled = false
      $('#composeGenerate').textContent = 'Generate — targets 85+ VPIS'
    }
  })

  $$('[data-cmpaction]').forEach((b) => {
    b.addEventListener('click', () => composeAction(b.dataset.cmpaction))
  })
}

async function composeAction(a) {
  const text = $('#composeText').value.trim()
  if (!text) return
  if (a === 'copy') {
    await navigator.clipboard.writeText(text); toast('Copied', 'success'); return
  }
  if (a === 'insert') {
    const r = await send('TEXT_INSERT', { text }).catch(() => null)
    toast(r?.ok ? 'Inserted' : 'Could not insert here', r?.ok ? 'success' : 'error'); return
  }
  if (a === 'queue') {
    const queueRes = await send('QUEUE_GET')
    const queue = queueRes?.queue || []
    queue.push({ id: Date.now(), text, type: state.compose.type, createdAt: new Date().toISOString() })
    await send('QUEUE_SAVE', { queue })
    toast('Queued', 'success'); return
  }
  if (a === 'regenerate') { $('#composeGenerate').click() }
}

// ───────────────────────────────────────────────────────
// flows tab
// ───────────────────────────────────────────────────────

function bindFlows() {
  $$('#flowBlockStrip .block-chip').forEach((c) => {
    c.addEventListener('click', () => addBlock(c.dataset.block))
  })
  $('#flowExecute').addEventListener('click', executeActiveFlow)
  $('#flowClear').addEventListener('click', () => { state.flow = []; renderFlowStack(); renderActiveFlowPreview() })
  $('#flowSave').addEventListener('click', saveFlow)
}

function addBlock(type) {
  const labels = {
    contacts: 'All contacts', filter: 'No filter set', email: 'Pick template',
    sms: 'Pick template', linkedin: 'Connect / DM', ai: 'Pick model',
    delay: 'Pick duration', webhook: 'Set URL',
  }
  state.flow.push({ id: crypto.randomUUID(), type, label: labels[type] || type })
  renderFlowStack()
  renderActiveFlowPreview()
}

function renderFlowStack() {
  const stack = $('#flowStack')
  if (!state.flow.length) { stack.innerHTML = ''; return }
  stack.innerHTML = state.flow
    .map((b, i) => `
      <div class="flow-block" data-id="${b.id}">
        <button class="block-remove" data-rm="${b.id}" aria-label="Remove">&times;</button>
        <div class="block-type">${escapeHtml(b.type)}</div>
        <div class="block-value">${escapeHtml(b.label)}</div>
        ${b.status ? `<span class="block-status">${b.status === 'ok' ? '✓' : b.status === 'fail' ? '✗' : '…'}</span>` : ''}
      </div>
      ${i < state.flow.length - 1 ? '<div class="flow-connector"></div>' : ''}
    `)
    .join('')
  stack.querySelectorAll('[data-rm]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation()
      state.flow = state.flow.filter((b) => b.id !== btn.dataset.rm)
      renderFlowStack()
      renderActiveFlowPreview()
    })
  })
}

async function saveFlow() {
  if (!state.flow.length) return toast('Nothing to save', 'error')
  const name = prompt('Name this flow:')
  if (!name) return
  state.saved.push({ id: crypto.randomUUID(), name, blocks: structuredClone(state.flow), savedAt: Date.now() })
  await chrome.storage.local.set({ oc_savedFlows: state.saved }).catch(() => {})
  renderSavedFlows()
  toast('Flow saved', 'success')
}

async function loadSavedFlows() {
  const r = await chrome.storage.local.get('oc_savedFlows').catch(() => ({}))
  state.saved = r.oc_savedFlows || []
  renderSavedFlows()
}

function renderSavedFlows() {
  const list = $('#savedFlows')
  if (!state.saved.length) { list.innerHTML = '<div class="activity-empty">No saved flows.</div>'; return }
  list.innerHTML = state.saved
    .map((f) => `<div class="saved-flow-row" data-load="${f.id}"><span class="name">${escapeHtml(f.name)}</span><span class="meta">${f.blocks.length} blocks</span></div>`)
    .join('')
  list.querySelectorAll('[data-load]').forEach((row) => {
    row.addEventListener('click', () => {
      const f = state.saved.find((x) => x.id === row.dataset.load)
      if (!f) return
      state.flow = structuredClone(f.blocks)
      renderFlowStack()
      renderActiveFlowPreview()
      toast(`Loaded "${f.name}"`, 'success')
    })
  })
}

async function executeActiveFlow() {
  if (!state.flow.length) return toast('No flow to execute', 'error')
  toast('Executing flow...', 'success')
  try {
    const res = await send('FLOW_EXECUTE', { flow: state.flow })
    if (res?.ok) {
      // mark each block status
      state.flow = state.flow.map((b, i) => ({ ...b, status: res.results?.[i]?.success ? 'ok' : 'fail' }))
      renderFlowStack()
      renderActiveFlowPreview()
      toast('Flow done', 'success')
    } else {
      toast(res?.error || 'Flow failed', 'error')
    }
  } catch (e) {
    toast(e.message || 'Flow failed', 'error')
  }
}

// ───────────────────────────────────────────────────────
// settings tab
// ───────────────────────────────────────────────────────

async function loadSettings() {
  if (state.user) {
    $('#setName').textContent = state.user.name || state.user.full_name || '—'
    $('#setEmail').textContent = state.user.email || '—'
    $('#setPlan').textContent = (state.user.plan || 'FREE').toUpperCase()
    $('#planBadge').textContent = (state.user.plan || 'FREE').toUpperCase()
    if (state.user.token) $('#setToken').textContent = state.user.token.slice(0, 12) + '…'
  }
  // connected services
  try {
    const r = await send('SETTINGS_GET')
    const conns = r?.connections || { crm: true, stripe: true, slack: true, wordpress: false, github: false }
    renderConnections(conns)
    if (r?.linkedin) {
      $('#setLiAuto').checked = !!r.linkedin.auto_post
      $('#setLiVoice').value = r.linkedin.voice || 'vibe'
    }
    const v = await send('VOICE_GET')
    if (v?.voice) {
      $('#setVoiceApproved').textContent = v.voice.approved_count || 0
      $('#setVoiceCorr').textContent = v.voice.corrections_count || 0
    }
  } catch {}
}

function renderConnections(c) {
  const items = ['crm', 'stripe', 'slack', 'wordpress', 'github', 'twitter']
  $('#connectGrid').innerHTML = items
    .map((k) => {
      const on = !!c[k]
      const label = k.charAt(0).toUpperCase() + k.slice(1)
      return `<div class="connect-item ${on ? 'on' : 'off'}"><span class="connect-mark">${on ? '✓' : '✗'}</span>${label}</div>`
    })
    .join('')
}

function bindSettings() {
  $('#setLiAuto').addEventListener('change', (e) => {
    send('SETTINGS_SAVE', { linkedin: { auto_post: e.target.checked } }).catch(() => {})
  })
  $('#setLiVoice').addEventListener('change', (e) => {
    send('SETTINGS_SAVE', { linkedin: { voice: e.target.value } }).catch(() => {})
  })
  $('#setVoiceEdit').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://0ncore.com/dashboard/voice' })
  })
  $('#setSignOut').addEventListener('click', signOut)
}

// ───────────────────────────────────────────────────────
// jaxx input
// ───────────────────────────────────────────────────────

function bindJaxx() {
  const input = $('#jaxxInput')
  const send_btn = $('#jaxxSend')
  const submit = async () => {
    const q = input.value.trim()
    if (!q) return
    input.value = ''
    send_btn.disabled = true
    toast('Asking Jaxx...', '')
    try {
      const res = await send('JAXX_COMMAND', { prompt: q, context: { tab: currentTab() } })
      if (res?.ok) {
        if (res.action?.type === 'open-tab') switchTab(res.action.tab)
        if (res.action?.type === 'add-block') addBlock(res.action.block)
        if (res.message) toast(res.message.slice(0, 200), 'success')
      } else {
        // fallback for environments without JAXX_COMMAND wired in service worker
        const fallback = await send('GENERATE', { prompt: q }).catch(() => null)
        toast((fallback?.text || 'Jaxx is offline').slice(0, 200), fallback?.text ? 'success' : 'error')
      }
    } catch (e) {
      toast(e.message || 'Jaxx failed', 'error')
    } finally {
      send_btn.disabled = false
    }
  }
  send_btn.addEventListener('click', submit)
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit() })
}

function currentTab() {
  return $$('.tab').find((t) => t.classList.contains('active'))?.dataset.tab || 'home'
}

// ───────────────────────────────────────────────────────
// boot
// ───────────────────────────────────────────────────────

function bindCommon() {
  $$('.tab').forEach((t) => t.addEventListener('click', () => switchTab(t.dataset.tab)))
  $('#authConnect').addEventListener('click', authConnect)
  $('#authToken').addEventListener('keydown', (e) => { if (e.key === 'Enter') authConnect() })
  $('#authLoginWith0n')?.addEventListener('click', () => { try { chrome.tabs.create({ url: 'https://www.0ncore.com/hub' }) } catch { window.open('https://www.0ncore.com/hub', '_blank') } })
}

async function refreshAll() {
  await loadHome()
  await loadLinkedIn()
  await loadSavedFlows()
  await loadSettings()
  // health
  try {
    const h = await send('HEALTH_CHECK')
    setStatus(h?.ok ? 'Connected' : 'Offline', !!h?.ok)
  } catch {
    setStatus('Offline', false)
  }
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))
}

// ───────────────────────────────────────────────────────
// scan tab — calls SCAN_REQUEST on the service worker which
// runs the detectors via injected content script + chrome.webRequest
// host capture, then forwards to /api/scanner/analyze.
// ───────────────────────────────────────────────────────

const SCAN_RECS_BASE = 'https://www.0ncore.com/turn-it-on/'
const SCAN = { lastScanId: null, lastResult: null, lastUrl: null }

const SCAN_CAT_LABEL = {
  platform: 'Platform / CMS',
  crm: 'CRM',
  analytics: 'Analytics',
  chat: 'Chat',
  email: 'Email / Marketing',
  payments: 'Payments',
  security: 'Security / Compliance',
}

async function runScan() {
  const btn = $('#scanRunBtn')
  btn.disabled = true
  btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/></svg> Scanning…'
  $('#scanDetected').innerHTML = '<div class="activity-empty">Scanning…</div>'
  $('#scanGaps').innerHTML = '<div class="activity-empty">Scanning…</div>'
  $('#scanRecs').innerHTML = '<div class="activity-empty">Scanning…</div>'
  try {
    const res = await send('SCAN_REQUEST')
    if (!res?.ok) {
      toast(res?.error || 'Scan failed', 'error')
      return
    }
    SCAN.lastScanId = res.scanId
    SCAN.lastResult = res
    SCAN.lastUrl = res.url
    $('#scanHost').textContent = res.hostname || res.url
    const score = typeof res.stack_gap_score === 'number' ? res.stack_gap_score : 0
    const scoreEl = $('#scanScore')
    scoreEl.textContent = score
    scoreEl.classList.remove('mid', 'low')
    if (score < 60) scoreEl.classList.add('low')
    else if (score < 80) scoreEl.classList.add('mid')

    renderDetected(res.detected || {})
    renderGaps(res.gaps || [])
    renderRecs(res.recommendations || [])
    $('#scanLeadActions').hidden = false
  } catch (e) {
    toast(e.message || 'Scan failed', 'error')
  } finally {
    btn.disabled = false
    btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></svg> Scan this site'
  }
}

function renderDetected(by_category) {
  const el = $('#scanDetected')
  const cats = Object.keys(by_category).filter((c) => by_category[c]?.length)
  if (!cats.length) {
    el.innerHTML = '<div class="activity-empty">Nothing detected.</div>'
    return
  }
  el.innerHTML = cats
    .map(
      (c) => `
        <div class="scan-cat">
          <div class="scan-cat-name">${escapeHtml(SCAN_CAT_LABEL[c] || c)}</div>
          <div class="scan-cat-tools">
            ${by_category[c]
              .map((h) => {
                const evid = (h.evidence || []).map((e) => `${e.kind}: ${e.detail}`).join(' · ')
                return `<span class="scan-tool" title="${escapeHtml(evid)}">${escapeHtml(h.name)}</span>`
              })
              .join('')}
          </div>
        </div>
      `,
    )
    .join('')
}

function renderGaps(gaps) {
  const el = $('#scanGaps')
  if (!gaps.length) {
    el.innerHTML = '<div class="activity-empty">No critical gaps. Nice stack.</div>'
    return
  }
  el.innerHTML = gaps
    .map((g) => `<span class="scan-gap-pill">${escapeHtml(SCAN_CAT_LABEL[g] || g)}</span>`)
    .join('')
}

function renderRecs(recs) {
  const el = $('#scanRecs')
  if (!recs.length) {
    el.innerHTML = '<div class="activity-empty">No recommendations.</div>'
    return
  }
  el.innerHTML = recs
    .slice(0, 8)
    .map(
      (r) => `
        <div class="scan-rec">
          <div class="scan-rec-text">
            <div class="scan-rec-name">${escapeHtml(r.service_id || r.id || 'Service')}</div>
            <div class="scan-rec-why">${escapeHtml(r.why || r.reason || '')}</div>
          </div>
          <a class="scan-rec-link" href="${SCAN_RECS_BASE}${encodeURIComponent(r.service_id || r.id || '')}${SCAN.lastScanId ? `?scan=${SCAN.lastScanId}` : ''}" target="_blank" rel="noopener">Connect →</a>
        </div>
      `,
    )
    .join('')
}

// ───────────────────────────────────────────────────────
// fiverr mode — gig generator (Phase 2 of fiverr-and-scanner spec)
// ───────────────────────────────────────────────────────

const FIV_LIMITS = {
  title: 80,
  description: 1200,
  tags: { count: 5, chars_per_tag: 20 },
  package_name: 35,
  package_description: 100,
  buyer_requirement: 400,
  faq_question: 100,
  faq_answer: 300,
}

const FIV = {
  mode: 'linkedin',
  tier: 'standard',
  tone: 'authoritative',
  lastSections: null,
  sourceScanId: null,
}

async function loadComposeMode() {
  try {
    const r = await chrome.storage.sync?.get('composeMode')
    const m = r?.composeMode || 'linkedin'
    setComposeMode(m, true)
  } catch {
    setComposeMode('linkedin', true)
  }
}

function setComposeMode(mode, skipPersist) {
  FIV.mode = mode
  $$('#composeModeRow .pill').forEach((p) => {
    p.classList.toggle('active', p.dataset.value === mode)
  })
  $$('[data-mode-block]').forEach((el) => {
    el.hidden = el.dataset.modeBlock !== mode && !(mode !== 'fiverr' && el.dataset.modeBlock === 'linkedin')
    if (mode === 'fiverr') el.hidden = el.dataset.modeBlock !== 'fiverr'
  })
  if (!skipPersist) {
    try { chrome.storage.sync?.set({ composeMode: mode }) } catch {}
  }
}

function bindFiverrMode() {
  // mode switcher
  $$('#composeModeRow .pill').forEach((p) => {
    p.addEventListener('click', () => setComposeMode(p.dataset.value))
  })
  // tier + tone pill rows
  bindPillGroup('fivTier', (v) => (FIV.tier = v))
  bindPillGroup('fivTone', (v) => (FIV.tone = v))
  // generate
  $('#fivGenerate').addEventListener('click', generateFiverr)
  // save as template
  const saveBtn = $('#fivSaveBtn')
  if (saveBtn) saveBtn.addEventListener('click', saveFiverrTemplate)

  // Pre-fill from scan if Scan tab handed us context
  try {
    chrome.storage.session?.get('composeFiverrPrefill').then((r) => {
      const data = r?.composeFiverrPrefill
      if (!data) return
      const gaps = (data.gaps || []).join(' + ')
      const top = data.topRec ? ` (recommended: ${data.topRec.service_id})` : ''
      $('#fivDescription').value = `Set up missing ${gaps}${top} for ${data.url}. Provide setup, configuration, and a 30-day audit.`
      $('#fiverrSourceBadge').hidden = false
      $('#fiverrSourceUrl').textContent = ` · ${data.url}`
      FIV.sourceScanId = data.scanId || null
      setComposeMode('fiverr')
      chrome.storage.session?.remove('composeFiverrPrefill')
    })
  } catch {}
}

function bindPillGroup(group, onChange) {
  $$(`[data-pillgroup="${group}"] .pill`).forEach((p) => {
    p.addEventListener('click', () => {
      $$(`[data-pillgroup="${group}"] .pill`).forEach((x) => x.classList.remove('active'))
      p.classList.add('active')
      onChange(p.dataset.value)
    })
  })
}

async function generateFiverr() {
  const description = $('#fivDescription').value.trim()
  if (description.length < 30) return toast('Describe the service in more detail (30+ chars)', 'error')
  const category = $('#fivCategory').value
  const subcategory = $('#fivSubcategory').value.trim() || 'General'

  const btn = $('#fivGenerate')
  btn.disabled = true
  btn.textContent = 'Generating gig…'
  $('#fivSections').innerHTML = ''
  $('#fivWarnings').hidden = true

  try {
    const res = await fetch('https://www.0ncore.com/api/fiverr/generate', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        description,
        category,
        subcategory,
        tier_intent: FIV.tier,
        tone: FIV.tone,
        source_scan_id: FIV.sourceScanId,
      }),
    })
    const data = await res.json()
    if (!res.ok || !data.ok) {
      toast(data.error || `Generate failed (${res.status})`, 'error')
      return
    }
    FIV.lastSections = data.sections
    FIV.lastVpis = data.vpis
    FIV.lastWarnings = data.warnings
    renderFiverrSections(data.sections, data.vpis, data.warnings)
    const saveRow = $('#fivSaveRow')
    if (saveRow) saveRow.hidden = false
  } catch (e) {
    toast(e.message || 'Network error', 'error')
  } finally {
    btn.disabled = false
    btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v6M12 16v6M2 12h6M16 12h6" /></svg> Generate Fiverr gig'
  }
}

async function regenerateFiverrSection(section) {
  if (!FIV.lastSections) return toast('Generate first', 'error')
  const description = $('#fivDescription').value.trim()
  const category = $('#fivCategory').value
  const subcategory = $('#fivSubcategory').value.trim() || 'General'
  toast(`Regenerating ${section}…`, 'info')
  try {
    const res = await fetch('https://www.0ncore.com/api/fiverr/section-regenerate', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        section,
        input_state: { description, category, subcategory, tier_intent: FIV.tier, tone: FIV.tone },
        existing_sections: FIV.lastSections,
      }),
    })
    const data = await res.json()
    if (!res.ok || !data.ok) return toast(data.error || `Regen failed (${res.status})`, 'error')
    FIV.lastSections[section] = data.value
    renderFiverrSections(FIV.lastSections, FIV.lastVpis, data.warnings || [])
    toast(`${section} regenerated`, 'success')
  } catch (e) {
    toast(e.message || 'Network error', 'error')
  }
}

async function saveFiverrTemplate() {
  if (!FIV.lastSections) return toast('Generate first', 'error')
  const name = ($('#fivTemplateName').value || '').trim()
  if (!name) return toast('Template name required', 'error')
  const description = $('#fivDescription').value.trim()
  const category = $('#fivCategory').value
  const subcategory = $('#fivSubcategory').value.trim() || 'General'
  const btn = $('#fivSaveBtn')
  btn.disabled = true
  btn.textContent = 'Saving…'
  try {
    const stored = await chrome.storage.local?.get('apiToken')
    const token = stored?.apiToken
    if (!token) {
      toast('Connect your 0n token first (Home tab)', 'error')
      return
    }
    const res = await fetch('https://www.0ncore.com/api/fiverr/templates', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        name,
        input_state: { description, category, subcategory, tier_intent: FIV.tier, tone: FIV.tone },
        sections: FIV.lastSections,
        vpis_score: FIV.lastVpis || null,
        source_scan_id: FIV.sourceScanId || null,
      }),
    })
    const data = await res.json()
    if (!res.ok || !data.ok) return toast(data.error || `Save failed (${res.status})`, 'error')
    toast('Template saved', 'success')
    $('#fivTemplateName').value = ''
  } catch (e) {
    toast(e.message || 'Network error', 'error')
  } finally {
    btn.disabled = false
    btn.textContent = 'Save as template'
  }
}

function renderFiverrSections(s, vpis, warnings) {
  // VPIS bar
  if (vpis) {
    $('#fivVpisRow').hidden = false
    const score = Math.max(0, Math.min(100, vpis.composite ?? 0))
    $('#fivVpisNum').textContent = score
    const fill = $('#fivVpisFill')
    fill.style.width = `${score}%`
    fill.className = 'vpis-fill ' + (score >= 80 ? 'high' : score >= 60 ? 'mid' : 'low')
  }

  if (warnings && warnings.length) {
    const w = $('#fivWarnings')
    w.hidden = false
    w.textContent = `Some fields are over Fiverr's limits — copy disabled until trimmed: ${warnings.join(', ')}`
  }

  const root = $('#fivSections')
  root.innerHTML = ''
  root.appendChild(card('1. Title', s.title || '', FIV_LIMITS.title, 'title'))
  root.appendChild(catCard(s.category, 'category'))
  root.appendChild(tagCard(s.tags || []))
  root.appendChild(card('4. Description', s.description || '', FIV_LIMITS.description, 'description'))
  root.appendChild(pkgCard('5. Basic package', s.basic, 'basic'))
  root.appendChild(pkgCard('6. Standard package', s.standard, 'standard'))
  root.appendChild(pkgCard('7. Premium package', s.premium, 'premium'))
  root.appendChild(reqCard(s.requirements || []))
  root.appendChild(faqCard(s.faq || []))
  root.appendChild(card('10. Image prompt', s.image_prompt || '', null, 'image_prompt'))
}

function copyableBtn(getText) {
  const btn = document.createElement('button')
  btn.className = 'fiv-icon-btn'
  btn.title = 'Copy'
  btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>'
  btn.addEventListener('click', async () => {
    const text = getText()
    if (!text) return
    try {
      await navigator.clipboard.writeText(text)
      toast('Copied', 'success')
    } catch {
      toast('Copy failed', 'error')
    }
  })
  return btn
}

function regenBtn(sectionKey) {
  const btn = document.createElement('button')
  btn.className = 'fiv-icon-btn'
  btn.title = 'Regenerate this section'
  btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg>'
  btn.addEventListener('click', () => regenerateFiverrSection(sectionKey))
  return btn
}

function cardShell(label, limit, currentLen) {
  const c = document.createElement('div')
  c.className = 'fiv-card'
  if (limit && currentLen > limit) c.classList.add('over')
  const head = document.createElement('div')
  head.className = 'fiv-head'
  const lbl = document.createElement('div')
  lbl.className = 'fiv-label'
  lbl.textContent = label
  head.appendChild(lbl)
  if (limit) {
    const cnt = document.createElement('div')
    cnt.className = 'fiv-count' + (currentLen > limit ? ' over' : '')
    cnt.textContent = `${currentLen}/${limit}`
    head.appendChild(cnt)
  }
  c.appendChild(head)
  return c
}

function card(label, text, limit, _key) {
  const c = cardShell(label, limit, text.length)
  const actions = document.createElement('div')
  actions.className = 'fiv-actions'
  const copyBtn = copyableBtn(() => text)
  if (limit && text.length > limit) copyBtn.disabled = true
  actions.appendChild(copyBtn)
  if (_key && ['title', 'description', 'image_prompt'].includes(_key)) {
    actions.appendChild(regenBtn(_key))
  }
  c.querySelector('.fiv-head').appendChild(actions)

  const body = document.createElement('div')
  body.className = 'fiv-body'
  body.textContent = text
  c.appendChild(body)
  return c
}

function catCard(category, _key) {
  const text = category ? `${category.category || ''} > ${category.subcategory || ''}` : ''
  const c = cardShell('2. Category', null, text.length)
  const actions = document.createElement('div')
  actions.className = 'fiv-actions'
  actions.appendChild(copyableBtn(() => text))
  c.querySelector('.fiv-head').appendChild(actions)
  const body = document.createElement('div')
  body.className = 'fiv-body mono'
  body.textContent = text
  c.appendChild(body)
  return c
}

function tagCard(tags) {
  const c = cardShell(`3. Tags`, FIV_LIMITS.tags.count, tags.length)
  const actions = document.createElement('div')
  actions.className = 'fiv-actions'
  actions.appendChild(copyableBtn(() => tags.join(', ')))
  actions.appendChild(regenBtn('tags'))
  c.querySelector('.fiv-head').appendChild(actions)
  const wrap = document.createElement('div')
  wrap.className = 'fiv-tags'
  tags.forEach((t) => {
    const chip = document.createElement('span')
    const overTag = t.length > FIV_LIMITS.tags.chars_per_tag
    chip.className = 'fiv-tag-chip' + (overTag ? ' over' : '')
    chip.innerHTML = `<span>${escapeHtml(t)}</span>`
    const cb = document.createElement('button')
    cb.title = 'Copy tag'
    cb.textContent = '⌘'
    cb.addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(t); toast('Tag copied', 'success') } catch {}
    })
    chip.appendChild(cb)
    wrap.appendChild(chip)
  })
  c.appendChild(wrap)
  return c
}

function pkgCard(label, pkg, _key) {
  pkg = pkg || {}
  const block = [
    pkg.name || '',
    pkg.description || '',
    `Delivery: ${pkg.delivery_days ?? '—'} days`,
    `Revisions: ${pkg.revisions ?? '—'}`,
    `Price: $${pkg.price_usd ?? '—'}`,
  ].join('\n')
  const nameOver = (pkg.name || '').length > FIV_LIMITS.package_name
  const descOver = (pkg.description || '').length > FIV_LIMITS.package_description
  const c = cardShell(label, null, 0)
  if (nameOver || descOver) c.classList.add('over')
  const actions = document.createElement('div')
  actions.className = 'fiv-actions'
  actions.appendChild(copyableBtn(() => block))
  if (_key) actions.appendChild(regenBtn(_key))
  c.querySelector('.fiv-head').appendChild(actions)

  const grid = document.createElement('div')
  grid.className = 'fiv-pkg-grid'
  grid.innerHTML = `
    <span class="k">Name</span>
    <span class="v">${escapeHtml(pkg.name || '—')} <span class="fiv-count${nameOver ? ' over' : ''}">${(pkg.name || '').length}/${FIV_LIMITS.package_name}</span></span>
    <span class="k">Description</span>
    <span class="v">${escapeHtml(pkg.description || '—')} <span class="fiv-count${descOver ? ' over' : ''}">${(pkg.description || '').length}/${FIV_LIMITS.package_description}</span></span>
    <span class="k">Delivery</span><span class="v">${pkg.delivery_days ?? '—'} days</span>
    <span class="k">Revisions</span><span class="v">${pkg.revisions ?? '—'}</span>
    <span class="k">Price</span><span class="v">$${pkg.price_usd ?? '—'}</span>
  `
  c.appendChild(grid)
  return c
}

function reqCard(reqs) {
  const c = cardShell('8. Buyer requirements', null, reqs.length)
  const actions = document.createElement('div')
  actions.className = 'fiv-actions'
  actions.appendChild(copyableBtn(() => reqs.map((r, i) => `${i + 1}. ${r}`).join('\n')))
  actions.appendChild(regenBtn('requirements'))
  c.querySelector('.fiv-head').appendChild(actions)
  const body = document.createElement('div')
  reqs.forEach((r, i) => {
    const item = document.createElement('div')
    item.className = 'fiv-req-item'
    const over = r.length > FIV_LIMITS.buyer_requirement
    item.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:6px;">
        <div class="fiv-body" style="flex:1">${i + 1}. ${escapeHtml(r)}</div>
        <span class="fiv-count${over ? ' over' : ''}">${r.length}/${FIV_LIMITS.buyer_requirement}</span>
      </div>
    `
    body.appendChild(item)
  })
  c.appendChild(body)
  return c
}

function faqCard(faqs) {
  const c = cardShell('9. FAQ', null, faqs.length)
  const actions = document.createElement('div')
  actions.className = 'fiv-actions'
  actions.appendChild(copyableBtn(() => faqs.map((f) => `Q: ${f.q}\nA: ${f.a}`).join('\n\n')))
  actions.appendChild(regenBtn('faq'))
  c.querySelector('.fiv-head').appendChild(actions)
  const body = document.createElement('div')
  faqs.forEach((f) => {
    const item = document.createElement('div')
    item.className = 'fiv-faq-item'
    const qOver = (f.q || '').length > FIV_LIMITS.faq_question
    const aOver = (f.a || '').length > FIV_LIMITS.faq_answer
    item.innerHTML = `
      <div class="fiv-faq-q">${escapeHtml(f.q || '')} <span class="fiv-count${qOver ? ' over' : ''}">${(f.q || '').length}/${FIV_LIMITS.faq_question}</span></div>
      <div class="fiv-body">${escapeHtml(f.a || '')} <span class="fiv-count${aOver ? ' over' : ''}">${(f.a || '').length}/${FIV_LIMITS.faq_answer}</span></div>
    `
    body.appendChild(item)
  })
  c.appendChild(body)
  return c
}

// ───────────────────────────────────────────────────────
// scan tab
// ───────────────────────────────────────────────────────

function bindScan() {
  $('#scanRunBtn').addEventListener('click', runScan)
  $('#scanSaveLead').addEventListener('click', () => {
    if (!SCAN.lastScanId) return toast('Run a scan first', 'error')
    $('#scanLeadForm').hidden = false
    $('#scanLeadEmail').focus()
  })
  $('#scanLeadCancel').addEventListener('click', () => {
    $('#scanLeadForm').hidden = true
    $('#scanLeadEmail').value = ''
    $('#scanLeadName').value = ''
  })
  $('#scanLeadSubmit').addEventListener('click', async () => {
    if (!SCAN.lastScanId) return toast('Run a scan first', 'error')
    const email = $('#scanLeadEmail').value.trim()
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return toast('Valid email required', 'error')
    }
    const name = $('#scanLeadName').value.trim()
    const submitBtn = $('#scanLeadSubmit')
    submitBtn.disabled = true
    submitBtn.textContent = 'Saving…'
    try {
      const r = await send('SCAN_SAVE_LEAD', { scanId: SCAN.lastScanId, email, name: name || undefined })
      if (r?.ok) {
        const path = r.upsertPath === 'updated' ? 'updated' : 'created'
        toast(`Lead ${path} — ${r.contactId?.slice(0, 8) || 'OK'}`, 'success')
        $('#scanLeadForm').hidden = true
        $('#scanLeadEmail').value = ''
        $('#scanLeadName').value = ''
      } else {
        toast(r?.error || 'Could not save', 'error')
      }
    } finally {
      submitBtn.disabled = false
      submitBtn.textContent = 'Save'
    }
  })
  $('#scanGenGig').addEventListener('click', () => {
    if (!SCAN.lastResult) return toast('Run a scan first', 'error')
    chrome.storage.session?.set({
      composeFiverrPrefill: {
        scanId: SCAN.lastScanId,
        url: SCAN.lastUrl,
        gaps: SCAN.lastResult.gaps,
        topRec: (SCAN.lastResult.recommendations || [])[0],
      },
    })
    switchTab('compose')
    toast('Compose pre-filled from scan', 'success')
  })
}

(async function init() {
  bindCommon()
  bindHome()
  bindLinkedIn()
  bindCompose()
  bindFiverrMode()
  bindFlows()
  bindSettings()
  bindJaxx()
  bindScan()
  // Rendered BEFORE the auth check so the panel is never blank: unconnected,
  // it says so and points at Settings, which is more useful than an empty tab.
  await initCrm(document.getElementById('crmRoot'))
  await initTasks(document.getElementById('tasksRoot'))
  await loadComposeMode()
  const ok = await ensureAuth()
  if (ok) await refreshAll()
})()
