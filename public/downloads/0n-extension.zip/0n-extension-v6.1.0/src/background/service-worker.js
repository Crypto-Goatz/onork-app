// ═══ 0nCore Background Service Worker — v4.0 ═══
// LOCAL-FIRST: routes all AI through desktop 0nMCP server (free via Claude MAX/Pro)
// Falls back to 0ncore.com cloud when local unavailable.
// Auth: 0ncore.com/api/auth/extension-login + verify-token (NO direct Supabase)

import { OnCoreClient, APIError } from '../lib/api.js'
import { storage, KEYS } from '../lib/storage.js'
import { PROVIDERS, getKeys, callProvider, askAllProviders } from '../lib/council.js'

const AUTH_BASE = 'https://0ncore.com'

// ── Singletons ──
let _client = null
let _localAlive = false

// ── Network host capture for the Stack Scanner ──
// Maps tabId -> Set<hostname>. Trimmed every 30 seconds so we only
// surface recently-active hosts to the detector engine.
const tabHosts = new Map()
const tabHostTimestamps = new Map()
const HOST_WINDOW_MS = 30_000

try {
  chrome.webRequest.onBeforeRequest.addListener(
    (info) => {
      if (info.tabId < 0) return
      try {
        const u = new URL(info.url)
        const set = tabHosts.get(info.tabId) || new Set()
        set.add(u.hostname)
        tabHosts.set(info.tabId, set)
        const ts = tabHostTimestamps.get(info.tabId) || new Map()
        ts.set(u.hostname, Date.now())
        tabHostTimestamps.set(info.tabId, ts)
      } catch {}
    },
    { urls: ['<all_urls>'] },
  )
} catch (e) {
  console.warn('[scanner] webRequest listener failed:', e.message)
}

function recentHostsForTab(tabId) {
  const ts = tabHostTimestamps.get(tabId)
  if (!ts) return []
  const cutoff = Date.now() - HOST_WINDOW_MS
  const result = []
  for (const [h, t] of ts.entries()) if (t >= cutoff) result.push(h)
  return result
}

// Reset host map when a tab navigates away
chrome.tabs?.onUpdated?.addListener((tabId, info) => {
  if (info.status === 'loading' && info.url) {
    tabHosts.delete(tabId)
    tabHostTimestamps.delete(tabId)
  }
})

// ── Install / Migration ──
chrome.runtime.onInstalled.addListener(async (details) => {
  // Context menus
  chrome.contextMenus.create({ id: '0n-reply', title: '0nCore — Generate Reply', contexts: ['selection'] })
  chrome.contextMenus.create({ id: '0n-post', title: '0nCore — Generate Post', contexts: ['selection'] })
  chrome.contextMenus.create({ id: '0n-summarize', title: '0nCore — Summarize', contexts: ['selection'] })
  chrome.contextMenus.create({ id: '0n-comment', title: '0nCore — Smart Comment', contexts: ['page'] })
  chrome.contextMenus.create({ id: '0n-scrape', title: '0nCore — Scrape Profile', contexts: ['page'], documentUrlPatterns: ['https://www.linkedin.com/in/*', 'https://linkedin.com/in/*'] })
  chrome.contextMenus.create({ id: '0n-compose', title: '0nCore — Compose Reply', contexts: ['selection'] })

  if (details.reason === 'install') {
    await storage.setApiMode('local')
    await storage.setLocalUrl('http://localhost:3000')
  }

  // Migrate old storage keys (v3 → v4)
  await runMigration()

  // Initial health check
  checkLocalServer()
})

async function runMigration() {
  try {
    const already = await chrome.storage.local.get('oc_migrated_v4')
    if (already.oc_migrated_v4) return

    const [syncData, localData] = await Promise.all([
      chrome.storage.sync.get(['oncore_session', 'oncore_config']),
      chrome.storage.local.get(['uip', '0n_leads', 'oncore_queue']),
    ])

    const session = syncData.oncore_session || {}
    const config  = syncData.oncore_config  || {}

    const writes = {}
    if (session.token && !(await storage.getToken()))    writes[KEYS.AUTH_TOKEN] = session.token
    if (session.email) {
      const user = await storage.getUser()
      if (!user) writes[KEYS.AUTH_USER] = { email: session.email }
    }
    if (config.groqKey || config.anthropicKey) {
      const existing = await storage.getSettings()
      if (!existing.groqKey && config.groqKey) existing.groqKey = config.groqKey
      if (!existing.anthropicKey && config.anthropicKey) existing.anthropicKey = config.anthropicKey
      if (config.persona) existing.persona = config.persona
      writes[KEYS.SETTINGS] = existing
    }
    if (localData.uip) {
      const existing = await storage.getVoice()
      if (!existing.count) writes[KEYS.VOICE] = { ...existing, ...localData.uip }
    }
    if (localData['0n_leads']?.length) {
      const existing = await storage.getLeads()
      if (!existing.length) writes[KEYS.LEADS] = localData['0n_leads']
    }
    if (localData.oncore_queue?.length) {
      const existing = await storage.getQueue()
      if (!existing.length) writes[KEYS.QUEUE] = localData.oncore_queue
    }

    if (Object.keys(writes).length > 0) {
      await chrome.storage.local.set(writes)
    }

    await chrome.storage.local.set({ oc_migrated_v4: true })
    console.log('[0nCore] Migration v3→v4 complete')
  } catch (err) {
    console.warn('[0nCore] Migration failed (non-fatal):', err.message)
  }
}

// ── Keep-Alive ──
chrome.alarms.create('keepalive', { periodInMinutes: 0.4 })
chrome.alarms.create('health-check', { periodInMinutes: 1 })
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'keepalive') chrome.storage.local.get(KEYS.AUTH_TOKEN, () => {})
  if (alarm.name === 'health-check') checkLocalServer()
  if (alarm.name === '0n-auto-content') {
    try {
      await fetch(`${AUTH_BASE}/api/cron/blog`)
      await fetch(`${AUTH_BASE}/api/cron/use-cases`)
      chrome.notifications.create({ type: 'basic', iconUrl: '/public/icon-128.png', title: '0nCore — Content Generated', message: 'Blog post and use case generated successfully.' })
    } catch (err) {
      console.error('[0nCore] Auto-content failed:', err)
    }
  }
})

// ── Side Panel ──
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {})
chrome.action.onClicked.addListener(async (tab) => {
  await chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {})
})

// ── Client Factory ──
async function getClient() {
  if (_client) return _client
  const [token, mode, localUrl] = await Promise.all([
    storage.getToken(), storage.getApiMode(), storage.getLocalUrl(),
  ])
  _client = new OnCoreClient({ token, mode, localUrl })
  return _client
}

async function refreshClient() {
  _client = null
  return getClient()
}

// ── Local Server Health Check ──
async function checkLocalServer() {
  try {
    const client = await getClient()
    const health = await client.checkLocalHealth()
    _localAlive = health.alive
    await storage.setLocalHealth({ alive: health.alive, tools: health.tools || 0, services: health.services || 0, version: health.version || '', checkedAt: Date.now() })

    if (!health.alive) {
      const detected = await client.autoDetect()
      if (detected.found) {
        _localAlive = true
        await storage.setLocalUrl(detected.url)
        await storage.setLocalHealth({ alive: true, tools: 0, services: 0, version: 'auto-detected', checkedAt: Date.now(), port: detected.port })
        await refreshClient()
      }
    }
    return health
  } catch {
    return { alive: false }
  }
}

// ── Auth ──
async function isAuthenticated() {
  const [token, expiry] = await Promise.all([storage.getToken(), storage.getExpiry()])
  if (!token) return false
  if (expiry && Date.now() > expiry) return false
  return true
}

async function performLogin(email, password) {
  const res = await fetch(`${AUTH_BASE}/api/auth/extension-login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  })
  const data = await res.json()
  if (!res.ok || !data.token) throw new Error(data.error || 'Login failed')

  const token  = data.token
  const user   = data.user || { email }
  const expiry = data.expires_in ? Date.now() + data.expires_in * 1000 : Date.now() + 30 * 24 * 60 * 60 * 1000

  await Promise.all([
    storage.setToken(token),
    storage.setUser(user),
    storage.setExpiry(expiry),
  ])
  _client = null

  // Sync profile + addons + connections + services via verify-token (await so first response is complete)
  const synced = await syncProfile(token).catch(() => null)
  // Sync vault keys (API keys from 0nmcp.com vault) — fire and forget
  syncVaultKeys(token).catch(() => {})

  return {
    ok:          true,
    success:     true,
    user:        synced?.profile     || user,
    connections: synced?.connections || [],
    addons:      synced?.addons      || [],
    services:    synced?.services    || [],
    plan:        synced?.plan        || null,
  }
}

/**
 * Token-based login — paste an 0n_<...> token from
 * 0ncore.com/dashboard/downloads. Server matches against profiles.access_token.
 */
async function performTokenLogin(token) {
  const raw = (token || '').trim()
  if (!raw.startsWith('0n_')) {
    throw new Error('Token must start with "0n_". Find yours at 0ncore.com/dashboard/downloads.')
  }
  const res = await fetch(`${AUTH_BASE}/api/auth/extension-login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token: raw }),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    throw new Error(data.error || `Login failed (${res.status})`)
  }
  // The token route returns { user: profile, addons, ... } — we save the
  // pasted 0n_ token itself as the auth credential.
  const user   = data.user || data.profile || {}
  const expiry = Date.now() + 365 * 24 * 60 * 60 * 1000  // tokens are long-lived

  await Promise.all([
    storage.setToken(raw),
    storage.setUser(user),
    storage.setExpiry(expiry),
  ])
  _client = null

  const synced = await syncProfile(raw).catch(() => null)
  syncVaultKeys(raw).catch(() => {})

  return {
    ok:          true,
    success:     true,
    user:        synced?.profile     || user,
    connections: synced?.connections || data.connections || [],
    addons:      synced?.addons      || data.addons      || [],
    services:    synced?.services    || [],
    plan:        synced?.plan        || data.plan        || null,
  }
}

async function syncProfile(token) {
  try {
    const res = await fetch(`${AUTH_BASE}/api/auth/verify-token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token }),
    })
    if (!res.ok) return null
    const data = await res.json()
    const writes = {}
    if (data.profile)     { await storage.setUser(data.profile); }
    if (data.connections) { writes.oc_connections = data.connections }
    if (data.addons)      { writes.oc_addons      = data.addons }
    if (data.services)    { writes.oc_services    = data.services }
    if (data.plan)        { writes.oc_plan        = data.plan }
    if (Object.keys(writes).length) await chrome.storage.local.set(writes)
    chrome.runtime.sendMessage({ action: 'PROFILE_SYNCED', profile: data.profile || null }).catch(() => {})
    return data
  } catch { return null }
}

async function syncVaultKeys(authToken) {
  try {
    const res = await fetch(`${AUTH_BASE}/api/auth/vault-keys`, {
      headers: { 'Authorization': `Bearer ${authToken}` },
    })
    if (!res.ok) return
    const { keys } = await res.json()
    if (!keys || Object.keys(keys).length === 0) return
    const keyMap = { openai: 'openai', anthropic: 'anthropic', gemini: 'gemini', grok: 'grok', xai: 'grok' }
    const existingKeys = await getKeys()
    let updated = false
    for (const [service, key] of Object.entries(keys)) {
      const extKey = keyMap[service]
      if (extKey && key && !existingKeys[extKey]) {
        existingKeys[extKey] = key
        updated = true
      }
    }
    if (updated) {
      await chrome.storage.local.set({ oc_apiKeys: existingKeys })
    }
  } catch {}
}

async function performRegister(name, email, password) {
  const res = await fetch(`${AUTH_BASE}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, password }),
  })
  const data = await res.json()
  if (!res.ok || !data.token) throw new Error(data.error || 'Registration failed')

  const token  = data.token
  const user   = data.user || { name, email }
  const expiry = Date.now() + 30 * 24 * 60 * 60 * 1000

  await Promise.all([
    storage.setToken(token),
    storage.setUser(user),
    storage.setExpiry(expiry),
  ])
  _client = null

  const synced = await syncProfile(token).catch(() => null)
  syncVaultKeys(token).catch(() => {})

  return {
    success:     true,
    user:        synced?.profile     || user,
    connections: synced?.connections || [],
    addons:      synced?.addons      || [],
    services:    synced?.services    || [],
    plan:        synced?.plan        || null,
  }
}

async function performLogout() {
  await storage.clearAuth()
  await chrome.storage.local.remove(['oc_connections', 'oc_addons', 'oc_services', 'oc_plan'])
  _client = null
  return { success: true }
}

// ── UIP Helpers (voice profile) ──
async function getUIP() {
  return storage.getVoice()
}

async function saveUIP(uip) {
  return storage.setVoice(uip)
}

// ── Groq Content Generation ──
async function generateContent(prompt, maxTokens = 800) {
  const settings = await storage.getSettings()
  const groqKey = settings.groqKey
  if (!groqKey) throw new Error('No Groq API key. Go to Settings to add one.')

  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${groqKey}` },
    body: JSON.stringify({
      model: 'llama-3.3-70b-versatile',
      messages: [
        { role: 'system', content: 'You are 0nCore AI — a content generation engine for LinkedIn, X, Reddit, email, and blogs. Write for the specified platform. Be direct, human, and valuable. Never start with "Great post" or use filler. Return content only.' },
        { role: 'user', content: prompt },
      ],
      temperature: 0.7,
      max_tokens: maxTokens,
    }),
  })
  if (!res.ok) throw new Error(`Groq error: ${res.status}`)
  const data = await res.json()
  return data.choices?.[0]?.message?.content || ''
}

// ── LinkedIn Generate — Anthropic + web_search ──
async function handleLinkedInGenerate({ url, mode, persona, apiKey }) {
  const settings = await storage.getSettings()
  const key = apiKey || settings.anthropicKey
  if (!key) throw new Error('No Anthropic API key for web search. Add one in Settings.')

  const modeInstructions = {
    comment: `Write a SHORT public LinkedIn comment (2-3 punchy paragraphs max).\n- Open with a genuine insight or empathetic observation — NEVER pitch\n- Subtly signal authority through the way you frame the problem\n- End with one open question or statement that invites a reply or DM`,
    dm: `Write a LinkedIn DM (4-5 sentences MAX).\n- Reference a specific detail from their post so they know you read it\n- Connect their stated pain to a direction — without selling anything\n- End with ONE low-friction conversational question`,
    post: `Write MY OWN LinkedIn post (150-200 words) inspired by their post.\n- Do NOT mention the original author or their post directly\n- Strong opening hook (first line must stop the scroll)\n- End with a thought-provoking question to drive engagement`,
  }

  const systemPrompt = `You are an expert LinkedIn ghostwriter and B2B consultant.\nYour writing rules:\n- Sounds like a sharp human, never like AI\n- Never opens with "I" — hook first\n- Concise and punchy — LinkedIn is not a blog\nReturn ONLY valid JSON. No markdown. No preamble.`

  const userPrompt = `Use web_search to fetch and read the LinkedIn post at this URL:\n${url}\n\nAfter reading the post content, generate a response in ${(mode || 'comment').toUpperCase()} mode.\n\nMode instructions:\n${modeInstructions[mode] || modeInstructions.comment}\n\n${persona ? `My persona: "${persona}"` : ''}\n\nReturn ONLY this JSON:\n{ "author": "author name", "hook": "their core point", "response": "the LinkedIn text to copy-paste" }`

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': key,
      'anthropic-version': '2023-06-01',
      'anthropic-beta': 'web-search-2025-03-05',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      system: systemPrompt,
      tools: [{ type: 'web_search_20250305', name: 'web_search' }],
      messages: [{ role: 'user', content: userPrompt }],
    }),
  })

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}))
    if (res.status === 401) throw new Error('INVALID_API_KEY')
    throw new Error(errData.error?.message || `API error ${res.status}`)
  }

  const data = await res.json()
  const textBlock = [...(data.content || [])].reverse().find(b => b.type === 'text')
  if (!textBlock?.text) throw new Error('NO_RESPONSE')

  try {
    const clean = textBlock.text.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/i, '').trim()
    return JSON.parse(clean)
  } catch {
    return { author: '', hook: '', response: textBlock.text }
  }
}

// ── Voice-Trained Generate — Anthropic with UIP ──
async function handleVoiceGenerate({ topic, style, uip: uipOverride }) {
  const settings = await storage.getSettings()
  const key = settings.anthropicKey
  if (!key) throw new Error('No Anthropic API key configured for voice generation.')

  const uip = uipOverride || await getUIP()

  const toneMap = {
    professional: 'Write in a sharp, credible, professional tone. No slang. High signal-to-noise ratio.',
    casual: 'Write in a relaxed, conversational tone. Short sentences. Sounds like a real person talking.',
    direct: 'Be blunt and direct. No fluff. Get to the point immediately. Cut every unnecessary word.',
    'thought-leader': 'Write as a category-defining expert. Bold claims backed by insight. Confident and forward-looking.',
    storyteller: 'Lead with a micro-story or scene. Make it human and specific before landing the lesson.',
  }
  const emojiMap = {
    none: 'Use ZERO emoji. Pure text only.',
    minimal: 'Use 1 emoji maximum, only if it truly adds meaning. Never decorative.',
    moderate: 'Use 2-3 emoji to highlight key points. Purposeful, not excessive.',
    expressive: 'Emoji can be used freely to add energy and personality throughout.',
  }

  const avoidedBlock = (uip.avoided || []).length > 0 ? `NEVER use these phrases: ${(uip.avoided || []).map(p => `"${p}"`).join(', ')}.` : ''
  const approvedExamples = (uip.approved || []).slice(0, 3)
  const examplesBlock = approvedExamples.length > 0 ? `\n\nHere are examples of posts I have approved — match this voice exactly:\n${approvedExamples.map((ex, i) => `EXAMPLE ${i + 1}:\n${ex}`).join('\n\n')}` : ''
  const corrections = (uip.corrections || []).filter(c => c.c).slice(0, 3)
  const correctionsBlock = corrections.length > 0 ? `\n\nHere are edits I have made to improve posts — learn from these:\n${corrections.map((c, i) => `CORRECTION ${i + 1}:\nOriginal: ${c.o}\nCorrected: ${c.c}`).join('\n\n')}` : ''

  const systemPrompt = `You are a world-class LinkedIn ghostwriter trained on this user's exact voice.\n\nTONE: ${toneMap[uip.tone] || toneMap.professional}\nEMOJI: ${emojiMap[uip.emoji] || emojiMap.minimal}\n${avoidedBlock}${examplesBlock}${correctionsBlock}\n\nHARD RULES:\n- Under 1300 characters total\n- Hook goes first — no preamble, no "I wanted to share"\n- Short paragraphs (1-3 lines max), breathing room between them\n- Sound completely human — never like AI wrote it\n- Return ONLY the post text, nothing else`

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': key,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 600,
      system: systemPrompt,
      messages: [{ role: 'user', content: `Write a LinkedIn post about: ${topic}${style ? `\n\nPost style: ${style}` : ''}` }],
    }),
  })

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}))
    if (res.status === 401) throw new Error('INVALID_API_KEY')
    throw new Error(errData.error?.message || `Anthropic error ${res.status}`)
  }

  const data = await res.json()
  const textBlock = data.content?.find(b => b.type === 'text')
  return textBlock?.text || ''
}

// ── Context Menu Click Handler ──
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const selection = info.selectionText || ''
  const pageUrl   = tab?.url || ''

  if (info.menuItemId === '0n-scrape') {
    try {
      const result = await sendToContentScript(tab.id, { type: 'DO_SCRAPE' })
      chrome.runtime.sendMessage({ type: 'PANEL_ACTION', action: 'scrape', data: result }).catch(() => {})
    } catch (err) { console.error('[0nCore] Scrape failed:', err) }
    return
  }

  if (info.menuItemId === '0n-compose') {
    chrome.runtime.sendMessage({ type: 'PANEL_ACTION', action: 'compose', selection, url: pageUrl }).catch(() => {})
    return
  }

  let prompt = ''
  switch (info.menuItemId) {
    case '0n-reply':    prompt = `Write a thoughtful, expert reply to this text. Be concise, add value, no filler:\n\n"${selection}"`; break
    case '0n-post':     prompt = `Write a LinkedIn post inspired by this topic. Hook in line 1, no hashtags, under 200 words:\n\n"${selection}"`; break
    case '0n-summarize':prompt = `Summarize this clearly in 2-3 sentences:\n\n"${selection}"`; break
    case '0n-comment':  prompt = `Write a smart, insightful comment for a post on this page: ${pageUrl}. Be brief, add unique value.`; break
    default: return
  }

  try {
    const token = await storage.getToken()
    let content = ''

    if (token) {
      try {
        const res = await fetch(`${AUTH_BASE}/api/extension/generate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
          body: JSON.stringify({ prompt, max_tokens: 800 }),
        })
        if (res.ok) {
          const data = await res.json()
          content = data.content || data.text || ''
        }
      } catch { /* fall through to Groq */ }
    }

    if (!content) content = await generateContent(prompt)

    if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: '0n-content-generated', content })
  } catch (err) {
    console.error('[0nCore] Context menu generation failed:', err)
  }
})

// ── Content Script Bridge ──
function sendToContentScript(tabId, payload) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, payload, (response) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message))
      else resolve(response)
    })
  })
}

// ── Unified Message Handler ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const action  = msg.action || msg.type
  const payload = msg.payload || {}
  const ts      = Date.now()

  // Fast-path sync handlers
  if (action === 'OPEN_SIDEBAR' || action === 'OPEN_POPUP') {
    chrome.sidePanel.open({ windowId: sender.tab?.windowId }).catch(() => {})
    return
  }
  if (action === 'PING') { sendResponse({ ok: true }); return true }
  if (action === 'PANEL_ACTION') {
    chrome.runtime.sendMessage(msg).catch(() => {})
    sendResponse({ ok: true })
    return true
  }

  // All async handlers
  handleAsync(action, msg, payload, ts, sender)
    .then(sendResponse)
    .catch(err => sendResponse({ success: false, error: err.message || String(err) }))
  return true
})

async function handleAsync(action, msg, payload, ts, sender) {
  switch (action) {

    // ═══ Auth ═══
    case 'AUTH_CHECK': {
      const [health, user, extras] = await Promise.all([
        storage.getLocalHealth(),
        storage.getUser(),
        chrome.storage.local.get(['oc_connections', 'oc_addons', 'oc_services', 'oc_plan']),
      ])
      return {
        success:       true,
        authenticated: await isAuthenticated(),
        user,
        connections:   extras.oc_connections || [],
        addons:        extras.oc_addons      || [],
        services:      extras.oc_services    || [],
        plan:          extras.oc_plan        || null,
        localAlive:    health?.alive || _localAlive,
      }
    }
    case 'AUTH_LOGIN':
      // New token-paste flow has priority. Email+password fallback retained
      // for legacy logins.
      if (payload && payload.token) return performTokenLogin(payload.token)
      return performLogin(payload?.email, payload?.password)
    case 'AUTH_REGISTER':
      return performRegister(payload.name, payload.email, payload.password)
    case 'AUTH_LOGOUT':
      return performLogout()
    case 'PROFILE_SYNC': {
      const token = await storage.getToken()
      if (!token) return { success: false, error: 'Not logged in' }
      const data = await syncProfile(token)
      return { success: !!data, ...(data || {}) }
    }

    // ═══ Config ═══
    case 'CONFIG_GET': {
      const [mode, localUrl, user, health] = await Promise.all([
        storage.getApiMode(), storage.getLocalUrl(), storage.getUser(), storage.getLocalHealth(),
      ])
      return { success: true, mode, localUrl, user, health }
    }
    case 'CONFIG_SET_MODE': {
      await storage.setApiMode(payload.mode)
      if (payload.localUrl) await storage.setLocalUrl(payload.localUrl)
      await refreshClient()
      if (payload.mode === 'local') await checkLocalServer()
      return { success: true }
    }

    // ═══ Health ═══
    case 'HEALTH_CHECK': {
      const health = await checkLocalServer()
      return { success: true, ...health }
    }

    // ═══ Tool Execution (direct, FREE via local) ═══
    case 'TOOL_EXECUTE': {
      const client = await getClient()
      const result = await client.callTool(payload.tool, payload.args || {})
      await storage.trackEvent('tools_executed')
      return { success: true, result }
    }

    // ═══ AI Execute (natural language → 0nMCP) ═══
    case 'AI_EXECUTE': {
      const client = await getClient()
      const result = await client.execute(payload.command, payload.context || {})
      return { success: true, result }
    }

    // ═══ AI Compose ═══
    case 'AI_COMPOSE':
    case 'ai:compose': {
      const client = await getClient()
      const voice  = await storage.getVoice()
      const result = await client.compose({ ...payload, voice })
      await storage.trackEvent('messages_sent')
      return { success: true, result }
    }

    case 'AI_COMMENT':
    case 'ai:comment': {
      const client = await getClient()
      const voice  = await storage.getVoice()
      const result = await client.generateComment({ ...payload, voice })
      await storage.trackEvent('comments_posted')
      return { success: true, result }
    }

    case 'AI_POST': {
      const client = await getClient()
      const voice  = await storage.getVoice()
      const result = await client.generatePost({ ...payload, voice })
      await storage.trackEvent('posts_created')
      return { success: true, result }
    }

    // ═══ LinkedIn Generate (Anthropic + web_search — Snip & Reply) ═══
    case 'GENERATE_REPLY':
      return { success: true, data: await handleLinkedInGenerate(payload) }

    // ═══ Groq content generation ═══
    case '0n-generate': {
      const content = await generateContent(msg.prompt, msg.maxTokens || 800)
      return { content }
    }

    // ═══ Voice-Trained Generate ═══
    case 'GENERATE': {
      const uip     = await getUIP()
      const content = await handleVoiceGenerate({ topic: payload.topic || msg.topic, style: payload.style || msg.style, uip })
      return { success: true, content }
    }

    // ═══ UIP / Voice ═══
    case 'GET_UIP':
      return { uip: await getUIP() }

    case 'SAVE_VOICE': {
      const uip    = await getUIP()
      const merged = { ...uip, ...(msg.v || payload.voice || {}) }
      await saveUIP(merged)
      return { ok: true, uip: merged }
    }

    case 'VOICE_GET':
      return { success: true, voice: await storage.getVoice() }

    case 'VOICE_SAVE':
      await storage.setVoice(payload.voice)
      return { success: true }

    // ═══ Log OK/EDIT/NO (UIP training) ═══
    case 'LOG_OK': {
      const uip     = await getUIP()
      const approved = [msg.text || payload.text, ...(uip.approved || [])].filter(Boolean).slice(0, 20)
      await saveUIP({ ...uip, approved, count: (uip.count || 0) + 1 })
      return { ok: true }
    }

    case 'LOG_EDIT': {
      const uip       = await getUIP()
      const o         = msg.o || payload.original
      const c         = msg.c || payload.final
      const correction = { o, c, ts }
      const corrections = [correction, ...(uip.corrections || [])].slice(0, 30)
      const approved    = [c, ...(uip.approved || [])].filter(Boolean).slice(0, 20)
      await saveUIP({ ...uip, corrections, approved, count: (uip.count || 0) + 1 })
      return { ok: true }
    }

    case 'LOG_NO': {
      const uip       = await getUIP()
      const correction = { o: msg.text || payload.text, c: null, ts }
      const corrections = [correction, ...(uip.corrections || [])].slice(0, 30)
      await saveUIP({ ...uip, corrections })
      return { ok: true }
    }

    // ═══ Profile ═══
    case 'PROFILE_UPDATE': {
      await storage.setCurrentProfile(payload.profile)
      chrome.runtime.sendMessage({ action: 'PROFILE_CHANGED', profile: payload.profile }).catch(() => {})
      return { success: true }
    }
    case 'PROFILE_GET':
      return { success: true, profile: await storage.getCurrentProfile() }

    // ═══ CRM ═══
    case 'CRM_SAVE':
    case 'crm:save': {
      const client = await getClient()
      const result = await client.saveToCRM(payload.profile)
      await storage.trackEvent('crm_synced')
      return { success: true, result }
    }
    case 'CRM_SEARCH':
    case 'crm:search': {
      const client = await getClient()
      const result = await client.searchCRM(payload.query)
      return { success: true, result }
    }

    // ═══ Leads ═══
    case 'LEAD_SAVE': {
      const leads = await storage.saveLead(payload.lead)
      await storage.trackEvent('leads_saved')
      const settings = await storage.getSettings()
      if (settings.crmSync) {
        const client = await getClient()
        client.saveToCRM(payload.lead).catch(() => {})
        await storage.trackEvent('crm_synced')
      }
      return { success: true, leads }
    }
    case 'LEAD_DELETE': {
      await storage.deleteLead(payload.id)
      return { success: true, leads: await storage.getLeads() }
    }
    case 'LEADS_GET':
      return { success: true, leads: await storage.getLeads() }

    // ═══ Queue ═══
    case 'QUEUE_GET':
      return { success: true, queue: await storage.getQueue() }
    case 'QUEUE_SAVE':
      await storage.setQueue(payload.queue)
      return { success: true }

    // ═══ Analytics ═══
    case 'ANALYTICS_GET':
      return { success: true, analytics: await storage.getAnalytics() }

    // ═══ Settings ═══
    case 'SETTINGS_GET':
      return { success: true, settings: await storage.getSettings() }
    case 'SETTINGS_SAVE':
      await storage.setSettings(payload.settings)
      return { success: true }

    // ═══ Council ═══
    case 'ASK_ALL': {
      const response = await askAllProviders(msg.prompt)
      if (!response.error) {
        await storage.trackEvent('council_queries')
        await storage.addCouncilQuery({ prompt: msg.prompt, providers: response.results?.length || 0 })
      }
      return response
    }
    case 'ASK_ONE': {
      const result = await callProvider(msg.provider, msg.prompt)
      return { result }
    }
    case 'COUNCIL_CONFIG_GET': {
      const keys = await getKeys()
      const status = {}
      for (const p of Object.keys(PROVIDERS)) {
        status[p] = { name: PROVIDERS[p].name, hasKey: !!keys[p], color: PROVIDERS[p].color }
      }
      return { status }
    }
    case 'COUNCIL_CONFIG_SET':
      await chrome.storage.local.set({ oc_apiKeys: msg.keys || payload.keys })
      return { ok: true }
    case 'COUNCIL_HISTORY_GET':
      return { success: true, history: await storage.getCouncilHistory() }

    // ═══ Console / Browser Open ═══
    case 'OPEN_CONSOLE': {
      const url = payload.tool ? `https://0nmcp.com/console/${payload.tool}` : 'https://0nmcp.com/console'
      await chrome.tabs.create({ url, active: true })
      return { success: true }
    }

    // ═══ Scrape (relay to content script) ═══
    case 'SCRAPE_PROFILE': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
      if (!tab?.id) return { success: false, error: 'No active tab' }
      const profile = await sendToContentScript(tab.id, { type: 'DO_SCRAPE' })
      if (profile) {
        await storage.setCurrentProfile(profile)
        chrome.runtime.sendMessage({ action: 'PROFILE_CHANGED', profile }).catch(() => {})
      }
      return { success: true, profile }
    }

    // ═══ Vault Sync ═══
    case 'VAULT_SYNC': {
      const token = await storage.getToken()
      if (!token) return { success: false, error: 'Not logged in' }
      await syncVaultKeys(token)
      const keys = await getKeys()
      return { success: true, synced: Object.keys(keys).filter(k => keys[k]).length }
    }

    // ═══ Content Script Bridge ═══
    case 'TO_CONTENT': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
      if (!tab?.id) return { error: 'No active tab' }
      return new Promise((resolve) => {
        chrome.tabs.sendMessage(tab.id, msg.payload, (response) => {
          if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message })
          else resolve({ data: response })
        })
      })
    }

    // ═══ API Proxy ═══
    case '0n-api-call': {
      const token = await storage.getToken()
      const res = await fetch(`${AUTH_BASE}${msg.path}`, {
        method: msg.method || 'GET',
        headers: { 'Content-Type': 'application/json', ...(token ? { 'Authorization': `Bearer ${token}` } : {}) },
        body: msg.body ? JSON.stringify(msg.body) : undefined,
      })
      const data = await res.json()
      return { data }
    }

    // ═══ Auto-content alarms ═══
    case '0n-enable-auto':
      chrome.alarms.create('0n-auto-content', { periodInMinutes: 1440 })
      return { ok: true }
    case '0n-disable-auto':
      chrome.alarms.clear('0n-auto-content')
      return { ok: true }

    // ═══ Stack Scanner ═══
    case 'SCAN_REQUEST': {
      // 1. Resolve active tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
      if (!tab?.id || !tab?.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
        return { ok: false, error: 'Open a regular https:// page first.' }
      }
      const networkHosts = recentHostsForTab(tab.id)

      // 2. Inject the scan content script + run detectors in-page
      let scanResult
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['src/content/scan-injector.js'],
        })
        scanResult = await new Promise((resolve) => {
          chrome.tabs.sendMessage(
            tab.id,
            { action: 'SCAN_RUN', payload: { networkHosts } },
            (response) => resolve(response || { ok: false, error: 'no response' }),
          )
        })
      } catch (e) {
        return { ok: false, error: 'Inject failed: ' + (e?.message || e) }
      }
      if (!scanResult?.ok) {
        return { ok: false, error: scanResult?.error || 'detector failed' }
      }

      // 3. POST to /api/scanner/analyze for gap analysis + persistence
      try {
        const auth = await storage.getAuth?.() || {}
        const headers = { 'content-type': 'application/json' }
        if (auth?.token) headers['authorization'] = `Bearer ${auth.token}`
        const r = await fetch(`${AUTH_BASE}/api/scanner/analyze`, {
          method: 'POST',
          headers,
          body: JSON.stringify({
            url: scanResult.url,
            hostname: scanResult.hostname,
            detected: scanResult.detected,
            network_hosts: networkHosts,
          }),
        })
        const data = await r.json()
        if (!r.ok || !data.ok) {
          return { ok: false, error: data?.error || `analyze ${r.status}` }
        }
        return {
          ok: true,
          url: scanResult.url,
          hostname: scanResult.hostname,
          detected: scanResult.detected,
          gaps: data.gaps,
          recommendations: data.recommendations,
          stack_gap_score: data.stack_gap_score,
          scanId: data.scanId,
        }
      } catch (e) {
        return { ok: false, error: 'analyze: ' + e.message }
      }
    }

    case 'SCAN_SAVE_LEAD': {
      const auth = await storage.getAuth?.() || {}
      const headers = { 'content-type': 'application/json' }
      if (auth?.token) headers['authorization'] = `Bearer ${auth.token}`
      try {
        const r = await fetch(`${AUTH_BASE}/api/scanner/save-lead`, {
          method: 'POST',
          headers,
          body: JSON.stringify({
            scanId: payload?.scanId,
            email: payload?.email,
            name: payload?.name,
            phone: payload?.phone,
            location_id: payload?.location_id,
          }),
        })
        const data = await r.json()
        if (!r.ok || !data.ok) return { ok: false, error: data?.error || `save ${r.status}` }
        return { ok: true, contactId: data.contactId, tags: data.tags, upsertPath: data.upsertPath }
      } catch (e) {
        return { ok: false, error: e.message }
      }
    }

    // ═══ Auth check (legacy) ═══
    case 'CHECK': {
      const settings = await storage.getSettings()
      const apiKey = settings.anthropicKey || settings.groqKey || ''
      return { has: !!apiKey }
    }

    default:
      return { success: false, error: `Unknown action: ${action}` }
  }
}

// ── Initial health check on startup ──
checkLocalServer()
