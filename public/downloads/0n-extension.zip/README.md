# 0n — AI Command Center (Chrome Extension)

The free Chrome extension for [0nCore](https://0ncore.com).

LinkedIn VPIS scoring, AI content generation, multi-AI Council, and 1,554 tools via 0nMCP — right from your browser sidebar.

**Version:** 4.1.0 · **Manifest:** V3

---

## Install

**From the Chrome Web Store** (free): _coming soon_

**Manual install (developer mode):**
1. Clone: `git clone https://github.com/0nork/0n-extension.git`
2. Open `chrome://extensions/`, toggle **Developer mode** on (top right)
3. Click **Load unpacked** → select this folder

---

## Connect

The extension authenticates with a token issued from your 0nCore dashboard.

1. Sign up free at <https://0ncore.com/signup> (or sign in at <https://0ncore.com/login>)
2. Visit **Settings → Extension**: <https://0ncore.com/dashboard/settings/extension>
3. Click **Generate**, copy the token
4. In the extension sidebar, paste the token and click **Connect**

That's it. The extension is now signed in and tied to your 0nCore account.

Tokens never expire. Revoke any token from the dashboard to instantly invalidate the extension instance using it.

---

## Features

- **LinkedIn VPIS** — score any post against the 8-factor viral formula, generate vibe-style comments
- **AI Content** — Groq-backed post + email + blog generation (no API keys required on free tier)
- **Multi-AI Council** — query GPT, Gemini, Grok, and Claude in parallel
- **0nMCP Tools** — direct execution of any of 1,554 tools via your local `0nmcp serve` instance (FREE)
- **Snip & Reply** — capture any LinkedIn post + draft an AI reply in seconds
- **0nTask** — quick-add, list and complete tasks against `app.0ntask.com` on the SAME 0n key, plus a right-click "Add to 0nTask" on any page

## Architecture

The extension is **local-first** when 0nMCP is running on your desktop (free AI execution via your local Claude/GPT/Groq keys), and **cloud-fallback** to 0ncore.com when local is unavailable.

```
Chrome Extension (this repo)
  ├─ Side panel UI — 8 tabs
  ├─ Token-based auth → 0ncore.com
  ├─ Local-first execution → http://localhost:3000 (0nmcp serve)
  └─ Cloud fallback → https://0ncore.com/api/*
```

## License

BSL 1.1 © RocketOpp LLC. Free for end-user use. Commercial integration requires a license — see [tldraw-style terms].

## Links

- **Web app:** <https://0ncore.com>
- **0nMCP npm:** <https://www.npmjs.com/package/0nmcp>
- **Issues:** <https://github.com/0nork/0n-extension/issues>
