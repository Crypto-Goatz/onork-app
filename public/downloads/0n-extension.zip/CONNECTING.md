# Connecting the extension

The extension never holds a CRM credential. It holds a **device key**
(`0n_live_…`) and trades it for a short-lived app token on each request.

```
device key  →  POST /api/auth/device/exchange  →  app JWT (15 min)  →  0nCORE
 long-lived, revocable                              stateless
```

Lose the laptop, revoke that one device in 0nCORE; every other device keeps
working. The app JWT is held in memory only — writing it to storage would
outlive its usefulness and add a second thing to leak.

## Install

1. `chrome://extensions` → enable **Developer mode**
2. **Load unpacked** → select this folder
3. Open the side panel from the toolbar icon

## Connect — two ways

**Automatic.** Sign in at `app.0ncore.com` with the extension installed. The
`on-identity` content script captures your `0n_` token same-origin and stores
it. The panel connects with no pasting.

**Manual.** 0nCORE → **Setup & Keys** → *Connect Extension* → a device key is
shown **once**. Paste it into the panel's Account tab.

## Requirements

Issuing a device key needs a **free account chosen** — a key is scoped to a
client, so there has to be one to scope it to.

## Verify

Account tab shows a green dot and the active client. It reports what is TRUE
now: it performs an exchange rather than trusting a flag, so a device revoked
in 0nCORE reads as disconnected on the next check.
