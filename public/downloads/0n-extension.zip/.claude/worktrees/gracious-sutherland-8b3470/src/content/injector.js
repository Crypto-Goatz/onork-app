/**
 * 0nCore Chrome Extension v3.0 — LinkedIn Unified Content Script
 *
 * Merged from 4 separate extensions into one. Covers:
 *   - Page type detection
 *   - Profile scraping
 *   - Feed scanning
 *   - Search result scraping
 *   - Text injection (post / comment / message / connect / search)
 *   - LinkedIn "Post Now" injection with trigger click
 *   - 0n button injection on post pages
 *   - SPA navigation handling
 *   - Full message listener for all action types
 *   - Toast notifications
 */

// ─────────────────────────────────────────────
// PAGE TYPE DETECTION
// ─────────────────────────────────────────────

function detectPage() {
  const path = location.pathname
  if (path.includes('/in/'))            return 'profile'
  if (path.includes('/feed'))           return 'feed'
  if (path.includes('/messaging'))      return 'messaging'
  if (path.includes('/mynetwork'))      return 'network'
  if (path.includes('/jobs'))           return 'jobs'
  if (path.includes('/search'))         return 'search'
  if (path.includes('/company'))        return 'company'
  if (
    path.includes('/posts/') ||
    path.includes('/feed/update/') ||
    path.includes('/pulse/')
  )                                     return 'post'
  return 'other'
}

// ─────────────────────────────────────────────
// PROFILE SCRAPER
// ─────────────────────────────────────────────

function scrapeProfile() {
  function txt(selector) {
    const el = document.querySelector(selector)
    return el ? el.innerText.trim() : null
  }

  function txtAll(selector, limit) {
    return Array.from(document.querySelectorAll(selector))
      .slice(0, limit)
      .map(el => el.innerText.trim())
      .filter(Boolean)
  }

  // Experience — up to 6 entries
  const experience = Array.from(
    document.querySelectorAll('#experience ~ div .pvs-list__paged-list-item')
  ).slice(0, 6).map(item => ({
    title:    item.querySelector('.t-bold span')?.innerText.trim() || null,
    company:  item.querySelector('.t-normal span')?.innerText.trim() || null,
    duration: item.querySelector('.t-black--light span')?.innerText.trim() || null,
  }))

  // Education — up to 3 entries
  const education = Array.from(
    document.querySelectorAll('#education ~ div .pvs-list__paged-list-item')
  ).slice(0, 3).map(item => ({
    school: item.querySelector('.t-bold span')?.innerText.trim() || null,
    degree: item.querySelector('.t-normal span')?.innerText.trim() || null,
  }))

  // Skills — up to 15
  const skills = Array.from(
    document.querySelectorAll('#skills ~ div .hoverable-link-text span')
  ).slice(0, 15).map(el => el.innerText.trim()).filter(Boolean)

  return {
    name:        txt('.text-heading-xlarge') || txt('h1'),
    headline:    txt('.text-body-medium.break-words'),
    location:    txt('.text-body-small.inline.t-black--light.break-words'),
    about:       txt('#about ~ div .inline-show-more-text') || txt('.pv-about__summary-text'),
    connections: (() => {
      const nodes = document.querySelectorAll('.t-bold:not(.text-heading-xlarge)')
      for (const el of nodes) {
        const t = el.innerText.trim()
        if (/connection|follower/i.test(t)) return t
      }
      return null
    })(),
    experience,
    education,
    skills,
    url: location.href,
  }
}

// ─────────────────────────────────────────────
// FEED SCANNER
// ─────────────────────────────────────────────

function scrapePost(el) {
  function txt(selector) {
    const found = el.querySelector(selector)
    return found ? found.innerText.trim() : null
  }
  return {
    author:    txt('.update-components-actor__name span'),
    headline:  txt('.update-components-actor__description'),
    content:   txt('.update-components-text span'),
    reactions: txt('.social-details-social-counts__reactions-count'),
    comments:  txt('.social-details-social-counts__comments'),
  }
}

function scanFeed() {
  const items = Array.from(
    document.querySelectorAll('.feed-shared-update-v2, .occludable-update')
  ).slice(0, 10)
  return items.map(scrapePost)
}

// ─────────────────────────────────────────────
// VPIS FEED SCANNER — overlays score badges on posts
// ─────────────────────────────────────────────

function injectVPISBadges() {
  if (detectPage() !== 'feed') return

  const posts = document.querySelectorAll('.feed-shared-update-v2, .occludable-update')
  posts.forEach(post => {
    if (post.querySelector('.onmcp-vpis-badge')) return // Already badged

    const contentEl = post.querySelector('.update-components-text span')
    if (!contentEl) return
    const content = contentEl.innerText?.trim()
    if (!content || content.length < 50) return

    // Quick client-side VPIS estimate (lightweight version)
    const score = quickVPIS(content)
    const grade = score >= 90 ? 'S' : score >= 80 ? 'A' : score >= 70 ? 'B' : score >= 60 ? 'C' : 'D'
    const color = score >= 80 ? '#6EE05A' : score >= 60 ? '#14b8a6' : score >= 40 ? '#f59e0b' : '#ef4444'

    const badge = document.createElement('div')
    badge.className = 'onmcp-vpis-badge'
    badge.innerHTML = `<span style="font-weight:800;color:${color}">${grade}</span><span style="font-size:9px;color:#9ca3af">${score}</span>`
    badge.style.cssText = `
      position:absolute; top:8px; right:8px; z-index:100;
      display:flex; flex-direction:column; align-items:center; gap:0;
      background:#161b22; border:1px solid ${color}40; border-radius:8px;
      padding:4px 8px; font-family:system-ui; font-size:13px; line-height:1.2;
      cursor:pointer; transition:all 0.15s;
    `
    badge.title = `VPIS Score: ${score}/100 (${grade})\nClick to generate a comment`

    badge.addEventListener('click', (e) => {
      e.stopPropagation()
      chrome.storage.local.set({
        linkedin_current_url: getCurrentPostUrl(),
        linkedin_post_content: content,
        linkedin_post_author: post.querySelector('.update-components-actor__name span')?.innerText?.trim() || '',
        linkedin_is_post: true,
        popup_trigger: Date.now(),
      })
      chrome.runtime.sendMessage({ type: 'OPEN_SIDEBAR' })
    })

    // Make post container relative for badge positioning
    const wrapper = post.querySelector('.feed-shared-update-v2__description, .update-components-text')?.parentElement
    if (wrapper) {
      wrapper.style.position = 'relative'
      wrapper.appendChild(badge)
    }
  })
}

// Lightweight client-side VPIS (no API call — runs instantly on every post)
function quickVPIS(text) {
  let score = 50
  const words = text.split(/\s+/).length
  const lines = text.split('\n')
  const firstLine = lines[0] || ''

  // Hook signals
  if (/^\d/.test(firstLine)) score += 8
  if (firstLine.length < 60) score += 5
  if (/^(Most|Nobody|Everyone|The truth|Here's what|Stop|Don't)/i.test(firstLine)) score += 8

  // Structure
  if (words >= 100 && words <= 250) score += 10
  if (text.split(/\n\n+/).length >= 4) score += 5
  if (words > 300) score -= 8

  // Anti-patterns
  if (/^I'm excited/im.test(text)) score -= 12
  if (/thoughts\?$/im.test(text)) score -= 15
  if ((text.match(/#\w+/g) || []).length >= 5) score -= 25
  if (/https?:\/\//.test(text)) score -= 15
  if (/game.?changer|innovative|cutting.?edge/i.test(text)) score -= 8
  if (/leverage|synergy|stakeholder|utilize/i.test(text)) score -= 5

  // Viral signals
  if (/but|however|instead|actually/i.test(text)) score += 5
  if (/\$\d/.test(text)) score += 5
  if (/\d+%/.test(text)) score += 5

  // Platform optimization
  if ((text.match(/#\w+/g) || []).length === 0) score += 8

  // CTA
  if (/\?$/.test(text.trim())) score += 5

  return Math.min(100, Math.max(0, score))
}

// Run VPIS badge scan periodically (LinkedIn is a SPA, new posts load dynamically)
setInterval(injectVPISBadges, 5000)
setTimeout(injectVPISBadges, 3000) // Initial run after page load

// ─────────────────────────────────────────────
// SEARCH RESULTS SCRAPER
// ─────────────────────────────────────────────

function scrapeSearch() {
  const items = Array.from(
    document.querySelectorAll('.entity-result__item, .reusable-search__result-container')
  ).slice(0, 20)

  return items.map(item => ({
    name:     item.querySelector('.entity-result__title-text a span span')?.innerText.trim() || null,
    headline: item.querySelector('.entity-result__primary-subtitle')?.innerText.trim() || null,
    location: item.querySelector('.entity-result__secondary-subtitle')?.innerText.trim() || null,
    url:      item.querySelector('.entity-result__title-text a')?.href || null,
  }))
}

// ─────────────────────────────────────────────
// POST URL DETECTION
// ─────────────────────────────────────────────

const LINKEDIN_POST_PATTERNS = [
  /linkedin\.com\/posts\//,
  /linkedin\.com\/feed\/update\//,
  /linkedin\.com\/pulse\//,
]

function isPostPage(url) {
  return LINKEDIN_POST_PATTERNS.some(pattern => pattern.test(url))
}

function getCurrentPostUrl() {
  const canonical = document.querySelector('link[rel="canonical"]')
  return canonical?.href || location.href
}

// ─────────────────────────────────────────────
// URL STORAGE FOR SIDEBAR AUTO-FILL
// ─────────────────────────────────────────────

function updateStoredUrl() {
  const url = getCurrentPostUrl()
  const isPost = isPostPage(url)
  chrome.storage.local.set({
    linkedin_current_url: url,
    linkedin_is_post: isPost,
  })
}

// ─────────────────────────────────────────────
// TEXT INJECTION — inject(text, target)
// ─────────────────────────────────────────────

const TARGET_SELECTORS = {
  post:    ['.ql-editor[contenteditable]', '[role="textbox"][contenteditable="true"]'],
  comment: ['.comments-comment-box__form [contenteditable]', '.ql-editor'],
  message: ['.msg-form__contenteditable', '[role="textbox"][contenteditable]'],
  connect: ['#custom-message', 'textarea[name="message"]'],
  search:  ['.search-global-typeahead__input'],
}

function inject(text, target) {
  const selectors = TARGET_SELECTORS[target] || TARGET_SELECTORS.post

  for (const sel of selectors) {
    const el = document.querySelector(sel)
    if (!el) continue

    const isContentEditable =
      el.isContentEditable || el.getAttribute('contenteditable') === 'true'

    if (isContentEditable) {
      el.focus()
      el.innerHTML = text
      el.dispatchEvent(new Event('input', { bubbles: true }))
    } else {
      el.focus()
      el.value = text
      el.dispatchEvent(new Event('input', { bubbles: true }))
    }

    showToast('Content injected')
    return { ok: true, selector: sel }
  }

  // Fallback: clipboard
  navigator.clipboard.writeText(text).then(() =>
    showToast('Copied to clipboard (no matching field)')
  )
  return { ok: false, fallback: 'clipboard' }
}

// ─────────────────────────────────────────────
// LINKEDIN "POST NOW" INJECTION — injectPost(text)
// ─────────────────────────────────────────────

const POST_TRIGGER_SELECTORS = [
  '.share-box-feed-entry__trigger',
  '[data-control-name="share.sharebox_text"]',
  '[aria-label*="start a post" i]',
  '[placeholder*="start a post" i]',
  '.share-creation-state__placeholder',
  '.artdeco-button--muted[aria-label*="post" i]',
]

async function injectPost(text) {
  // Step 1: Click the LinkedIn "start a post" trigger
  let triggered = false
  for (const sel of POST_TRIGGER_SELECTORS) {
    const el = document.querySelector(sel)
    if (el) {
      el.click()
      triggered = true
      break
    }
  }

  if (!triggered) {
    // Fallback directly to clipboard
    await navigator.clipboard.writeText(text)
    showToast('Copied to clipboard — no post trigger found')
    return { ok: false, fallback: 'clipboard' }
  }

  // Step 2: Wait for the editor to appear
  await new Promise(resolve => setTimeout(resolve, 800))

  const editor = document.querySelector('.ql-editor[contenteditable="true"]')
  if (editor) {
    editor.focus()
    // Use execCommand for reliable insertion into Quill
    document.execCommand('selectAll', false, null)
    document.execCommand('insertText', false, text)
    showToast('Post drafted')
    return { ok: true }
  }

  // Fallback: clipboard
  await navigator.clipboard.writeText(text)
  showToast('Copied to clipboard — editor not found after trigger')
  return { ok: false, fallback: 'clipboard' }
}

// ─────────────────────────────────────────────
// INJECT "0n" BUTTON
// ─────────────────────────────────────────────

function injectButtonIfNeeded() {
  if (!isPostPage(location.href)) return
  if (document.getElementById('onmcp-reply-btn')) return

  const commentBox = document.querySelector(
    '.comments-comment-box, .comments-comment-texteditor, [data-placeholder="Add a comment\u2026"]'
  )
  if (!commentBox) return

  const container = commentBox.closest(
    '.comments-comment-box-comment__text-editor, .comments-comment-box'
  )
  if (!container) return

  const btn = document.createElement('button')
  btn.id = 'onmcp-reply-btn'
  btn.innerHTML =
    '<span style="font-size:10px;font-weight:800;letter-spacing:0.05em;color:#6EE05A;">0n</span>' +
    '<span style="font-size:11px;color:#999;">&#8599;</span>'
  btn.title = 'Generate reply with 0nCore'
  btn.style.cssText = [
    'position:absolute',
    'top:-36px',
    'right:0',
    'background:#161b22',
    'border:1px solid #30363d',
    'border-radius:6px',
    'padding:4px 10px',
    'cursor:pointer',
    'display:flex',
    'align-items:center',
    'gap:3px',
    'box-shadow:0 2px 8px rgba(0,0,0,0.3)',
    'z-index:9999',
    'transition:all 0.2s',
    'font-family:system-ui,sans-serif',
  ].join(';')

  btn.addEventListener('mouseenter', () => {
    btn.style.boxShadow = '0 4px 16px rgba(110,224,90,0.15)'
    btn.style.borderColor = '#6EE05A'
  })
  btn.addEventListener('mouseleave', () => {
    btn.style.boxShadow = '0 2px 8px rgba(0,0,0,0.3)'
    btn.style.borderColor = '#30363d'
  })

  btn.addEventListener('click', e => {
    e.preventDefault()
    e.stopPropagation()
    chrome.storage.local.set({
      linkedin_current_url: getCurrentPostUrl(),
      linkedin_is_post: true,
      popup_trigger: Date.now(),
    })
    chrome.runtime.sendMessage({ type: 'OPEN_SIDEBAR' })
  })

  const wrapper = container.parentElement
  if (wrapper) {
    wrapper.style.position = 'relative'
    wrapper.appendChild(btn)
  }
}

// ─────────────────────────────────────────────
// INSERT CONTENT (legacy / fallback helper)
// ─────────────────────────────────────────────

function insertContent(content) {
  // Priority 1: Active element
  const active = document.activeElement
  if (
    active &&
    (active.tagName === 'TEXTAREA' ||
      active.tagName === 'INPUT' ||
      active.isContentEditable)
  ) {
    if (active.isContentEditable) {
      active.innerText = content
    } else {
      active.value = content
    }
    active.dispatchEvent(new Event('input', { bubbles: true }))
    showToast('Content inserted')
    return
  }

  // Priority 2: Known selectors
  const selectors = [
    '.ql-editor',
    '[role="textbox"]',
    '.msg-form__contenteditable',
    '[contenteditable="true"]',
    'textarea[name="body"]',
  ]
  for (const sel of selectors) {
    const el = document.querySelector(sel)
    if (el) {
      if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
        el.innerText = content
      } else {
        el.value = content
      }
      el.dispatchEvent(new Event('input', { bubbles: true }))
      el.focus()
      showToast('Content inserted')
      return
    }
  }

  // Fallback: clipboard
  navigator.clipboard.writeText(content).then(() =>
    showToast('Copied to clipboard (no text field found)')
  )
}

// ─────────────────────────────────────────────
// TOAST NOTIFICATION
// ─────────────────────────────────────────────

function showToast(message) {
  const existing = document.getElementById('onmcp-toast')
  if (existing) existing.remove()

  // Inject keyframes once
  if (!document.getElementById('onmcp-styles')) {
    const style = document.createElement('style')
    style.id = 'onmcp-styles'
    style.textContent =
      '@keyframes onmcp-slide-in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}'
    document.head.appendChild(style)
  }

  const toast = document.createElement('div')
  toast.id = 'onmcp-toast'
  toast.textContent = message
  toast.style.cssText = [
    'position:fixed',
    'bottom:20px',
    'right:20px',
    'z-index:999999',
    'background:#161b22',
    'color:#6EE05A',
    'border:1px solid rgba(110,224,90,0.4)',
    'padding:10px 16px',
    'border-radius:8px',
    'font-size:13px',
    'font-weight:600',
    'font-family:system-ui,sans-serif',
    'box-shadow:0 4px 16px rgba(0,0,0,0.4)',
    'animation:onmcp-slide-in 0.2s ease',
  ].join(';')

  document.body.appendChild(toast)
  setTimeout(() => toast.remove(), 3000)
}

// ─────────────────────────────────────────────
// SPA NAVIGATION HANDLER
// ─────────────────────────────────────────────

let lastUrl = location.href

const urlObserver = new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href
    updateStoredUrl()
    setTimeout(injectButtonIfNeeded, 1500)
  }
})

urlObserver.observe(document.body, { subtree: true, childList: true })

// ─────────────────────────────────────────────
// INITIALISE ON LOAD
// ─────────────────────────────────────────────

updateStoredUrl()
setTimeout(injectButtonIfNeeded, 2000)

// ─────────────────────────────────────────────
// MESSAGE LISTENER
// ─────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const reply = data => { sendResponse(data); }

  switch (msg.type) {

    case 'DO_SCRAPE':
      reply(scrapeProfile())
      break

    case 'DO_SCAN':
      reply({ page: detectPage(), posts: scanFeed() })
      break

    case 'DO_SEARCH_SCRAPE':
      reply({ results: scrapeSearch() })
      break

    case 'DO_INJECT':
      reply(inject(msg.text, msg.target))
      break

    case 'DO_POST':
      // async — must return true to keep channel open
      injectPost(msg.text).then(reply)
      return true

    case 'GET_PAGE':
      reply({ page: detectPage(), url: location.href })
      break

    case '0n-content-generated':
    case '0n-insert-content':
      insertContent(msg.content)
      break

    case '0n-copy-to-clipboard':
      navigator.clipboard.writeText(msg.content).then(() =>
        showToast('Copied to clipboard')
      )
      break

    default:
      break
  }

  return true // Keep message channel open for all cases
})
