<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap oncore-admin">
  <h1>0nCore CRM</h1>
  <p class="subtitle">Manage your CRM connection. All form submissions automatically flow into your CRM with full UTM tracking.</p>

  <div class="oncore-card">
    <h2><span class="dot"></span> Connection Status</h2>
    <?php
    $pit = get_option('oncore_crm_pit', '');
    $webhook = get_option('oncore_crm_webhook', '');
    $location = get_option('oncore_crm_location_id', '');
    ?>
    <div class="oncore-status <?php echo ($pit || $webhook) ? 'oncore-status-success' : 'oncore-status-error'; ?>">
      <?php if ($pit && $location): ?>
        Direct API: Connected (Location: <?php echo esc_html(substr($location, 0, 8)); ?>...)
      <?php elseif ($webhook): ?>
        Webhook: Configured
      <?php else: ?>
        Not configured — go to Settings to add CRM credentials
      <?php endif; ?>
    </div>
  </div>

  <div class="oncore-card">
    <h2><span class="dot"></span> How It Works</h2>
    <ol style="font-size:14px;line-height:2;color:#374151;padding-left:20px;">
      <li>A visitor lands on your site (UTM params are auto-captured into a cookie)</li>
      <li>They fill out any <code>[oncore_form]</code> shortcode on any page</li>
      <li>The form submits to your CRM via webhook or direct API</li>
      <li>Contact is created with: name, email, phone, UTM source, tags, custom fields</li>
      <li>If they came from Facebook ads → tagged <code>facebook-ad</code></li>
      <li>If they came from Google ads → tagged <code>google-ad</code> + <code>pmax-remarketing</code></li>
      <li>Campaign name auto-tagged as <code>campaign-{name}</code></li>
    </ol>
  </div>

  <div class="oncore-card">
    <h2><span class="dot"></span> CRM Tags Reference</h2>
    <table style="width:100%;font-size:13px;border-collapse:collapse;">
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;font-weight:600;">website-lead</td><td style="padding:8px;color:#6b7280;">Applied to every form submission</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;font-weight:600;">0ncore</td><td style="padding:8px;color:#6b7280;">Identifies leads from 0nCore-powered sites</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;font-weight:600;">facebook-ad</td><td style="padding:8px;color:#6b7280;">Came from Facebook/Meta ads (fbclid detected)</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;font-weight:600;">google-ad</td><td style="padding:8px;color:#6b7280;">Came from Google Ads (gclid detected)</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;font-weight:600;">pmax-remarketing</td><td style="padding:8px;color:#6b7280;">Eligible for Google PMax remarketing</td></tr>
      <tr><td style="padding:8px;font-weight:600;">campaign-{name}</td><td style="padding:8px;color:#6b7280;">Auto-tagged with UTM campaign name</td></tr>
    </table>
  </div>
</div>
