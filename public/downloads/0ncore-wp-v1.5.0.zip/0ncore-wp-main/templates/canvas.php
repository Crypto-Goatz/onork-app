<?php
/**
 * 0nCore Canvas Template
 *
 * Zero theme. Pure content. Full control.
 * This template completely bypasses the WordPress theme.
 * Only 0nCore tracking, schema, and the page content are rendered.
 */
if (!defined('ABSPATH')) exit;

// ── Strip ALL theme styles and scripts on canvas pages ──
add_action('wp_enqueue_scripts', function() {
    global $wp_styles, $wp_scripts;

    // Keep only essential WP scripts
    $keep_scripts = ['jquery', 'jquery-core', 'jquery-migrate', 'wp-embed'];
    $keep_styles = [];

    if ($wp_styles) {
        foreach ($wp_styles->registered as $handle => $style) {
            if (!in_array($handle, $keep_styles)) {
                wp_dequeue_style($handle);
                wp_deregister_style($handle);
            }
        }
    }
    if ($wp_scripts) {
        foreach ($wp_scripts->registered as $handle => $script) {
            // Keep jQuery and our own scripts
            if (!in_array($handle, $keep_scripts) &&
                strpos($handle, 'oncore') === false &&
                strpos($handle, 'wpsxo') === false &&
                strpos($handle, 'jquery') === false) {
                wp_dequeue_script($handle);
            }
        }
    }
}, 9999);

// Also remove theme head actions
remove_all_actions('wp_head');
// Re-add only what we need
add_action('wp_head', 'wp_enqueue_scripts', 1);
add_action('wp_head', 'wp_print_styles', 8);
add_action('wp_head', 'wp_print_head_scripts', 9);
add_action('wp_head', 'wp_site_icon', 99);

// Remove footer scripts from theme
remove_all_actions('wp_footer');
add_action('wp_footer', 'wp_print_footer_scripts', 20);

$post_id = get_the_ID();
$title = get_the_title();
$content = apply_filters('the_content', get_the_content());

// Page settings from meta
$page_css = get_post_meta($post_id, '_oncore_page_css', true);
$page_js = get_post_meta($post_id, '_oncore_page_js', true);
$head_scripts = get_post_meta($post_id, '_oncore_head_scripts', true);
$body_class = get_post_meta($post_id, '_oncore_body_class', true);
$hide_nav = get_post_meta($post_id, '_oncore_hide_nav', true);
$nav_logo = get_post_meta($post_id, '_oncore_nav_logo', true);
$cta_text = get_post_meta($post_id, '_oncore_nav_cta_text', true) ?: 'Book Now';
$cta_url = get_post_meta($post_id, '_oncore_nav_cta_url', true);
$bg_color = get_post_meta($post_id, '_oncore_bg_color', true) ?: '#F5EDE0';
$font_display = get_post_meta($post_id, '_oncore_font_display', true) ?: 'Playfair Display';
$font_body = get_post_meta($post_id, '_oncore_font_body', true) ?: 'Lato';

// Business info
$biz_name = get_option('oncore_business_name', get_bloginfo('name'));
$biz_phone = get_option('oncore_business_phone', '');
$pixel_id = get_option('oncore_fb_pixel_id', '');
$ga4_id = get_option('oncore_ga4_id', '');

// Build Google Fonts URL
$fonts = [];
if ($font_display) $fonts[] = str_replace(' ', '+', $font_display) . ':ital,wght@0,300;0,400;0,500;0,600;0,700;1,400';
if ($font_body && $font_body !== $font_display) $fonts[] = str_replace(' ', '+', $font_body) . ':wght@300;400;500;600;700';
$fonts_url = 'https://fonts.googleapis.com/css2?family=' . implode('&family=', $fonts) . '&display=swap';

// SEO
$meta_title = get_post_meta($post_id, '_yoast_wpseo_title', true) ?: $title . ' | ' . $biz_name;
$meta_desc = get_post_meta($post_id, '_yoast_wpseo_metadesc', true) ?: get_the_excerpt();
$canonical = get_permalink($post_id);
?>
<!DOCTYPE html>
<html lang="<?php echo get_bloginfo('language'); ?>">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo esc_html($meta_title); ?></title>
<meta name="description" content="<?php echo esc_attr($meta_desc); ?>">
<link rel="canonical" href="<?php echo esc_url($canonical); ?>">

<!-- OG Tags -->
<meta property="og:title" content="<?php echo esc_attr($meta_title); ?>">
<meta property="og:description" content="<?php echo esc_attr($meta_desc); ?>">
<meta property="og:url" content="<?php echo esc_url($canonical); ?>">
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?php echo esc_attr($biz_name); ?>">

<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="<?php echo esc_url($fonts_url); ?>" rel="stylesheet">

<!-- 0nCore Base Reset -->
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;-webkit-text-size-adjust:100%}
body{
  font-family:'<?php echo esc_attr($font_body); ?>',system-ui,sans-serif;
  color:#2C1810;line-height:1.7;
  background:<?php echo esc_attr($bg_color); ?>;
  -webkit-font-smoothing:antialiased;
  -moz-osx-font-smoothing:grayscale;
  overflow-x:hidden;
  font-size:17px;
}
img{max-width:100%;height:auto;display:block}
a{text-decoration:none;color:inherit}
</style>

<?php if ($page_css): ?>
<style><?php echo $page_css; // Already sanitized on save ?></style>
<?php endif; ?>

<?php
// Meta Pixel
if ($pixel_id): ?>
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init','<?php echo esc_js($pixel_id); ?>');fbq('track','PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=<?php echo esc_attr($pixel_id); ?>&ev=PageView&noscript=1"/></noscript>
<?php endif;

// GA4
if ($ga4_id): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo esc_attr($ga4_id); ?>"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','<?php echo esc_js($ga4_id); ?>');</script>
<?php endif;

// UTM capture
if (get_option('oncore_utm_tracking', '1') === '1'): ?>
<script>
(function(){var p=new URLSearchParams(location.search);var u=['utm_source','utm_medium','utm_campaign','utm_content','utm_term','fbclid','gclid','ref'];var d={};u.forEach(function(k){var v=p.get(k);if(v)d[k]=v;});if(Object.keys(d).length>0){document.cookie='oncore_utm='+encodeURIComponent(JSON.stringify(d))+';path=/;max-age=2592000;SameSite=Lax';}
if(d.fbclid||d.gclid||d.utm_source){if(window.fbq)fbq('track','ViewContent',{content_name:document.title,content_type:'page'});if(window.gtag)gtag('event','view_item',{items:[{item_name:document.title}]});}
})();
</script>
<?php endif;

// Schema.org
$schema_type = get_option('oncore_schema_type', 'LocalBusiness');
$biz_email = get_option('oncore_business_email', '');
$biz_address = get_option('oncore_business_address', '');
$biz_lat = get_option('oncore_business_lat', '');
$biz_lng = get_option('oncore_business_lng', '');

if ($biz_name):
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => $schema_type,
        'name' => $biz_name,
        'url' => home_url('/'),
    ];
    if ($biz_phone) $schema['telephone'] = $biz_phone;
    if ($biz_email) $schema['email'] = $biz_email;
    if ($biz_address) {
        $parts = array_map('trim', explode(',', $biz_address));
        $schema['address'] = [
            '@type' => 'PostalAddress',
            'streetAddress' => $parts[0] ?? '',
            'addressLocality' => $parts[1] ?? '',
            'addressRegion' => trim(explode(' ', trim($parts[2] ?? ''))[0] ?? ''),
            'postalCode' => trim(explode(' ', trim($parts[2] ?? ''))[1] ?? ''),
            'addressCountry' => 'US',
        ];
    }
    if ($biz_lat && $biz_lng) {
        $schema['geo'] = ['@type' => 'GeoCoordinates', 'latitude' => (float)$biz_lat, 'longitude' => (float)$biz_lng];
    }
?>
<script type="application/ld+json"><?php echo wp_json_encode($schema, JSON_UNESCAPED_SLASHES); ?></script>
<?php endif;

// Custom head scripts
if ($head_scripts) echo $head_scripts;
?>

<?php wp_head(); ?>
</head>
<body class="oncore-canvas <?php echo esc_attr($body_class); ?>">

<?php echo $content; ?>

<?php if ($page_js): ?>
<script><?php echo $page_js; ?></script>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
