<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap oncore-admin">
  <h1>0nCore Booking</h1>
  <p class="subtitle">MassageBook integration — embed booking buttons and service menus on any page.</p>

  <div class="oncore-card">
    <h2><span class="dot"></span> Connection</h2>
    <?php $biz_id = get_option('oncore_booking_business_id', '1554118'); ?>
    <div class="oncore-status oncore-status-success">
      MassageBook Business ID: <?php echo esc_html($biz_id); ?>
    </div>
    <p style="margin-top:8px;font-size:12px;color:#6b7280;">
      <a href="https://www.massagebook.com/business/<?php echo esc_attr($biz_id); ?>" target="_blank" style="color:#2c4b43;">View your MassageBook page →</a>
    </p>
  </div>

  <div class="oncore-card">
    <h2><span class="dot"></span> Booking Shortcodes</h2>
    <div class="oncore-shortcode-ref">
      <h3>Single Booking Button</h3>
      <code>[oncore_booking service_id="219925" label="Book a Facial"]</code>
      <div class="desc">Links to a specific service. Every click fires a Lead conversion event.</div>

      <h3>Full Facial Menu</h3>
      <code>[oncore_booking_list category="facials"]</code>
      <div class="desc">Shows all 12 facials with prices, descriptions, and individual Book buttons.</div>

      <h3>Massage Menu</h3>
      <code>[oncore_booking_list category="massage"]</code>
      <div class="desc">Shows all massage services.</div>

      <h3>CTA Block with Booking</h3>
      <code>[oncore_cta title="Ready for Your Best Skin?" button="Book Your Facial" service_id="219925" style="dark"]Experience the difference professional skincare makes.[/oncore_cta]</code>
      <div class="desc">Full-width CTA block that links to booking.</div>
    </div>
  </div>

  <div class="oncore-card">
    <h2><span class="dot"></span> Popular Service IDs</h2>
    <table style="width:100%;font-size:13px;border-collapse:collapse;">
      <tr style="border-bottom:1px solid #e5e7eb;background:#f9fafb;"><td style="padding:8px;font-weight:700;">Service</td><td style="padding:8px;font-weight:700;">ID</td><td style="padding:8px;font-weight:700;">Price</td></tr>
      <?php
      $services = OnCore_Booking::get_services('facials');
      foreach (array_slice($services, 0, 6) as $s):
      ?>
      <tr style="border-bottom:1px solid #e5e7eb;">
        <td style="padding:8px;"><?php echo esc_html($s['name']); ?></td>
        <td style="padding:8px;"><code><?php echo esc_html($s['id']); ?></code></td>
        <td style="padding:8px;"><?php echo esc_html($s['price']); ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
</div>
