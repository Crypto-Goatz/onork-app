<?php if (!defined('ABSPATH')) exit;
$license = OnCore_License::get_license();
$step = intval($_GET['step'] ?? 1);
?>
<div class="wrap oncore-admin">
<style>
.onboard-wrap { max-width: 640px; margin: 0 auto; }
.onboard-header { text-align: center; margin-bottom: 32px; }
.onboard-header h1 { font-size: 28px; font-weight: 700; color: #1a2c27; }
.onboard-header p { color: #6b7280; font-size: 14px; margin-top: 6px; }
.onboard-steps { display: flex; gap: 4px; margin-bottom: 32px; }
.onboard-step { flex: 1; height: 4px; border-radius: 2px; background: #e5e7eb; }
.onboard-step.done { background: #6EE05A; }
.onboard-step.active { background: #1a2c27; }
.onboard-card { background: #fff; border: 1px solid #e5e7eb; border-radius: 16px; padding: 32px; }
.onboard-card h2 { font-size: 18px; font-weight: 700; color: #1a2c27; margin-bottom: 4px; }
.onboard-card .step-sub { color: #6b7280; font-size: 13px; margin-bottom: 24px; }
.onboard-nav { display: flex; justify-content: space-between; margin-top: 24px; }
.onboard-skip { color: #9ca3af; font-size: 13px; text-decoration: none; padding: 10px 0; }
.onboard-skip:hover { color: #6b7280; }
</style>

<div class="onboard-wrap">
  <div class="onboard-header">
    <h1>Welcome to 0nCore</h1>
    <p>Let's get your site connected in 5 minutes.</p>
    <?php if ($license['key']): ?>
    <div class="oncore-status oncore-status-success" style="margin-top:12px;display:inline-flex;">
      License: <?php echo esc_html(substr($license['key'], 0, 14)); ?>... (<?php echo esc_html($license['tier']); ?>)
    </div>
    <?php endif; ?>
  </div>

  <div class="onboard-steps">
    <div class="onboard-step <?php echo $step > 1 ? 'done' : ($step === 1 ? 'active' : ''); ?>"></div>
    <div class="onboard-step <?php echo $step > 2 ? 'done' : ($step === 2 ? 'active' : ''); ?>"></div>
    <div class="onboard-step <?php echo $step > 3 ? 'done' : ($step === 3 ? 'active' : ''); ?>"></div>
    <div class="onboard-step <?php echo $step > 4 ? 'done' : ($step === 4 ? 'active' : ''); ?>"></div>
    <div class="onboard-step <?php echo $step >= 5 ? 'active' : ''; ?>"></div>
  </div>

  <?php if ($step === 1): ?>
  <!-- STEP 1: Business Info -->
  <div class="onboard-card">
    <h2>Step 1: Your Business</h2>
    <p class="step-sub">This powers your schema.org SEO, contact info, and form defaults.</p>
    <div class="oncore-field"><label>Business Name</label><input type="text" id="ob-name" class="oncore-setting" value="<?php echo esc_attr(get_option('oncore_business_name','')); ?>" placeholder="The Spa In Ligonier"></div>
    <div class="oncore-grid-2">
      <div class="oncore-field"><label>Phone</label><input type="text" id="ob-phone" value="<?php echo esc_attr(get_option('oncore_business_phone','')); ?>" placeholder="+1-724-238-9800"></div>
      <div class="oncore-field"><label>Email</label><input type="email" id="ob-email" value="<?php echo esc_attr(get_option('oncore_business_email','')); ?>" placeholder="hello@business.com"></div>
    </div>
    <div class="oncore-field"><label>Address</label><input type="text" id="ob-address" value="<?php echo esc_attr(get_option('oncore_business_address','')); ?>" placeholder="201 S Fairfield St, Ligonier, PA 15658"></div>
    <div class="oncore-field">
      <label>Business Type</label>
      <select id="ob-schema">
        <?php foreach (['DaySpa','HealthAndBeautyBusiness','BeautySalon','HairSalon','LocalBusiness','MedicalBusiness','Restaurant','Store','ProfessionalService'] as $t): ?>
        <option value="<?php echo $t; ?>" <?php selected(get_option('oncore_schema_type','LocalBusiness'), $t); ?>><?php echo $t; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="onboard-nav">
      <span></span>
      <button class="oncore-btn oncore-btn-primary" onclick="obSave('business',{name:$('#ob-name').val(),phone:$('#ob-phone').val(),email:$('#ob-email').val(),address:$('#ob-address').val(),schema_type:$('#ob-schema').val()},2)">Next: Tracking →</button>
    </div>
  </div>

  <?php elseif ($step === 2): ?>
  <!-- STEP 2: Tracking -->
  <div class="onboard-card">
    <h2>Step 2: Tracking</h2>
    <p class="step-sub">Connect Meta Pixel and Google Analytics for conversion tracking.</p>
    <div class="oncore-field">
      <label>Meta Pixel ID</label>
      <input type="text" id="ob-pixel" value="<?php echo esc_attr(get_option('oncore_fb_pixel_id','')); ?>" placeholder="1234567890">
      <div class="help">Facebook Events Manager → Pixel → Settings → Pixel ID</div>
    </div>
    <div class="oncore-field">
      <label>GA4 Measurement ID</label>
      <input type="text" id="ob-ga4" value="<?php echo esc_attr(get_option('oncore_ga4_id','')); ?>" placeholder="G-XXXXXXXXXX">
      <div class="help">Google Analytics → Admin → Data Streams → Measurement ID</div>
    </div>
    <div class="onboard-nav">
      <a href="?page=oncore-onboarding&step=1" class="onboard-skip">← Back</a>
      <div style="display:flex;gap:8px;">
        <a href="?page=oncore-onboarding&step=3" class="onboard-skip">Skip</a>
        <button class="oncore-btn oncore-btn-primary" onclick="obSave('tracking',{pixel_id:$('#ob-pixel').val(),ga4_id:$('#ob-ga4').val()},3)">Next: CRM →</button>
      </div>
    </div>
  </div>

  <?php elseif ($step === 3): ?>
  <!-- STEP 3: CRM -->
  <div class="onboard-card">
    <h2>Step 3: CRM Integration</h2>
    <p class="step-sub">Connect your CRM so form submissions create contacts automatically.</p>
    <div class="oncore-field">
      <label>CRM Webhook URL (recommended)</label>
      <input type="text" id="ob-webhook" value="<?php echo esc_attr(get_option('oncore_crm_webhook','')); ?>" placeholder="https://services.leadconnectorhq.com/hooks/...">
      <div class="help">CRM → Automation → Workflows → New → Trigger: Inbound Webhook → Copy URL</div>
    </div>
    <div class="oncore-field">
      <label>CRM Location ID (optional — for direct API)</label>
      <input type="text" id="ob-loc" value="<?php echo esc_attr(get_option('oncore_crm_location_id','')); ?>" placeholder="F76MNK...">
    </div>
    <div class="oncore-field">
      <label>CRM PIT Token (optional)</label>
      <input type="password" id="ob-pit" value="<?php echo esc_attr(get_option('oncore_crm_pit','')); ?>" placeholder="pit-...">
    </div>
    <div class="onboard-nav">
      <a href="?page=oncore-onboarding&step=2" class="onboard-skip">← Back</a>
      <div style="display:flex;gap:8px;">
        <a href="?page=oncore-onboarding&step=4" class="onboard-skip">Skip</a>
        <button class="oncore-btn oncore-btn-primary" onclick="obSave('crm',{webhook:$('#ob-webhook').val(),location_id:$('#ob-loc').val(),pit:$('#ob-pit').val()},4)">Next: Booking →</button>
      </div>
    </div>
  </div>

  <?php elseif ($step === 4): ?>
  <!-- STEP 4: Booking -->
  <div class="onboard-card">
    <h2>Step 4: Online Booking</h2>
    <p class="step-sub">Connect MassageBook or your booking platform.</p>
    <div class="oncore-field">
      <label>MassageBook Business ID</label>
      <input type="text" id="ob-booking" value="<?php echo esc_attr(get_option('oncore_booking_business_id','1554118')); ?>" placeholder="1554118">
      <div class="help">From your MassageBook URL: massagebook.com/business/<strong>YOUR_ID</strong></div>
    </div>
    <div class="onboard-nav">
      <a href="?page=oncore-onboarding&step=3" class="onboard-skip">← Back</a>
      <div style="display:flex;gap:8px;">
        <a href="?page=oncore-onboarding&step=5" class="onboard-skip">Skip</a>
        <button class="oncore-btn oncore-btn-primary" onclick="obSave('booking',{business_id:$('#ob-booking').val()},5)">Next: Finish →</button>
      </div>
    </div>
  </div>

  <?php elseif ($step === 5): ?>
  <!-- STEP 5: Done! -->
  <div class="onboard-card" style="text-align:center;">
    <div style="font-size:48px;margin-bottom:16px;">🎉</div>
    <h2>You're All Set!</h2>
    <p class="step-sub">0nCore is configured and active on your site. Here's what's running:</p>
    <div style="text-align:left;background:#f9fafb;border-radius:8px;padding:16px;margin:20px 0;font-size:13px;line-height:2;">
      <?php if (get_option('oncore_fb_pixel_id')): ?>✅ Meta Pixel tracking (sitewide)<br><?php else: ?>⬜ Meta Pixel (not configured)<br><?php endif; ?>
      <?php if (get_option('oncore_ga4_id')): ?>✅ GA4 analytics (sitewide)<br><?php else: ?>⬜ GA4 (not configured)<br><?php endif; ?>
      <?php if (get_option('oncore_crm_webhook') || get_option('oncore_crm_pit')): ?>✅ CRM integration<br><?php else: ?>⬜ CRM (not configured)<br><?php endif; ?>
      <?php if (get_option('oncore_booking_business_id')): ?>✅ MassageBook booking<br><?php else: ?>⬜ Booking (not configured)<br><?php endif; ?>
      ✅ Schema.org SEO (<?php echo esc_html(get_option('oncore_schema_type','LocalBusiness')); ?>)<br>
      ✅ UTM tracking + cookie capture<br>
      ✅ Auto-update from GitHub<br>
    </div>
    <p style="font-size:13px;color:#6b7280;margin-bottom:20px;">Now add shortcodes to your pages to start capturing leads:</p>
    <div style="text-align:left;background:#1a2c27;color:#6EE05A;border-radius:8px;padding:14px;font-family:monospace;font-size:12px;line-height:2;margin-bottom:20px;">
      [oncore_form title="Contact Us" fields="name,email,phone,message"]<br>
      [oncore_booking_list category="facials"]<br>
      [oncore_cta title="Book Now" service_id="219925"]
    </div>
    <div style="display:flex;gap:10px;justify-content:center;">
      <button class="oncore-btn oncore-btn-primary" onclick="obSave('complete',{},0)">Go to Dashboard</button>
      <a href="<?php echo admin_url('admin.php?page=oncore-ai'); ?>" class="oncore-btn oncore-btn-secondary">Try AI Generator</a>
    </div>
  </div>
  <?php endif; ?>
</div>
</div>

<script>
function obSave(step, data, nextStep) {
  // Save settings directly via AJAX
  var settings = {};
  if (step === 'business') {
    settings['oncore_business_name'] = data.name || '';
    settings['oncore_business_phone'] = data.phone || '';
    settings['oncore_business_email'] = data.email || '';
    settings['oncore_business_address'] = data.address || '';
    if (data.schema_type) settings['oncore_schema_type'] = data.schema_type;
    if (data.lat) settings['oncore_business_lat'] = data.lat;
    if (data.lng) settings['oncore_business_lng'] = data.lng;
  } else if (step === 'tracking') {
    if (data.pixel_id) settings['oncore_fb_pixel_id'] = data.pixel_id;
    if (data.ga4_id) settings['oncore_ga4_id'] = data.ga4_id;
  } else if (step === 'crm') {
    if (data.webhook) settings['oncore_crm_webhook'] = data.webhook;
    if (data.pit) settings['oncore_crm_pit'] = data.pit;
    if (data.location_id) settings['oncore_crm_location_id'] = data.location_id;
  } else if (step === 'booking') {
    if (data.business_id) settings['oncore_booking_business_id'] = data.business_id;
  }

  jQuery.post(ajaxurl, {
    action: 'oncore_save_settings',
    nonce: '<?php echo wp_create_nonce('oncore_nonce'); ?>',
    settings: settings
  }, function() {
    if (step === 'complete') {
      jQuery.post(ajaxurl, {
        action: 'oncore_complete_onboarding',
        nonce: '<?php echo wp_create_nonce('oncore_nonce'); ?>',
        step: 'complete',
        data: {}
      }, function() {
        window.location = '<?php echo admin_url('admin.php?page=oncore'); ?>';
      });
    } else if (nextStep === 0) {
      window.location = '<?php echo admin_url('admin.php?page=oncore'); ?>';
    } else {
      window.location = '<?php echo admin_url('admin.php?page=oncore-onboarding&step='); ?>' + nextStep;
    }
  });
}
</script>
