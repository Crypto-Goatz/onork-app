<?php if (!defined('ABSPATH')) exit;
$license = OnCore_License::get_license();
$sxo_health = [];
try {
  $scored = get_posts(['post_type'=>['post','page'],'post_status'=>'publish','posts_per_page'=>-1,'meta_key'=>'_oncore_sxo_score','fields'=>'ids']);
  $scores = array_map(fn($id)=>intval(get_post_meta($id,'_oncore_sxo_score',true)), $scored);
  $sxo_health = ['scored'=>count($scored),'avg'=>count($scores)>0?round(array_sum($scores)/count($scores)):0];
} catch (\Exception $e) { $sxo_health = ['scored'=>0,'avg'=>0]; }
$pixel = get_option('oncore_fb_pixel_id','');
$ga4 = get_option('oncore_ga4_id','');
$crm = get_option('oncore_crm_webhook','') || get_option('oncore_crm_pit','');
?>
<div class="wrap oncore-admin">

  <!-- Header Banner -->
  <div class="oc-header">
    <div class="oc-header-left">
      <h1>0nCore <span class="oc-version">v<?php echo ONCORE_VERSION; ?></span></h1>
      <p class="subtitle">Your WordPress site connected to the 0n ecosystem.</p>
    </div>
    <div class="oc-header-right">
      <a href="<?php echo admin_url('admin.php?page=oncore-onboarding'); ?>" class="oncore-btn oncore-btn-secondary">Setup Wizard</a>
      <a href="<?php echo admin_url('admin.php?page=oncore-ai'); ?>" class="oncore-btn oncore-btn-primary">AI Generator</a>
    </div>
  </div>

  <!-- Stats -->
  <div class="oc-stats">
    <div class="oc-stat oc-stat-green">
      <div class="oc-stat-value"><?php echo $sxo_health['avg'] ?? 0; ?></div>
      <div class="oc-stat-label">Avg SXO Score</div>
    </div>
    <div class="oc-stat oc-stat-blue">
      <div class="oc-stat-value"><?php echo $sxo_health['scored'] ?? 0; ?></div>
      <div class="oc-stat-label">Pages Scored</div>
    </div>
    <div class="oc-stat oc-stat-purple">
      <div class="oc-stat-value"><?php echo $pixel ? '&#10003;' : '&#10005;'; ?></div>
      <div class="oc-stat-label">Meta Pixel</div>
    </div>
    <div class="oc-stat oc-stat-orange">
      <div class="oc-stat-value"><?php echo $ga4 ? '&#10003;' : '&#10005;'; ?></div>
      <div class="oc-stat-label">GA4 Tracking</div>
    </div>
  </div>

  <!-- License -->
  <?php if ($license['status'] === 'active'): ?>
  <div class="oncore-card">
    <h2><span class="dot"></span> License Active</h2>
    <div class="oncore-status oncore-status-success">
      <strong><?php echo esc_html($license['key']); ?></strong> — <?php echo esc_html($license['tier']); ?> tier
    </div>
    <div style="margin-top:12px;display:flex;gap:8px;">
      <a href="<?php echo admin_url('admin.php?page=oncore-onboarding'); ?>" class="oncore-btn oncore-btn-secondary">Re-run Setup</a>
      <button class="oncore-btn oncore-btn-danger" onclick="if(confirm('Deactivate?')){jQuery.post(oncore.ajax_url,{action:'oncore_deactivate_license',nonce:oncore.nonce},function(){location.reload();})}">Deactivate</button>
    </div>
  </div>
  <?php else: ?>
  <div class="oncore-card" style="border-color:rgba(110,224,90,0.3);">
    <h2><span class="dot" style="background:#f97316;box-shadow:0 0 8px rgba(249,115,22,0.3)"></span> Activate License</h2>
    <div class="oncore-field">
      <label>License Key</label>
      <div style="display:flex;gap:8px;max-width:420px;">
        <input type="text" id="license-key-input" placeholder="0NCORE-XXXX-XXXX-XXXX-XXXX" style="max-width:320px;font-family:'JetBrains Mono',monospace;text-transform:uppercase;letter-spacing:0.05em;">
        <button class="oncore-btn oncore-btn-primary" id="activate-btn" onclick="oncoreActivate()">Activate</button>
      </div>
      <div class="help">Get your key at <a href="https://0ncore.com" target="_blank" style="color:#6EE05A;">0ncore.com</a></div>
    </div>
    <div id="license-status"></div>
  </div>
  <script>
  function oncoreActivate(){var k=document.getElementById('license-key-input').value.trim();if(!k){alert('Enter a license key');return;}var b=document.getElementById('activate-btn');b.disabled=true;b.textContent='Activating...';jQuery.post(oncore.ajax_url,{action:'oncore_activate_license',nonce:oncore.nonce,license_key:k},function(r){if(r.success)window.location='<?php echo admin_url('admin.php?page=oncore-onboarding&step=1'); ?>';else{b.disabled=false;b.textContent='Activate';document.getElementById('license-status').innerHTML='<div class="oncore-status oncore-status-error">'+(r.data||'Failed')+'</div>';}});}
  </script>
  <?php endif; ?>

  <!-- Quick Features -->
  <div class="oncore-card">
    <h2><span class="dot dot-blue"></span> What's Powered On</h2>
    <div class="oc-features">
      <div class="oc-feature">
        <div class="oc-feature-icon" style="background:rgba(110,224,90,0.1);color:#22c55e;">&#9733;</div>
        <h3>SXO Scoring</h3>
        <p>Every post and page gets a real-time SXO score across 8 dimensions. Check the sidebar when editing.</p>
      </div>
      <div class="oc-feature">
        <div class="oc-feature-icon" style="background:rgba(59,130,246,0.1);color:#3b82f6;">&#9783;</div>
        <h3>Tracking Stack</h3>
        <p>Meta Pixel + GA4 + UTM capture injected sitewide. Every visitor tracked, every conversion attributed.</p>
      </div>
      <div class="oc-feature">
        <div class="oc-feature-icon" style="background:rgba(168,85,247,0.1);color:#a855f7;">&#9881;</div>
        <h3>CRM Integration</h3>
        <p>Forms auto-submit to your CRM with tags, UTM data, and custom fields. Webhook or direct API.</p>
      </div>
      <div class="oc-feature">
        <div class="oc-feature-icon" style="background:rgba(249,115,22,0.1);color:#f97316;">&#9889;</div>
        <h3>API Bridge</h3>
        <p>Full REST API for remote site management. Claude Code can build pages, upload media, manage menus.</p>
      </div>
      <div class="oc-feature">
        <div class="oc-feature-icon" style="background:rgba(234,179,8,0.1);color:#eab308;">&#9635;</div>
        <h3>Canvas Template</h3>
        <p>Check a box on any page to bypass your theme completely. Clean SXO canvas with tracking auto-injected.</p>
      </div>
      <div class="oc-feature">
        <div class="oc-feature-icon" style="background:rgba(236,72,153,0.1);color:#ec4899;">&#10024;</div>
        <h3>Schema.org</h3>
        <p>Auto-injects LocalBusiness, DaySpa, Article, or any schema type based on your settings.</p>
      </div>
    </div>
  </div>

  <!-- Business Info -->
  <div class="oncore-card">
    <h2><span class="dot dot-purple"></span> Business Information</h2>
    <div class="oncore-grid-2">
      <div class="oncore-field"><label>Business Name</label><input type="text" name="oncore_business_name" class="oncore-setting" value="<?php echo esc_attr(get_option('oncore_business_name','')); ?>" placeholder="Your Business Name"></div>
      <div class="oncore-field"><label>Phone</label><input type="text" name="oncore_business_phone" class="oncore-setting" value="<?php echo esc_attr(get_option('oncore_business_phone','')); ?>" placeholder="+1-555-123-4567"></div>
    </div>
    <div class="oncore-grid-2">
      <div class="oncore-field"><label>Email</label><input type="email" name="oncore_business_email" class="oncore-setting" value="<?php echo esc_attr(get_option('oncore_business_email','')); ?>" placeholder="hello@business.com"></div>
      <div class="oncore-field"><label>Schema Type</label>
        <select name="oncore_schema_type" class="oncore-setting">
          <?php foreach(['DaySpa','HealthAndBeautyBusiness','BeautySalon','LocalBusiness','MedicalBusiness','Restaurant','Store','ProfessionalService'] as $t): ?>
          <option value="<?php echo $t; ?>" <?php selected(get_option('oncore_schema_type','LocalBusiness'),$t); ?>><?php echo $t; ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div class="oncore-field"><label>Address</label><input type="text" name="oncore_business_address" class="oncore-setting" value="<?php echo esc_attr(get_option('oncore_business_address','')); ?>" placeholder="201 S Fairfield St, Ligonier, PA 15658"><div class="help">Format: Street, City, State Zip</div></div>
  </div>

  <!-- Tracking -->
  <div class="oncore-card">
    <h2><span class="dot dot-orange"></span> Tracking</h2>
    <div class="oncore-grid-2">
      <div class="oncore-field"><label>Meta Pixel ID</label><input type="text" name="oncore_fb_pixel_id" class="oncore-setting" value="<?php echo esc_attr($pixel); ?>" placeholder="1234567890"><div class="help">Facebook Events Manager → Pixel</div></div>
      <div class="oncore-field"><label>GA4 Measurement ID</label><input type="text" name="oncore_ga4_id" class="oncore-setting" value="<?php echo esc_attr($ga4); ?>" placeholder="G-XXXXXXXXXX"><div class="help">Google Analytics → Admin → Data Streams</div></div>
    </div>
  </div>

  <!-- CRM -->
  <div class="oncore-card">
    <h2><span class="dot dot-gold"></span> CRM Integration</h2>
    <div class="oncore-field"><label>CRM Webhook URL</label><input type="text" name="oncore_crm_webhook" class="oncore-setting" value="<?php echo esc_attr(get_option('oncore_crm_webhook','')); ?>" placeholder="https://services.leadconnectorhq.com/hooks/..."><div class="help">Automation → Workflows → Inbound Webhook → Copy URL</div></div>
    <div class="oncore-grid-2">
      <div class="oncore-field"><label>CRM Location ID</label><input type="text" name="oncore_crm_location_id" class="oncore-setting" value="<?php echo esc_attr(get_option('oncore_crm_location_id','')); ?>" placeholder="F76MNK..."></div>
      <div class="oncore-field"><label>Booking Business ID</label><input type="text" name="oncore_booking_business_id" class="oncore-setting" value="<?php echo esc_attr(get_option('oncore_booking_business_id','1554118')); ?>" placeholder="1554118"><div class="help">MassageBook Business ID</div></div>
    </div>
  </div>

  <!-- Save -->
  <div style="display:flex;gap:8px;margin-bottom:24px;">
    <button class="oncore-btn oncore-btn-primary" id="oncore-save-settings" style="padding:12px 28px;font-size:14px;">Save All Settings</button>
    <button class="oncore-btn oncore-btn-secondary" id="oncore-test-crm">Test CRM Connection</button>
  </div>
  <div id="oncore-status"></div>
  <div id="crm-status"></div>

  <!-- Shortcodes -->
  <div class="oncore-card">
    <h2><span class="dot"></span> Shortcodes</h2>
    <div class="oncore-shortcode-ref">
      <code>[oncore_form title="Contact Us" fields="name,email,phone,message"]</code>
      <div class="desc">Lead form → auto-submits to CRM with UTM tracking</div>
      <code>[oncore_booking service_id="219925" label="Book Now"]</code>
      <div class="desc">Booking button linked to MassageBook</div>
      <code>[oncore_booking_list category="facials"]</code>
      <div class="desc">Full service menu with prices + Book buttons</div>
      <code>[oncore_phone label="Call Us"]</code>
      <div class="desc">Click-to-call with conversion tracking</div>
      <code>[oncore_cta title="Ready?" button="Book Now" style="dark"]CTA text[/oncore_cta]</code>
      <div class="desc">Call-to-action block</div>
      <code>[oncore_map]</code>
      <div class="desc">Google Maps embed</div>
    </div>
  </div>

</div>
