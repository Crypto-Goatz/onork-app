<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap oncore-admin">
  <h1>0nCore AI Generator <span class="badge">AI</span></h1>
  <p class="subtitle">Generate SXO-optimized pages and posts instantly. Describe what you want — AI builds the page.</p>

  <div class="oncore-card">
    <h2><span class="dot"></span> AI Configuration</h2>
    <div class="oncore-field">
      <label>Anthropic API Key</label>
      <input type="password" name="oncore_ai_api_key" class="oncore-setting" value="<?php echo esc_attr(get_option('oncore_ai_api_key', '')); ?>" placeholder="sk-ant-...">
      <div class="help">Get your key at <a href="https://console.anthropic.com" target="_blank">console.anthropic.com</a>. Used for AI page generation.</div>
    </div>
    <button class="oncore-btn oncore-btn-primary" id="oncore-save-settings">Save Key</button>
    <div id="oncore-status"></div>
  </div>

  <div class="oncore-card">
    <h2><span class="dot" style="background:#6c63ff"></span> Generate a Page</h2>
    <div class="oncore-field">
      <label>What do you want to create?</label>
      <input type="text" id="ai-topic" placeholder="e.g. Professional facials landing page for a day spa in Ligonier PA" style="max-width:100%;font-size:15px;padding:14px;">
    </div>
    <div class="oncore-grid-2">
      <div class="oncore-field">
        <label>Page Type</label>
        <select id="ai-page-type">
          <option value="landing">Landing Page</option>
          <option value="service">Service Page</option>
          <option value="about">About Page</option>
          <option value="contact">Contact Page</option>
        </select>
      </div>
      <div class="oncore-field">
        <label>Style</label>
        <select id="ai-style">
          <option value="professional">Professional</option>
          <option value="luxury">Luxury / Spa</option>
          <option value="modern">Modern / Tech</option>
          <option value="warm">Warm / Friendly</option>
          <option value="bold">Bold / Aggressive</option>
        </select>
      </div>
    </div>
    <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:8px;">
      <label style="font-size:13px;display:flex;align-items:center;gap:6px;">
        <input type="checkbox" id="ai-form" checked> Lead Form
      </label>
      <label style="font-size:13px;display:flex;align-items:center;gap:6px;">
        <input type="checkbox" id="ai-booking" checked> Booking Buttons
      </label>
      <label style="font-size:13px;display:flex;align-items:center;gap:6px;">
        <input type="checkbox" id="ai-faq" checked> FAQ Section
      </label>
      <label style="font-size:13px;display:flex;align-items:center;gap:6px;">
        <input type="checkbox" id="ai-reviews" checked> Reviews
      </label>
    </div>
    <div style="margin-top:16px;display:flex;gap:10px;">
      <button class="oncore-btn oncore-btn-primary" id="ai-generate-btn" onclick="oncoreGenerate(false)">Generate as Draft</button>
      <button class="oncore-btn oncore-btn-secondary" id="ai-publish-btn" onclick="oncoreGenerate(true)">Generate & Publish</button>
    </div>
    <div id="ai-status" style="margin-top:12px;"></div>
    <div id="ai-result" style="display:none;margin-top:16px;background:#f0fdf4;border:1px solid #86efac;border-radius:8px;padding:16px;">
      <h3 style="color:#065f46;font-size:14px;margin-bottom:8px;">Page Created!</h3>
      <p id="ai-result-title" style="font-size:13px;color:#374151;"></p>
      <div style="display:flex;gap:8px;margin-top:10px;">
        <a id="ai-result-view" href="#" target="_blank" class="oncore-btn oncore-btn-primary" style="font-size:12px;padding:8px 14px;">View Page</a>
        <a id="ai-result-edit" href="#" target="_blank" class="oncore-btn oncore-btn-secondary" style="font-size:12px;padding:8px 14px;">Edit in WordPress</a>
      </div>
    </div>
  </div>
</div>

<script>
function oncoreGenerate(publish) {
  var topic = document.getElementById('ai-topic').value.trim();
  if (!topic) { alert('Enter a topic'); return; }
  var btn = publish ? document.getElementById('ai-publish-btn') : document.getElementById('ai-generate-btn');
  btn.disabled = true; btn.textContent = 'Generating...';
  document.getElementById('ai-status').innerHTML = '<div class="oncore-status oncore-status-info">AI is generating your page — this takes 15-30 seconds...</div>';
  document.getElementById('ai-result').style.display = 'none';

  jQuery.post(oncore.ajax_url, {
    action: 'oncore_ai_generate',
    nonce: oncore.nonce,
    topic: topic,
    page_type: document.getElementById('ai-page-type').value,
    style: document.getElementById('ai-style').value,
    publish: publish ? '1' : ''
  }, function(res) {
    btn.disabled = false;
    btn.textContent = publish ? 'Generate & Publish' : 'Generate as Draft';
    if (res.success) {
      document.getElementById('ai-status').innerHTML = '<div class="oncore-status oncore-status-success">Page generated successfully!</div>';
      document.getElementById('ai-result').style.display = 'block';
      document.getElementById('ai-result-title').textContent = res.data.title;
      document.getElementById('ai-result-view').href = res.data.url;
      document.getElementById('ai-result-edit').href = res.data.edit_url;
    } else {
      document.getElementById('ai-status').innerHTML = '<div class="oncore-status oncore-status-error">' + (res.data || 'Generation failed') + '</div>';
    }
  });
}
</script>
