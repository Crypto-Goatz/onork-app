<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap oncore-admin">
  <h1>0nCore Tracking</h1>
  <p class="subtitle">Meta Pixel and GA4 are injected sitewide automatically. UTM parameters are captured into cookies for CRM attribution.</p>

  <div class="oncore-card">
    <h2><span class="dot"></span> Active Tracking</h2>
    <?php $pixel = get_option('oncore_fb_pixel_id',''); $ga4 = get_option('oncore_ga4_id',''); ?>
    <div class="oncore-status <?php echo $pixel ? 'oncore-status-success' : 'oncore-status-error'; ?>">
      Meta Pixel: <?php echo $pixel ? 'Active (ID: '.esc_html($pixel).')' : 'Not configured'; ?>
    </div>
    <br>
    <div class="oncore-status <?php echo $ga4 ? 'oncore-status-success' : 'oncore-status-error'; ?>">
      GA4: <?php echo $ga4 ? 'Active ('.esc_html($ga4).')' : 'Not configured'; ?>
    </div>
    <br>
    <div class="oncore-status oncore-status-success">
      UTM Capture: <?php echo get_option('oncore_utm_tracking','1')==='1' ? 'Active' : 'Disabled'; ?>
    </div>
  </div>

  <div class="oncore-card">
    <h2><span class="dot"></span> Events Fired Automatically</h2>
    <table style="width:100%;font-size:13px;border-collapse:collapse;">
      <tr style="border-bottom:1px solid #e5e7eb;background:#f9fafb;"><td style="padding:8px;font-weight:700;">Event</td><td style="padding:8px;font-weight:700;">Platform</td><td style="padding:8px;font-weight:700;">When</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;">PageView</td><td style="padding:8px;">Meta Pixel</td><td style="padding:8px;">Every page load</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;">page_view</td><td style="padding:8px;">GA4</td><td style="padding:8px;">Every page load</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;">ViewContent</td><td style="padding:8px;">Meta Pixel</td><td style="padding:8px;">Ad visitor lands (fbclid/gclid detected)</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;">Lead</td><td style="padding:8px;">Meta Pixel + GA4</td><td style="padding:8px;">Form submit or booking click</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;">BookingClick</td><td style="padding:8px;">Meta Pixel (custom)</td><td style="padding:8px;">Any [oncore_booking] button clicked</td></tr>
      <tr><td style="padding:8px;">Contact</td><td style="padding:8px;">Meta Pixel</td><td style="padding:8px;">Click-to-call via [oncore_phone]</td></tr>
    </table>
  </div>

  <div class="oncore-card">
    <h2><span class="dot"></span> Facebook Ads Setup</h2>
    <ol style="font-size:13px;line-height:2;color:#374151;padding-left:20px;">
      <li>Create a campaign in Facebook Ads Manager</li>
      <li>Set destination URL: <code>https://facialhealthspa.com/?utm_source=facebook&utm_medium=cpc&utm_campaign=YOUR_CAMPAIGN</code></li>
      <li>The Meta Pixel will auto-fire PageView + ViewContent</li>
      <li>Optimize for "Lead" event — fires on form submit + booking click</li>
      <li>All leads auto-tagged <code>facebook-ad</code> in your CRM</li>
    </ol>
  </div>

  <div class="oncore-card">
    <h2><span class="dot"></span> Google PMax Remarketing</h2>
    <ol style="font-size:13px;line-height:2;color:#374151;padding-left:20px;">
      <li>GA4 fires <code>view_item</code> for all ad visitors automatically</li>
      <li>In Google Ads → Audience Manager → Create from GA4 events</li>
      <li>Create audience: "Users who triggered view_item in last 30 days"</li>
      <li>Use this audience in a PMax campaign</li>
      <li>All Google Ad leads auto-tagged <code>google-ad</code> + <code>pmax-remarketing</code> in CRM</li>
    </ol>
  </div>
</div>
