<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap oncore-admin">
  <h1>0nCore Forms</h1>
  <p class="subtitle">Drop these shortcodes on any page. Forms auto-submit to your CRM with full UTM tracking.</p>

  <div class="oncore-card">
    <h2><span class="dot"></span> Quick Copy Shortcodes</h2>

    <div class="oncore-shortcode-ref">
      <h3>General Contact Form</h3>
      <code>[oncore_form title="Contact Us" subtitle="We'll respond within 24 hours" fields="name,email,phone,message" button="Send Message"]</code>

      <h3>Facial Consultation Form</h3>
      <code>[oncore_form title="Free Skin Consultation" subtitle="Not sure which facial? We'll help." fields="name,email,phone,skin" tags="facial-interest,website-lead" service="Facials" button="Get My Free Consultation"]</code>

      <h3>Booking Interest (No Message)</h3>
      <code>[oncore_form title="Request Appointment" fields="name,email,phone,service" tags="appointment-request" button="Request Appointment"]</code>

      <h3>Newsletter Signup (Minimal)</h3>
      <code>[oncore_form title="Stay Updated" subtitle="Monthly tips and exclusive offers." fields="name,email" tags="newsletter-signup" button="Subscribe"]</code>
    </div>
  </div>

  <div class="oncore-card">
    <h2><span class="dot"></span> Form Field Options</h2>
    <table style="width:100%;font-size:13px;border-collapse:collapse;">
      <tr style="border-bottom:1px solid #e5e7eb;background:#f9fafb;"><td style="padding:8px;font-weight:700;">Field Key</td><td style="padding:8px;font-weight:700;">What It Shows</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;"><code>name</code></td><td style="padding:8px;">First + Last name (side by side)</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;"><code>email</code></td><td style="padding:8px;">Email address</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;"><code>phone</code></td><td style="padding:8px;">Phone number</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;"><code>service</code></td><td style="padding:8px;">Service interest text field</td></tr>
      <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;"><code>skin</code></td><td style="padding:8px;">Skin concern dropdown (7 options)</td></tr>
      <tr><td style="padding:8px;"><code>message</code></td><td style="padding:8px;">Free-text message area</td></tr>
    </table>
  </div>
</div>
