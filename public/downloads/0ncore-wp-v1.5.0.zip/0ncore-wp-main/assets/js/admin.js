/**
 * 0nCore Admin JS
 */
jQuery(function($){
  // Save settings via AJAX
  $('#oncore-save-settings').on('click', function(e){
    e.preventDefault();
    var btn = $(this);
    btn.prop('disabled', true).text('Saving...');
    var settings = {};
    $('.oncore-setting').each(function(){ settings[$(this).attr('name')] = $(this).val(); });

    $.post(oncore.ajax_url, {
      action: 'oncore_save_settings',
      nonce: oncore.nonce,
      settings: settings
    }, function(res){
      btn.prop('disabled', false).text('Save Settings');
      if (res.success) {
        $('#oncore-status').html('<div class="oncore-status oncore-status-success">Settings saved successfully</div>');
      } else {
        $('#oncore-status').html('<div class="oncore-status oncore-status-error">'+(res.data||'Error')+'</div>');
      }
      setTimeout(function(){ $('#oncore-status').html(''); }, 3000);
    });
  });

  // Test CRM connection
  $('#oncore-test-crm').on('click', function(e){
    e.preventDefault();
    var btn = $(this);
    btn.prop('disabled', true).text('Testing...');

    $.post(oncore.ajax_url, {
      action: 'oncore_test_crm',
      nonce: oncore.nonce
    }, function(res){
      btn.prop('disabled', false).text('Test Connection');
      if (res.success) {
        $('#crm-status').html('<div class="oncore-status oncore-status-success">Connected: ' + res.data.name + ' (' + (res.data.email||'') + ')</div>');
      } else {
        $('#crm-status').html('<div class="oncore-status oncore-status-error">'+(res.data||'Connection failed')+'</div>');
      }
    });
  });
});
