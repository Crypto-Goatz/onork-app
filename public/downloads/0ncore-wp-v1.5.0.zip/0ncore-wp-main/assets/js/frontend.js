/**
 * 0nCore v1.0.0 — Frontend JavaScript
 * Form submission, tracking events, booking clicks
 */

(function(){
  'use strict';

  // ── Form Handling ──
  document.addEventListener('DOMContentLoaded', function(){
    document.querySelectorAll('.oncore-form').forEach(function(form){
      form.addEventListener('submit', function(e){
        e.preventDefault();
        var btn = form.querySelector('.oncore-submit');
        if (btn.disabled) return;
        btn.disabled = true;
        btn.textContent = 'Sending...';

        var data = new FormData(form);
        data.append('action', 'oncore_form_submit');
        data.append('nonce', oncore_config.nonce);
        data.append('tags', form.dataset.tags || 'website-lead,0ncore');
        data.append('service', form.dataset.service || '');
        data.append('source', 'website');

        fetch(oncore_config.ajax_url, { method: 'POST', body: data })
          .then(function(r){ return r.json(); })
          .then(function(res){
            if (res.success) {
              // Track conversion
              oncore_track_lead('form_submit');
              // Show success
              var wrap = form.closest('.oncore-form-wrap');
              if (wrap) {
                form.style.display = 'none';
                var success = wrap.querySelector('.oncore-form-success');
                if (success) success.style.display = 'block';
              }
            } else {
              btn.disabled = false;
              btn.textContent = 'Try Again';
              alert(res.data || 'Something went wrong. Please try again.');
            }
          })
          .catch(function(){
            btn.disabled = false;
            btn.textContent = 'Try Again';
          });
      });
    });
  });

  // ── Tracking Functions (global) ──
  window.oncore_track_booking = function(serviceId) {
    // Meta Pixel
    if (window.fbq) {
      fbq('track', 'Lead', { content_name: 'Booking Click', content_category: 'booking', value: 85, currency: 'USD' });
      fbq('trackCustom', 'BookingClick', { service_id: serviceId });
    }
    // GA4
    if (window.gtag) {
      gtag('event', 'generate_lead', { event_category: 'booking', event_label: serviceId, value: 85 });
    }
  };

  window.oncore_track_lead = function(label) {
    if (window.fbq) {
      fbq('track', 'Lead', { content_name: 'Form Submit', content_category: 'lead' });
    }
    if (window.gtag) {
      gtag('event', 'generate_lead', { event_category: 'form', event_label: label || 'contact' });
    }
  };

  window.oncore_track_call = function() {
    if (window.fbq) {
      fbq('track', 'Contact', { content_name: 'Phone Call' });
    }
    if (window.gtag) {
      gtag('event', 'contact', { event_category: 'phone', event_label: 'click_to_call' });
    }
  };

  // ── Auto ViewContent for ad visitors ──
  (function(){
    var p = new URLSearchParams(location.search);
    if (p.get('fbclid') || p.get('gclid') || p.get('utm_source')) {
      if (window.fbq) fbq('track', 'ViewContent', { content_name: document.title, content_type: 'page' });
      if (window.gtag) gtag('event', 'view_item', { items: [{ item_name: document.title }] });
    }
  })();

})();
