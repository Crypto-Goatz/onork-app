<?php
/**
 * Plugin Name: 0nCore
 * Plugin URI: https://0ncore.com
 * Description: Connect your WordPress site to the 0nCore ecosystem — CRM integration, AI-powered forms, tracking (Meta Pixel + GA4), booking embeds, SXO landing pages, and schema.org SEO. The VIP WordPress plugin from RocketOpp.
 * Version: 1.0.0
 * Author: RocketOpp LLC
 * Author URI: https://rocketopp.com
 * License: GPL v2 or later
 * Text Domain: 0ncore
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) exit;

define('ONCORE_VERSION', '1.5.0');
define('ONCORE_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ONCORE_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ONCORE_PLUGIN_FILE', __FILE__);

// ── Autoload Includes ──
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-settings.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-tracking.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-crm.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-forms.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-schema.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-shortcodes.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-booking.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-updater.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-ai-generator.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-license.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-api-bridge.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-template.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-jwt-setup.php';
require_once ONCORE_PLUGIN_DIR . 'includes/class-oncore-sxo-scorer.php';

/**
 * Main 0nCore Plugin Class
 */
final class OnCore {

    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('init', [$this, 'init']);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
        add_action('wp_enqueue_scripts', [$this, 'frontend_assets']);
        register_activation_hook(ONCORE_PLUGIN_FILE, [$this, 'activate']);
    }

    public function init() {
        OnCore_Settings::instance();
        OnCore_Tracking::instance();
        OnCore_CRM::instance();
        OnCore_Forms::instance();
        OnCore_Schema::instance();
        OnCore_Shortcodes::instance();
        OnCore_Booking::instance();
        OnCore_Updater::instance();
        OnCore_AI_Generator::instance();
        OnCore_License::instance();
        OnCore_API_Bridge::instance();
        OnCore_Template::instance();
        OnCore_JWT_Setup::instance();
        OnCore_SXO_Scorer::instance();
    }

    public function admin_menu() {
        add_menu_page(
            '0nCore',
            '0nCore',
            'manage_options',
            'oncore',
            [$this, 'render_admin'],
            'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><circle cx="10" cy="10" r="8" fill="#6EE05A"/><text x="10" y="14" text-anchor="middle" font-size="10" font-weight="900" fill="#0B0F19">0n</text></svg>'),
            3
        );

        add_submenu_page('oncore', 'Settings', 'Settings', 'manage_options', 'oncore', [$this, 'render_admin']);
        add_submenu_page('oncore', 'CRM', 'CRM', 'manage_options', 'oncore-crm', [$this, 'render_crm']);
        add_submenu_page('oncore', 'Tracking', 'Tracking', 'manage_options', 'oncore-tracking', [$this, 'render_tracking']);
        add_submenu_page('oncore', 'Forms', 'Forms', 'manage_options', 'oncore-forms', [$this, 'render_forms']);
        add_submenu_page('oncore', 'Booking', 'Booking', 'manage_options', 'oncore-booking', [$this, 'render_booking']);
        add_submenu_page('oncore', 'AI Generator', 'AI Generator', 'manage_options', 'oncore-ai', [$this, 'render_ai']);
        add_submenu_page('oncore', 'Setup Wizard', 'Setup Wizard', 'manage_options', 'oncore-onboarding', [$this, 'render_onboarding']);
    }

    public function admin_assets($hook) {
        if (strpos($hook, 'oncore') === false) return;
        wp_enqueue_style('oncore-admin', ONCORE_PLUGIN_URL . 'assets/css/admin.css', [], ONCORE_VERSION);
        wp_enqueue_script('oncore-admin', ONCORE_PLUGIN_URL . 'assets/js/admin.js', ['jquery'], ONCORE_VERSION, true);
        wp_localize_script('oncore-admin', 'oncore', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('oncore_nonce'),
        ]);
    }

    public function frontend_assets() {
        wp_enqueue_style('oncore-front', ONCORE_PLUGIN_URL . 'assets/css/frontend.css', [], ONCORE_VERSION);
        wp_enqueue_script('oncore-front', ONCORE_PLUGIN_URL . 'assets/js/frontend.js', [], ONCORE_VERSION, true);
        wp_localize_script('oncore-front', 'oncore_config', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('oncore_public_nonce'),
            'pixel_id' => get_option('oncore_fb_pixel_id', ''),
            'ga4_id' => get_option('oncore_ga4_id', ''),
            'crm_webhook' => get_option('oncore_crm_webhook', ''),
            'booking_business_id' => get_option('oncore_booking_business_id', '1554118'),
        ]);
    }

    public function render_admin() { include ONCORE_PLUGIN_DIR . 'templates/admin-settings.php'; }
    public function render_crm() { include ONCORE_PLUGIN_DIR . 'templates/admin-crm.php'; }
    public function render_tracking() { include ONCORE_PLUGIN_DIR . 'templates/admin-tracking.php'; }
    public function render_forms() { include ONCORE_PLUGIN_DIR . 'templates/admin-forms.php'; }
    public function render_booking() { include ONCORE_PLUGIN_DIR . 'templates/admin-booking.php'; }
    public function render_ai() { include ONCORE_PLUGIN_DIR . 'templates/admin-ai-generator.php'; }
    public function render_onboarding() { include ONCORE_PLUGIN_DIR . 'templates/admin-onboarding.php'; }

    public function activate() {
        // Set defaults
        add_option('oncore_fb_pixel_id', '');
        add_option('oncore_ga4_id', '');
        add_option('oncore_crm_webhook', '');
        add_option('oncore_crm_pit', '');
        add_option('oncore_crm_location_id', '');
        add_option('oncore_booking_business_id', '1554118');
        add_option('oncore_business_name', '');
        add_option('oncore_business_phone', '');
        add_option('oncore_business_email', '');
        add_option('oncore_business_address', '');
        add_option('oncore_business_lat', '');
        add_option('oncore_business_lng', '');
        add_option('oncore_schema_type', 'LocalBusiness');
        add_option('oncore_utm_tracking', '1');
        add_option('oncore_auto_crm_capture', '1');
        add_option('oncore_ai_api_key', '');
        add_option('oncore_api_key', wp_generate_password(32, false));
        add_option('oncore_custom_css', '');
        flush_rewrite_rules();
    }
}

OnCore::instance();
