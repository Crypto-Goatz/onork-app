<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore License Key System
 *
 * Generates license keys, validates against 0nmcp.com, ties to domain.
 * On first activation, launches guided onboarding wizard.
 *
 * Key format: 0NCORE-XXXX-XXXX-XXXX-XXXX
 * Storage: Supabase licenses table via 0nmcp.com API
 * Fallback: Local validation for offline/development
 */
class OnCore_License {
    private static $instance = null;
    private $api_base = 'https://www.0nmcp.com/api/licenses';

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_init', [$this, 'check_license_redirect']);
        add_action('wp_ajax_oncore_activate_license', [$this, 'ajax_activate']);
        add_action('wp_ajax_oncore_deactivate_license', [$this, 'ajax_deactivate']);
        add_action('wp_ajax_oncore_complete_onboarding', [$this, 'ajax_complete_onboarding']);
        add_action('admin_notices', [$this, 'license_notice']);
    }

    /**
     * Check if license is active
     */
    public static function is_active() {
        $status = get_option('oncore_license_status', '');
        return $status === 'active';
    }

    /**
     * Get license data
     */
    public static function get_license() {
        return [
            'key' => get_option('oncore_license_key', ''),
            'status' => get_option('oncore_license_status', 'inactive'),
            'domain' => get_option('oncore_license_domain', ''),
            'activated_at' => get_option('oncore_license_activated_at', ''),
            'tier' => get_option('oncore_license_tier', 'free'),
            'onboarding_complete' => get_option('oncore_onboarding_complete', false),
        ];
    }

    /**
     * Generate a license key locally (for Mike to issue keys)
     */
    public static function generate_key($tier = 'free') {
        $segments = [];
        for ($i = 0; $i < 4; $i++) {
            $segments[] = strtoupper(substr(md5(wp_rand() . microtime(true) . $i), 0, 4));
        }
        return '0NCORE-' . implode('-', $segments);
    }

    /**
     * Activate a license key
     */
    public function activate($key) {
        $key = strtoupper(trim($key));
        if (!preg_match('/^0NCORE-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/', $key)) {
            return new WP_Error('invalid_format', 'Invalid license key format. Expected: 0NCORE-XXXX-XXXX-XXXX-XXXX');
        }

        $domain = $this->get_site_domain();

        // Try remote validation
        $response = wp_remote_post($this->api_base . '/activate', [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode([
                'key' => $key,
                'domain' => $domain,
                'site_url' => home_url(),
                'wp_version' => get_bloginfo('version'),
                'plugin_version' => ONCORE_VERSION,
            ]),
            'timeout' => 15,
        ]);

        $tier = 'free';
        $remote_ok = false;

        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($body['valid'])) {
                $tier = $body['tier'] ?? 'free';
                $remote_ok = true;
            } elseif (isset($body['error'])) {
                return new WP_Error('license_error', $body['error']);
            }
        }

        // Fallback: accept any properly formatted key (offline mode)
        if (!$remote_ok) {
            // Validate format is correct — accept it locally
            $tier = 'free';
        }

        // Store license
        update_option('oncore_license_key', $key);
        update_option('oncore_license_status', 'active');
        update_option('oncore_license_domain', $domain);
        update_option('oncore_license_activated_at', current_time('mysql'));
        update_option('oncore_license_tier', $tier);

        return [
            'status' => 'active',
            'key' => $key,
            'domain' => $domain,
            'tier' => $tier,
        ];
    }

    /**
     * Deactivate license
     */
    public function deactivate() {
        $key = get_option('oncore_license_key', '');
        if ($key) {
            // Notify remote
            wp_remote_post($this->api_base . '/deactivate', [
                'headers' => ['Content-Type' => 'application/json'],
                'body' => wp_json_encode([
                    'key' => $key,
                    'domain' => $this->get_site_domain(),
                ]),
                'timeout' => 10,
            ]);
        }

        delete_option('oncore_license_key');
        update_option('oncore_license_status', 'inactive');
        delete_option('oncore_license_domain');
        delete_option('oncore_license_activated_at');
        update_option('oncore_license_tier', 'free');
        update_option('oncore_onboarding_complete', false);

        return true;
    }

    /**
     * Redirect to onboarding if license active but onboarding not complete
     */
    public function check_license_redirect() {
        if (!is_admin() || wp_doing_ajax()) return;

        $screen = get_current_screen();
        if (!$screen) return;

        // Only redirect on 0nCore pages (not during onboarding itself)
        if (strpos($screen->id, 'oncore') === false) return;
        if ($screen->id === 'toplevel_page_oncore' || strpos($screen->id, 'oncore-onboarding') !== false) return;

        if (self::is_active() && !get_option('oncore_onboarding_complete', false)) {
            // Don't redirect, but show notice
        }
    }

    /**
     * Show admin notice if no license
     */
    public function license_notice() {
        if (self::is_active()) return;

        $screen = get_current_screen();
        if (!$screen || strpos($screen->id, 'oncore') === false) return;

        echo '<div class="notice notice-warning is-dismissible"><p>';
        echo '<strong>0nCore:</strong> Enter your license key to activate all features. ';
        echo '<a href="' . admin_url('admin.php?page=oncore') . '">Go to Settings</a>';
        echo '</p></div>';
    }

    /**
     * AJAX: Activate license
     */
    public function ajax_activate() {
        check_ajax_referer('oncore_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $key = sanitize_text_field($_POST['license_key'] ?? '');
        if (empty($key)) wp_send_json_error('License key required');

        $result = $this->activate($key);
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }

        wp_send_json_success($result);
    }

    /**
     * AJAX: Deactivate license
     */
    public function ajax_deactivate() {
        check_ajax_referer('oncore_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
        $this->deactivate();
        wp_send_json_success(['status' => 'deactivated']);
    }

    /**
     * AJAX: Complete onboarding step
     */
    public function ajax_complete_onboarding() {
        check_ajax_referer('oncore_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $step = sanitize_text_field($_POST['step'] ?? '');
        $data = $_POST['data'] ?? [];

        // Save step data
        switch ($step) {
            case 'business':
                foreach (['name','phone','email','address'] as $f) {
                    if (isset($data[$f])) update_option("oncore_business_{$f}", sanitize_text_field($data[$f]));
                }
                if (isset($data['schema_type'])) update_option('oncore_schema_type', sanitize_text_field($data['schema_type']));
                if (isset($data['lat'])) update_option('oncore_business_lat', sanitize_text_field($data['lat']));
                if (isset($data['lng'])) update_option('oncore_business_lng', sanitize_text_field($data['lng']));
                break;

            case 'tracking':
                if (isset($data['pixel_id'])) update_option('oncore_fb_pixel_id', sanitize_text_field($data['pixel_id']));
                if (isset($data['ga4_id'])) update_option('oncore_ga4_id', sanitize_text_field($data['ga4_id']));
                break;

            case 'crm':
                if (isset($data['webhook'])) update_option('oncore_crm_webhook', sanitize_text_field($data['webhook']));
                if (isset($data['pit'])) update_option('oncore_crm_pit', sanitize_text_field($data['pit']));
                if (isset($data['location_id'])) update_option('oncore_crm_location_id', sanitize_text_field($data['location_id']));
                break;

            case 'booking':
                if (isset($data['business_id'])) update_option('oncore_booking_business_id', sanitize_text_field($data['business_id']));
                break;

            case 'complete':
                update_option('oncore_onboarding_complete', true);
                break;
        }

        wp_send_json_success(['step' => $step, 'saved' => true]);
    }

    private function get_site_domain() {
        $url = home_url();
        $parsed = wp_parse_url($url);
        return $parsed['host'] ?? $url;
    }
}
