<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore SXO Scorer — Built-in content scoring
 * Same engine as WP-SXO but integrated into 0nCore.
 * Scores every post/page on save. Shows score in editor + post list.
 */
class OnCore_SXO_Scorer {
    private static $instance = null;
    private $weights = [
        'bluf' => 0.20, 'header_depth' => 0.15, 'info_gain' => 0.15,
        'table_trap' => 0.10, 'readability' => 0.15, 'schema' => 0.10,
        'internal_links' => 0.05, 'content_length' => 0.10,
    ];

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('save_post', [$this, 'score_on_save'], 20, 2);
        add_action('add_meta_boxes', [$this, 'add_meta_box']);
        add_filter('manage_posts_columns', [$this, 'add_column']);
        add_filter('manage_pages_columns', [$this, 'add_column']);
        add_action('manage_posts_custom_column', [$this, 'render_column'], 10, 2);
        add_action('manage_pages_custom_column', [$this, 'render_column'], 10, 2);
        add_action('wp_ajax_oncore_sxo_score', [$this, 'ajax_score']);
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function score_on_save($post_id, $post) {
        if (wp_is_post_revision($post_id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) return;
        if (!in_array($post->post_type, ['post', 'page']) || empty($post->post_content)) return;
        $score = $this->score($post->post_content, $post->post_title);
        update_post_meta($post_id, '_oncore_sxo_score', $score['overall']);
        update_post_meta($post_id, '_oncore_sxo_data', wp_json_encode($score));
        update_post_meta($post_id, '_oncore_sxo_at', current_time('mysql'));
    }

    public function ajax_score() {
        check_ajax_referer('oncore_nonce', 'nonce');
        $post = get_post(intval($_POST['post_id'] ?? 0));
        if (!$post) wp_send_json_error('Post not found');
        $score = $this->score($post->post_content, $post->post_title);
        update_post_meta($post->ID, '_oncore_sxo_score', $score['overall']);
        update_post_meta($post->ID, '_oncore_sxo_data', wp_json_encode($score));
        update_post_meta($post->ID, '_oncore_sxo_at', current_time('mysql'));
        wp_send_json_success($score);
    }

    public function register_routes() {
        register_rest_route('oncore/v1', '/sxo/score/(?P<id>\d+)', [
            'methods' => 'GET', 'callback' => [$this, 'api_get_score'], 'permission_callback' => '__return_true',
        ]);
        register_rest_route('oncore/v1', '/sxo/score', [
            'methods' => 'POST', 'callback' => [$this, 'api_score_content'],
            'permission_callback' => function($r) { $l = $r->get_header('X-OnCore-License'); return ($l && $l === get_option('oncore_license_key','')); },
        ]);
        register_rest_route('oncore/v1', '/sxo/health', [
            'methods' => 'GET', 'callback' => [$this, 'api_site_health'],
            'permission_callback' => function($r) { $l = $r->get_header('X-OnCore-License'); return ($l && $l === get_option('oncore_license_key','')); },
        ]);
    }

    public function api_get_score($r) {
        $id = intval($r->get_param('id'));
        $data = get_post_meta($id, '_oncore_sxo_data', true);
        return $data ? new \WP_REST_Response(json_decode($data, true)) : new \WP_REST_Response(['error' => 'Not scored'], 404);
    }

    public function api_score_content($r) {
        $p = $r->get_json_params();
        return new \WP_REST_Response($this->score($p['content'] ?? '', $p['title'] ?? ''));
    }

    public function api_site_health() {
        $posts = get_posts(['post_type' => ['post','page'], 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids']);
        $scored = 0; $total = 0; $grades = [];
        foreach ($posts as $pid) {
            $s = get_post_meta($pid, '_oncore_sxo_score', true);
            if ($s) { $scored++; $total += intval($s); $g = $this->grade(intval($s)); $grades[$g] = ($grades[$g] ?? 0) + 1; }
        }
        return new \WP_REST_Response([
            'total' => count($posts), 'scored' => $scored, 'unscored' => count($posts) - $scored,
            'avg_score' => $scored > 0 ? round($total / $scored) : 0, 'grades' => $grades,
        ]);
    }

    public function add_meta_box() {
        add_meta_box('oncore_sxo', 'SXO Score', [$this, 'render_meta_box'], ['post','page'], 'side', 'high');
    }

    public function render_meta_box($post) {
        $s = get_post_meta($post->ID, '_oncore_sxo_score', true);
        $data = json_decode(get_post_meta($post->ID, '_oncore_sxo_data', true) ?: '{}', true);
        $at = get_post_meta($post->ID, '_oncore_sxo_at', true);
        $c = $this->color($s);
        ?>
        <div style="text-align:center;padding:8px 0;">
        <?php if ($s): ?>
          <div style="font-size:42px;font-weight:900;color:<?php echo $c; ?>;line-height:1;"><?php echo intval($s); ?></div>
          <div style="font-size:12px;color:#666;margin:4px 0 12px;">Grade: <b><?php echo esc_html($data['grade'] ?? '?'); ?></b> &bull; <?php echo intval($data['word_count'] ?? 0); ?> words</div>
          <?php if (!empty($data['dimensions'])): foreach ($data['dimensions'] as $dim): ?>
          <div style="margin-bottom:6px;">
            <div style="display:flex;justify-content:space-between;font-size:10px;margin-bottom:2px;">
              <span style="color:#666;"><?php echo esc_html($dim['label']); ?></span>
              <span style="font-weight:700;color:<?php echo $this->color($dim['score']); ?>;"><?php echo intval($dim['score']); ?></span>
            </div>
            <div style="height:5px;background:#e5e7eb;border-radius:3px;overflow:hidden;">
              <div style="height:100%;width:<?php echo intval($dim['score']); ?>%;background:<?php echo $this->color($dim['score']); ?>;border-radius:3px;"></div>
            </div>
          </div>
          <?php endforeach; endif; ?>
          <?php if (!empty($data['recommendations'])): ?>
          <div style="background:#fef3c7;border:1px solid #fbbf24;border-radius:6px;padding:8px;margin:10px 0;text-align:left;">
            <?php foreach (array_slice($data['recommendations'], 0, 2) as $r): ?>
            <div style="font-size:10px;color:#78350f;margin-bottom:4px;"><b><?php echo esc_html($r['dimension']); ?>:</b> <?php echo esc_html($r['tips'][0] ?? ''); ?></div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        <?php else: ?>
          <div style="color:#999;font-size:13px;padding:12px;">Save post to generate SXO score.</div>
        <?php endif; ?>
        <button type="button" onclick="jQuery.post(oncore.ajax_url,{action:'oncore_sxo_score',nonce:oncore.nonce,post_id:<?php echo $post->ID; ?>},function(){location.reload();})" class="button button-primary" style="width:100%;margin-top:8px;">
          <?php echo $s ? 'Re-Score' : 'Score Content'; ?>
        </button>
        </div>
        <?php
    }

    public function add_column($cols) { $cols['oncore_sxo'] = 'SXO'; return $cols; }
    public function render_column($col, $pid) {
        if ($col !== 'oncore_sxo') return;
        $s = get_post_meta($pid, '_oncore_sxo_score', true);
        if ($s) echo '<span style="display:inline-block;min-width:28px;text-align:center;padding:2px 6px;border-radius:4px;font-size:11px;font-weight:700;background:' . $this->color($s) . '20;color:' . $this->color($s) . ';">' . intval($s) . '</span>';
        else echo '<span style="color:#ccc;">—</span>';
    }

    /** Core scoring engine */
    public function score($content, $title = '') {
        $text = wp_strip_all_tags($content);
        $wc = str_word_count($text);
        $dims = [
            'bluf' => $this->s_bluf($content, $text, $title),
            'header_depth' => $this->s_headers($content),
            'info_gain' => $this->s_info($text),
            'table_trap' => $this->s_table($content),
            'readability' => $this->s_read($text),
            'schema' => $this->s_schema($content),
            'internal_links' => $this->s_links($content),
            'content_length' => $this->s_length($wc),
        ];
        $overall = 0;
        foreach ($dims as $k => $d) $overall += $d['score'] * $this->weights[$k];
        $recs = [];
        foreach ($dims as $d) { if ($d['score'] < 60 && !empty($d['tips'])) $recs[] = ['dimension'=>$d['label'],'score'=>$d['score'],'tips'=>$d['tips']]; }
        usort($recs, fn($a,$b) => $a['score'] - $b['score']);
        return ['overall'=>round($overall),'dimensions'=>$dims,'word_count'=>$wc,'grade'=>$this->grade($overall),'recommendations'=>$recs];
    }

    private function s_bluf($html, $text, $title) {
        $s=0;$t=[];$f100=implode(' ',array_slice(explode(' ',$text),0,100));
        $tw=array_filter(explode(' ',strtolower($title)),fn($w)=>strlen($w)>3);$fl=strtolower($f100);$m=0;
        foreach($tw as $w){if(strpos($fl,$w)!==false)$m++;}
        $s+=count($tw)>0?($m/count($tw))*30:15;
        if(preg_match('/<h1/i',$html))$s+=20;else $t[]='Add H1 heading';
        if(preg_match('/<p[^>]*>(.*?)<\/p>/is',$html,$pm)){$pw=str_word_count(wp_strip_all_tags($pm[1]));if($pw>=20)$s+=25;elseif($pw>=10)$s+=15;}
        $fluff=['in this article','in this post','today we will','have you ever wondered'];$hf=false;
        foreach($fluff as $f){if(stripos($f100,$f)!==false){$hf=true;break;}}
        if(!$hf)$s+=25;else $t[]='Remove generic opener — lead with main point';
        return['score'=>min(100,round($s)),'tips'=>$t,'label'=>'BLUF Architecture'];
    }
    private function s_headers($html) {
        $s=0;$t=[];preg_match_all('/<h([1-6])/i',$html,$m);$h=$m[1]??[];
        if(!count($h))return['score'=>0,'tips'=>['Add H2/H3 headers'],'label'=>'Header Depth'];
        if(in_array('1',$h))$s+=20;$h2=count(array_filter($h,fn($x)=>$x==='2'));$h3=count(array_filter($h,fn($x)=>$x==='3'));
        if($h2>=3)$s+=30;elseif($h2>=1)$s+=15;else $t[]='Add 3+ H2 sections';
        if($h3>=2)$s+=25;elseif($h3>=1)$s+=15;else $t[]='Add H3 sub-sections';
        $s+=25;
        return['score'=>min(100,round($s)),'tips'=>$t,'label'=>'Header Depth'];
    }
    private function s_info($text) {
        $s=0;$t=[];preg_match_all('/\d+[\.,]?\d*\s*(%|percent|times|x\b)/i',$text,$st);
        if(count($st[0])>=3)$s+=25;elseif(count($st[0])>=1)$s+=15;else $t[]='Add statistics/data';
        $li=substr_count(strtolower($text),'<li');if($li>=5)$s+=20;elseif($li>=3)$s+=10;else $t[]='Add bullet lists';
        $depth=['for example','case study','step 1','how to','specifically'];$dc=0;
        foreach($depth as $d){if(stripos($text,$d)!==false)$dc++;}
        if($dc>=3)$s+=30;elseif($dc>=1)$s+=15;else $t[]='Add examples or how-to steps';
        $s+=25;
        return['score'=>min(100,round($s)),'tips'=>$t,'label'=>'Information Gain'];
    }
    private function s_table($html) {
        $s=0;$t=[];
        if(preg_match('/<table/i',$html))$s+=30;else $t[]='Add a data/comparison table';
        if(preg_match('/<ol/i',$html))$s+=20;if(preg_match('/<ul/i',$html))$s+=15;
        preg_match_all('/<strong/i',$html,$b);if(count($b[0])>=3)$s+=20;
        preg_match_all('/<h[2-4][^>]*>[^<]*\?/i',$html,$fq);if(count($fq[0])>=2)$s+=15;else $t[]='Add FAQ-style question headers';
        return['score'=>min(100,round($s)),'tips'=>$t,'label'=>'Table Trap'];
    }
    private function s_read($text) {
        $s=0;$t=[];$sents=preg_split('/[.!?]+/',$text,-1,PREG_SPLIT_NO_EMPTY);$sc=count($sents);
        if(!$sc)return['score'=>0,'tips'=>['Add content'],'label'=>'Readability'];
        $avg=str_word_count($text)/$sc;
        if($avg>=12&&$avg<=22)$s+=30;elseif($avg<=28)$s+=20;else $t[]='Shorten sentences to 15-20 words avg';
        $paras=preg_split('/\n\n|<\/p>/i',$text);$ap=str_word_count($text)/max(count($paras),1);
        if($ap<=80)$s+=25;elseif($ap<=120)$s+=15;else $t[]='Break up long paragraphs';
        $trans=['however','therefore','furthermore','for instance','as a result'];$tc=0;
        foreach($trans as $tr){if(stripos($text,$tr)!==false)$tc++;}
        if($tc>=3)$s+=25;elseif($tc>=1)$s+=15;else $t[]='Add transition words';
        $s+=20;
        return['score'=>min(100,round($s)),'tips'=>$t,'label'=>'Readability'];
    }
    private function s_schema($html) {
        $s=0;$t=[];
        if(preg_match('/ld\+json/i',$html))$s+=50;
        if(defined('WPSEO_VERSION')||defined('RANK_MATH_VERSION'))$s+=30;
        $s+=20;
        if($s<50)$t[]='Add Schema.org structured data';
        return['score'=>min(100,round($s)),'tips'=>$t,'label'=>'Schema Markup'];
    }
    private function s_links($html) {
        $s=0;$t=[];$su=home_url();preg_match_all('/href=["\']([^"\']+)/i',$html,$ls);$int=0;$ext=0;
        foreach($ls[1]??[] as $h){if(strpos($h,$su)!==false||strpos($h,'/')===0)$int++;elseif(strpos($h,'http')===0)$ext++;}
        if($int>=3)$s+=50;elseif($int>=1)$s+=20;else $t[]='Add 2-3 internal links';
        if($ext>=1)$s+=25;else $t[]='Add external authority link';
        $s+=25;
        return['score'=>min(100,round($s)),'tips'=>$t,'label'=>'Internal Links'];
    }
    private function s_length($wc) {
        $t=[];
        if($wc>=2000)$s=100;elseif($wc>=1500)$s=90;elseif($wc>=1000)$s=75;elseif($wc>=750)$s=60;elseif($wc>=500)$s=45;else{$s=20;$t[]='Aim for 1,000+ words';}
        return['score'=>$s,'tips'=>$t,'label'=>'Content Length'];
    }

    private function grade($s){if($s>=90)return'A+';if($s>=80)return'A';if($s>=70)return'B';if($s>=60)return'C';if($s>=50)return'D';return'F';}
    private function color($s){if($s>=80)return'#22c55e';if($s>=60)return'#eab308';if($s>=40)return'#f97316';return'#ef4444';}
}
