<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore CRM Integration
 * Connects to CRM via PIT token or webhook for contact management
 */
class OnCore_CRM {
    private static $instance = null;
    private $api_base = 'https://services.leadconnectorhq.com';
    private $api_version = '2021-07-28';

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_ajax_oncore_crm_search', [$this, 'ajax_search']);
        add_action('wp_ajax_oncore_crm_create', [$this, 'ajax_create']);
    }

    private function get_headers() {
        $pit = get_option('oncore_crm_pit', '');
        return [
            'Authorization' => "Bearer {$pit}",
            'Version' => $this->api_version,
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        ];
    }

    /**
     * Create or update a contact in CRM
     */
    public function upsert_contact($data) {
        $location_id = get_option('oncore_crm_location_id', '');
        if (empty($location_id)) return new WP_Error('no_location', 'CRM Location ID not configured');

        $utm = OnCore_Tracking::get_utm_params();

        $contact = [
            'locationId' => $location_id,
            'firstName' => sanitize_text_field($data['firstName'] ?? ''),
            'lastName' => sanitize_text_field($data['lastName'] ?? ''),
            'email' => sanitize_email($data['email'] ?? ''),
            'phone' => sanitize_text_field($data['phone'] ?? ''),
            'source' => sanitize_text_field($data['source'] ?? ($utm['utm_source'] ?? 'website')),
            'tags' => array_map('sanitize_text_field', $data['tags'] ?? ['website-lead', '0ncore']),
        ];

        // Build custom fields from UTM + form data
        $custom_fields = [];
        if (!empty($utm['utm_source'])) {
            $custom_fields[] = ['key' => 'how_did_you_hear_about_us', 'field_value' => $utm['utm_source']];
        }
        if (!empty($utm['gclid'])) {
            $custom_fields[] = ['key' => 'gclick_id', 'field_value' => $utm['gclid']];
        }
        if (!empty($data['service'])) {
            $custom_fields[] = ['key' => 'which_services_are_you_requesting', 'field_value' => $data['service']];
        }
        if (!empty($data['message'])) {
            $custom_fields[] = ['key' => 'your_message', 'field_value' => $data['message']];
        }
        if (!empty($custom_fields)) {
            $contact['customFields'] = $custom_fields;
        }

        // Add source tags based on UTM
        if (!empty($utm['fbclid']) || ($utm['utm_source'] ?? '') === 'facebook') {
            $contact['tags'][] = 'facebook-ad';
        }
        if (!empty($utm['gclid']) || ($utm['utm_source'] ?? '') === 'google') {
            $contact['tags'][] = 'google-ad';
            $contact['tags'][] = 'pmax-remarketing';
        }
        if (!empty($utm['utm_campaign'])) {
            $contact['tags'][] = 'campaign-' . sanitize_title($utm['utm_campaign']);
        }

        $response = wp_remote_post("{$this->api_base}/contacts/upsert", [
            'headers' => $this->get_headers(),
            'body' => wp_json_encode($contact),
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) return $response;

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $code = wp_remote_retrieve_response_code($response);

        if ($code >= 200 && $code < 300 && isset($body['contact'])) {
            return $body['contact'];
        }

        return new WP_Error('crm_error', $body['message'] ?? 'CRM API error', ['status' => $code]);
    }

    /**
     * Send to CRM webhook (simpler — no PIT token needed)
     */
    public function webhook_submit($data) {
        $webhook_url = get_option('oncore_crm_webhook', '');
        if (empty($webhook_url)) return new WP_Error('no_webhook', 'CRM Webhook URL not configured');

        $utm = OnCore_Tracking::get_utm_params();

        $payload = [
            'first_name' => sanitize_text_field($data['firstName'] ?? ''),
            'last_name' => sanitize_text_field($data['lastName'] ?? ''),
            'email' => sanitize_email($data['email'] ?? ''),
            'phone' => sanitize_text_field($data['phone'] ?? ''),
            'tags' => implode(',', array_map('sanitize_text_field', $data['tags'] ?? ['website-lead', '0ncore'])),
            'source' => $utm['utm_source'] ?? 'website',
            'customField' => [
                'how_did_you_hear_about_us' => $utm['utm_source'] ?? 'website',
                'gclick_id' => $utm['gclid'] ?? '',
                'which_services_are_you_requesting' => sanitize_text_field($data['service'] ?? ''),
                'wellness_goal' => sanitize_text_field($data['skinConcern'] ?? $data['goal'] ?? ''),
                'your_message' => sanitize_textarea_field($data['message'] ?? ''),
            ],
        ];

        $response = wp_remote_post($webhook_url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($payload),
            'timeout' => 10,
        ]);

        return !is_wp_error($response);
    }

    /**
     * Add contact to workflow
     */
    public function add_to_workflow($contact_id, $workflow_id) {
        $response = wp_remote_post("{$this->api_base}/contacts/{$contact_id}/workflow/{$workflow_id}", [
            'headers' => $this->get_headers(),
            'timeout' => 10,
        ]);
        return !is_wp_error($response);
    }

    public function ajax_search() {
        check_ajax_referer('oncore_nonce', 'nonce');
        $query = sanitize_text_field($_POST['query'] ?? '');
        $location = get_option('oncore_crm_location_id', '');

        $response = wp_remote_get("{$this->api_base}/contacts/search/duplicate?locationId={$location}&email={$query}", [
            'headers' => $this->get_headers(),
            'timeout' => 10,
        ]);

        if (is_wp_error($response)) wp_send_json_error($response->get_error_message());
        wp_send_json_success(json_decode(wp_remote_retrieve_body($response), true));
    }

    public function ajax_create() {
        check_ajax_referer('oncore_nonce', 'nonce');
        $data = $_POST['contact'] ?? [];
        $result = $this->upsert_contact($data);
        if (is_wp_error($result)) wp_send_json_error($result->get_error_message());
        wp_send_json_success($result);
    }
}
