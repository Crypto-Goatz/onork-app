<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore JWT Auto-Setup
 * Automatically configures JWT Authentication for the WP REST API.
 * Adds the secret key and CORS constant to wp-config.php on activation.
 */
class OnCore_JWT_Setup {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        // Auto-configure on admin init if not already done
        add_action('admin_init', [$this, 'maybe_configure_jwt']);

        // Show notice if JWT plugin is missing
        add_action('admin_notices', [$this, 'jwt_notice']);
    }

    /**
     * Auto-add JWT constants to wp-config.php if not present
     */
    public function maybe_configure_jwt() {
        // Skip if already configured
        if (defined('JWT_AUTH_SECRET_KEY')) return;

        // Skip if already attempted
        if (get_option('oncore_jwt_configured', false)) return;

        $config_path = ABSPATH . 'wp-config.php';

        // Check if wp-config.php exists and is writable
        if (!file_exists($config_path) || !is_writable($config_path)) {
            // Try one level up (common in some setups)
            $config_path = dirname(ABSPATH) . '/wp-config.php';
            if (!file_exists($config_path) || !is_writable($config_path)) return;
        }

        $config_content = file_get_contents($config_path);
        if ($config_content === false) return;

        // Don't modify if already has JWT constants
        if (strpos($config_content, 'JWT_AUTH_SECRET_KEY') !== false) {
            update_option('oncore_jwt_configured', true);
            return;
        }

        // Generate a unique secret key
        $secret = wp_generate_password(64, true, true);

        // Build the constants to add
        $jwt_config = "\n\n/** 0nCore JWT Authentication Configuration */\n";
        $jwt_config .= "define('JWT_AUTH_SECRET_KEY', '" . addslashes($secret) . "');\n";
        $jwt_config .= "define('JWT_AUTH_CORS_ENABLE', true);\n";

        // Insert before "That's all, stop editing"
        $marker = "/* That's all, stop editing!";
        if (strpos($config_content, $marker) !== false) {
            $config_content = str_replace($marker, $jwt_config . $marker, $config_content);
        } else {
            // Fallback: insert before the require_once ABSPATH line
            $fallback = "require_once ABSPATH";
            if (strpos($config_content, $fallback) !== false) {
                $config_content = str_replace($fallback, $jwt_config . $fallback, $config_content);
            } else {
                // Last resort: append before closing
                $config_content .= $jwt_config;
            }
        }

        // Write back
        $result = file_put_contents($config_path, $config_content);
        if ($result !== false) {
            update_option('oncore_jwt_configured', true);
            update_option('oncore_jwt_secret', $secret);
        }
    }

    /**
     * Show notice if JWT plugin is not active
     */
    public function jwt_notice() {
        if (!is_plugin_active('jwt-authentication-for-wp-rest-api/jwt-auth.php') &&
            !is_plugin_active('jwt-auth/jwt-auth.php')) {
            $screen = get_current_screen();
            if ($screen && strpos($screen->id, 'oncore') !== false) {
                echo '<div class="notice notice-info"><p><strong>0nCore:</strong> For full REST API access (Claude Code, remote management), install and activate the <a href="' . admin_url('plugin-install.php?s=jwt+authentication&tab=search&type=term') . '">JWT Authentication for WP REST API</a> plugin. 0nCore will auto-configure it.</p></div>';
            }
        }
    }
}
