<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore Auto-Updater — GitHub Releases
 * Checks Crypto-Goatz/0ncore-wp for new releases, shows update in WP dashboard.
 */
class OnCore_Updater {
    private static $instance = null;
    private $slug = '0ncore-wp';
    private $plugin_file;
    private $github_repo = 'Crypto-Goatz/0ncore-wp';
    private $github_api = 'https://api.github.com/repos/Crypto-Goatz/0ncore-wp/releases/latest';
    private $cache_key = 'oncore_update_check';
    private $cache_ttl = 43200; // 12 hours

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->plugin_file = plugin_basename(ONCORE_PLUGIN_FILE);
        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_update']);
        add_filter('plugins_api', [$this, 'plugin_info'], 20, 3);
        add_filter('upgrader_post_install', [$this, 'after_install'], 10, 3);
    }

    /**
     * Check GitHub for a newer release
     */
    public function check_update($transient) {
        if (empty($transient->checked)) return $transient;

        $release = $this->get_latest_release();
        if (!$release) return $transient;

        $remote_version = ltrim($release['tag_name'], 'v');
        $current_version = ONCORE_VERSION;

        if (version_compare($remote_version, $current_version, '>')) {
            $download_url = $this->get_download_url($release);
            if ($download_url) {
                $transient->response[$this->plugin_file] = (object) [
                    'slug' => $this->slug,
                    'plugin' => $this->plugin_file,
                    'new_version' => $remote_version,
                    'url' => "https://github.com/{$this->github_repo}",
                    'package' => $download_url,
                    'icons' => [
                        '1x' => ONCORE_PLUGIN_URL . 'assets/img/icon-128.png',
                        '2x' => ONCORE_PLUGIN_URL . 'assets/img/icon-256.png',
                    ],
                    'banners' => [
                        'low' => ONCORE_PLUGIN_URL . 'assets/img/banner-772x250.png',
                        'high' => ONCORE_PLUGIN_URL . 'assets/img/banner-1544x500.png',
                    ],
                ];
            }
        }

        return $transient;
    }

    /**
     * Show plugin info in the update modal
     */
    public function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information' || !isset($args->slug) || $args->slug !== $this->slug) {
            return $result;
        }

        $release = $this->get_latest_release();
        if (!$release) return $result;

        $remote_version = ltrim($release['tag_name'], 'v');

        return (object) [
            'name' => '0nCore',
            'slug' => $this->slug,
            'version' => $remote_version,
            'author' => '<a href="https://rocketopp.com">RocketOpp LLC</a>',
            'author_profile' => 'https://rocketopp.com',
            'homepage' => 'https://0ncore.com',
            'requires' => '6.0',
            'tested' => '6.8',
            'requires_php' => '8.0',
            'download_link' => $this->get_download_url($release),
            'trunk' => $this->get_download_url($release),
            'last_updated' => $release['published_at'] ?? '',
            'sections' => [
                'description' => '<p>Connect your WordPress site to the 0nCore ecosystem — CRM integration, AI-powered forms, Meta Pixel + GA4 tracking, MassageBook booking, SXO page generation, and schema.org SEO.</p>',
                'changelog' => $this->format_changelog($release),
                'installation' => '<p>Upload the plugin zip, activate, then go to <strong>0nCore</strong> in the sidebar to configure.</p>',
            ],
            'banners' => [
                'low' => ONCORE_PLUGIN_URL . 'assets/img/banner-772x250.png',
                'high' => ONCORE_PLUGIN_URL . 'assets/img/banner-1544x500.png',
            ],
        ];
    }

    /**
     * Fix directory name after install (GitHub zips have repo-branch suffix)
     */
    public function after_install($response, $hook_extra, $result) {
        if (!isset($hook_extra['plugin']) || $hook_extra['plugin'] !== $this->plugin_file) {
            return $result;
        }

        global $wp_filesystem;
        $proper_dir = WP_PLUGIN_DIR . '/' . $this->slug;
        $wp_filesystem->move($result['destination'], $proper_dir);
        $result['destination'] = $proper_dir;

        activate_plugin($this->plugin_file);
        return $result;
    }

    /**
     * Fetch latest release from GitHub (cached)
     */
    private function get_latest_release() {
        $cached = get_transient($this->cache_key);
        if ($cached !== false) return $cached;

        $response = wp_remote_get($this->github_api, [
            'headers' => [
                'Accept' => 'application/vnd.github.v3+json',
                'User-Agent' => '0nCore-WordPress-Plugin/' . ONCORE_VERSION,
            ],
            'timeout' => 10,
        ]);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return null;
        }

        $release = json_decode(wp_remote_retrieve_body($response), true);
        if (!$release || !isset($release['tag_name'])) return null;

        set_transient($this->cache_key, $release, $this->cache_ttl);
        return $release;
    }

    /**
     * Get the zip download URL from a release
     */
    private function get_download_url($release) {
        // Prefer uploaded asset named 0ncore-wp.zip
        if (!empty($release['assets'])) {
            foreach ($release['assets'] as $asset) {
                if (strpos($asset['name'], '.zip') !== false) {
                    return $asset['browser_download_url'];
                }
            }
        }
        // Fall back to source zip
        return $release['zipball_url'] ?? null;
    }

    private function format_changelog($release) {
        $body = $release['body'] ?? 'No changelog provided.';
        return '<pre>' . esc_html($body) . '</pre>';
    }
}
