<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore SXO Template Override
 *
 * Check a box on any page → theme is completely bypassed.
 * Page renders on a clean 0nCore canvas with:
 * - Zero theme CSS/JS/header/footer
 * - 0nCore tracking auto-injected (Pixel + GA4)
 * - Schema.org auto-injected
 * - Custom CSS/JS per page via meta fields
 * - Full responsive SXO structure
 *
 * Meta fields added to page editor:
 * - _oncore_override (checkbox) — activate 0nCore template
 * - _oncore_page_css (textarea) — custom CSS for this page
 * - _oncore_page_js (textarea) — custom JS for this page
 * - _oncore_head_scripts (textarea) — scripts in <head>
 * - _oncore_body_class (text) — extra body classes
 * - _oncore_hide_nav (checkbox) — hide the 0nCore sticky nav
 * - _oncore_nav_logo (text) — custom logo URL for nav
 * - _oncore_nav_cta_text (text) — CTA button text
 * - _oncore_nav_cta_url (text) — CTA button URL
 * - _oncore_bg_color (text) — page background color
 * - _oncore_font_display (text) — display font (Google Fonts name)
 * - _oncore_font_body (text) — body font (Google Fonts name)
 */
class OnCore_Template {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('add_meta_boxes', [$this, 'add_meta_box']);
        add_action('save_post', [$this, 'save_meta'], 10, 2);
        add_filter('template_include', [$this, 'override_template'], 999);

        // REST API for toggling override remotely
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    /**
     * Add 0nCore meta box to page editor
     */
    public function add_meta_box() {
        add_meta_box(
            'oncore_template_override',
            '0nCore SXO Template',
            [$this, 'render_meta_box'],
            'page',
            'side',
            'high'
        );
        add_meta_box(
            'oncore_page_settings',
            '0nCore Page Settings',
            [$this, 'render_settings_box'],
            'page',
            'normal',
            'high'
        );
    }

    /**
     * Sidebar meta box — the checkbox
     */
    public function render_meta_box($post) {
        wp_nonce_field('oncore_template_nonce', '_oncore_nonce');
        $override = get_post_meta($post->ID, '_oncore_override', true);
        $hide_nav = get_post_meta($post->ID, '_oncore_hide_nav', true);
        ?>
        <label style="display:flex;align-items:center;gap:8px;padding:8px 0;font-size:14px;font-weight:600;">
            <input type="checkbox" name="_oncore_override" value="1" <?php checked($override, '1'); ?>>
            Use 0nCore Template
        </label>
        <p style="font-size:11px;color:#666;margin:4px 0 12px;">Bypasses your theme entirely. Clean SXO canvas with tracking, schema, and custom styling.</p>

        <label style="display:flex;align-items:center;gap:8px;padding:4px 0;font-size:13px;">
            <input type="checkbox" name="_oncore_hide_nav" value="1" <?php checked($hide_nav, '1'); ?>>
            Hide 0nCore navigation bar
        </label>
        <?php
    }

    /**
     * Full settings meta box — custom CSS, JS, fonts, colors
     */
    public function render_settings_box($post) {
        $css = get_post_meta($post->ID, '_oncore_page_css', true);
        $js = get_post_meta($post->ID, '_oncore_page_js', true);
        $head = get_post_meta($post->ID, '_oncore_head_scripts', true);
        $body_class = get_post_meta($post->ID, '_oncore_body_class', true);
        $logo = get_post_meta($post->ID, '_oncore_nav_logo', true);
        $cta_text = get_post_meta($post->ID, '_oncore_nav_cta_text', true);
        $cta_url = get_post_meta($post->ID, '_oncore_nav_cta_url', true);
        $bg = get_post_meta($post->ID, '_oncore_bg_color', true);
        $font_d = get_post_meta($post->ID, '_oncore_font_display', true);
        $font_b = get_post_meta($post->ID, '_oncore_font_body', true);

        $override = get_post_meta($post->ID, '_oncore_override', true);
        if (!$override) {
            echo '<p style="color:#666;font-size:13px;">Enable "Use 0nCore Template" in the sidebar to see these settings.</p>';
            echo '<div style="opacity:0.4;pointer-events:none;">';
        }
        ?>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
            <div>
                <label style="font-size:12px;font-weight:600;color:#555;">Display Font (Google Fonts)</label>
                <input type="text" name="_oncore_font_display" value="<?php echo esc_attr($font_d ?: 'Playfair Display'); ?>" class="widefat" placeholder="Playfair Display" style="margin-top:4px;">
            </div>
            <div>
                <label style="font-size:12px;font-weight:600;color:#555;">Body Font (Google Fonts)</label>
                <input type="text" name="_oncore_font_body" value="<?php echo esc_attr($font_b ?: 'Lato'); ?>" class="widefat" placeholder="Lato" style="margin-top:4px;">
            </div>
            <div>
                <label style="font-size:12px;font-weight:600;color:#555;">Background Color</label>
                <input type="text" name="_oncore_bg_color" value="<?php echo esc_attr($bg ?: '#F5EDE0'); ?>" class="widefat" placeholder="#F5EDE0" style="margin-top:4px;">
            </div>
            <div>
                <label style="font-size:12px;font-weight:600;color:#555;">Body Class</label>
                <input type="text" name="_oncore_body_class" value="<?php echo esc_attr($body_class); ?>" class="widefat" placeholder="landing-page spa" style="margin-top:4px;">
            </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-top:16px;">
            <div>
                <label style="font-size:12px;font-weight:600;color:#555;">Nav Logo URL</label>
                <input type="text" name="_oncore_nav_logo" value="<?php echo esc_attr($logo); ?>" class="widefat" placeholder="https://..." style="margin-top:4px;">
            </div>
            <div>
                <label style="font-size:12px;font-weight:600;color:#555;">CTA Button Text</label>
                <input type="text" name="_oncore_nav_cta_text" value="<?php echo esc_attr($cta_text ?: 'Book Now'); ?>" class="widefat" style="margin-top:4px;">
            </div>
            <div>
                <label style="font-size:12px;font-weight:600;color:#555;">CTA Button URL</label>
                <input type="text" name="_oncore_nav_cta_url" value="<?php echo esc_attr($cta_url); ?>" class="widefat" placeholder="https://..." style="margin-top:4px;">
            </div>
        </div>

        <div style="margin-top:16px;">
            <label style="font-size:12px;font-weight:600;color:#555;">Custom CSS (this page only)</label>
            <textarea name="_oncore_page_css" rows="6" class="widefat" style="margin-top:4px;font-family:monospace;font-size:12px;" placeholder="/* Your custom CSS */"><?php echo esc_textarea($css); ?></textarea>
        </div>

        <div style="margin-top:16px;">
            <label style="font-size:12px;font-weight:600;color:#555;">Custom JavaScript (this page only)</label>
            <textarea name="_oncore_page_js" rows="4" class="widefat" style="margin-top:4px;font-family:monospace;font-size:12px;" placeholder="// Your custom JS"><?php echo esc_textarea($js); ?></textarea>
        </div>

        <div style="margin-top:16px;">
            <label style="font-size:12px;font-weight:600;color:#555;">Head Scripts (tracking pixels, etc.)</label>
            <textarea name="_oncore_head_scripts" rows="3" class="widefat" style="margin-top:4px;font-family:monospace;font-size:12px;" placeholder="<!-- Additional head scripts -->"><?php echo esc_textarea($head); ?></textarea>
        </div>

        <?php if (!$override) echo '</div>'; ?>
        <?php
    }

    /**
     * Save meta fields
     */
    public function save_meta($post_id, $post) {
        if (!isset($_POST['_oncore_nonce']) || !wp_verify_nonce($_POST['_oncore_nonce'], 'oncore_template_nonce')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if ($post->post_type !== 'page') return;
        if (!current_user_can('edit_page', $post_id)) return;

        $fields = [
            '_oncore_override', '_oncore_hide_nav', '_oncore_page_css', '_oncore_page_js',
            '_oncore_head_scripts', '_oncore_body_class', '_oncore_nav_logo',
            '_oncore_nav_cta_text', '_oncore_nav_cta_url', '_oncore_bg_color',
            '_oncore_font_display', '_oncore_font_body',
        ];

        foreach ($fields as $key) {
            if (isset($_POST[$key])) {
                update_post_meta($post_id, $key, sanitize_textarea_field($_POST[$key]));
            } else {
                delete_post_meta($post_id, $key);
            }
        }
    }

    /**
     * Override theme template when checkbox is checked
     */
    public function override_template($template) {
        if (!is_page()) return $template;

        $post_id = get_queried_object_id();
        $override = get_post_meta($post_id, '_oncore_override', true);

        if ($override !== '1') return $template;

        // Use our own template — completely bypasses the theme
        return ONCORE_PLUGIN_DIR . 'templates/canvas.php';
    }

    /**
     * REST API — toggle override remotely
     */
    public function register_routes() {
        register_rest_route('oncore/v1', '/template/(?P<id>\d+)', [
            'methods' => 'POST',
            'callback' => [$this, 'api_set_template'],
            'permission_callback' => function($req) {
                $license = $req->get_header('X-OnCore-License');
                return ($license && $license === get_option('oncore_license_key', ''));
            },
        ]);
    }

    public function api_set_template($request) {
        $post_id = intval($request->get_param('id'));
        $params = $request->get_json_params();

        if (isset($params['override'])) {
            update_post_meta($post_id, '_oncore_override', $params['override'] ? '1' : '');
        }

        $meta_fields = [
            'hide_nav' => '_oncore_hide_nav',
            'page_css' => '_oncore_page_css',
            'page_js' => '_oncore_page_js',
            'head_scripts' => '_oncore_head_scripts',
            'body_class' => '_oncore_body_class',
            'nav_logo' => '_oncore_nav_logo',
            'nav_cta_text' => '_oncore_nav_cta_text',
            'nav_cta_url' => '_oncore_nav_cta_url',
            'bg_color' => '_oncore_bg_color',
            'font_display' => '_oncore_font_display',
            'font_body' => '_oncore_font_body',
        ];

        foreach ($meta_fields as $key => $meta_key) {
            if (isset($params[$key])) {
                update_post_meta($post_id, $meta_key, sanitize_textarea_field($params[$key]));
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'page_id' => $post_id,
            'override' => get_post_meta($post_id, '_oncore_override', true) === '1',
            'url' => get_permalink($post_id),
        ]);
    }
}
