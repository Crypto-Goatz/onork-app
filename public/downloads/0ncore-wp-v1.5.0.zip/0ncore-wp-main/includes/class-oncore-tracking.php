<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore Tracking — Meta Pixel + GA4 + UTM Capture
 * Injects tracking scripts sitewide, captures UTM params in cookies for CRM
 */
class OnCore_Tracking {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_head', [$this, 'inject_pixel'], 1);
        add_action('wp_head', [$this, 'inject_ga4'], 2);
        add_action('wp_head', [$this, 'inject_utm_capture'], 5);
    }

    public function inject_pixel() {
        $pixel_id = get_option('oncore_fb_pixel_id', '');
        if (empty($pixel_id)) return;
        ?>
        <!-- 0nCore: Meta Pixel -->
        <script>
        !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
        n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
        document,'script','https://connect.facebook.net/en_US/fbevents.js');
        fbq('init','<?php echo esc_attr($pixel_id); ?>');
        fbq('track','PageView');
        </script>
        <noscript><img height="1" width="1" style="display:none"
        src="https://www.facebook.com/tr?id=<?php echo esc_attr($pixel_id); ?>&ev=PageView&noscript=1"/></noscript>
        <?php
    }

    public function inject_ga4() {
        $ga4_id = get_option('oncore_ga4_id', '');
        if (empty($ga4_id)) return;
        ?>
        <!-- 0nCore: GA4 -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo esc_attr($ga4_id); ?>"></script>
        <script>
        window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}
        gtag('js',new Date());gtag('config','<?php echo esc_attr($ga4_id); ?>');
        </script>
        <?php
    }

    public function inject_utm_capture() {
        if (get_option('oncore_utm_tracking', '1') !== '1') return;
        ?>
        <!-- 0nCore: UTM Capture -->
        <script>
        (function(){
            var p=new URLSearchParams(location.search);
            var utms=['utm_source','utm_medium','utm_campaign','utm_content','utm_term','fbclid','gclid','ref'];
            var d={};
            utms.forEach(function(k){var v=p.get(k);if(v){d[k]=v;}});
            if(Object.keys(d).length>0){
                document.cookie='oncore_utm='+encodeURIComponent(JSON.stringify(d))+';path=/;max-age=2592000;SameSite=Lax';
            }
        })();
        </script>
        <?php
    }

    /**
     * Get stored UTM params from cookie (server-side)
     */
    public static function get_utm_params() {
        $raw = isset($_COOKIE['oncore_utm']) ? sanitize_text_field(wp_unslash($_COOKIE['oncore_utm'])) : '';
        if (empty($raw)) return [];
        $data = json_decode(urldecode($raw), true);
        return is_array($data) ? $data : [];
    }
}
