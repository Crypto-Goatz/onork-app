<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore AI Page Generator
 *
 * Generates full SXO-optimized WordPress pages using AI.
 * Creates Gutenberg block markup with all tracking, forms, booking, and schema built in.
 *
 * REST API: POST /wp-json/oncore/v1/generate-page
 * Admin UI: 0nCore → AI Generator
 */
class OnCore_AI_Generator {
    private static $instance = null;
    private $anthropic_api = 'https://api.anthropic.com/v1/messages';

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
        add_action('wp_ajax_oncore_ai_generate', [$this, 'ajax_generate']);
        add_action('wp_ajax_oncore_ai_preview', [$this, 'ajax_preview']);
    }

    /**
     * Register REST API routes
     */
    public function register_routes() {
        register_rest_route('oncore/v1', '/generate-page', [
            'methods' => 'POST',
            'callback' => [$this, 'api_generate_page'],
            'permission_callback' => function() { return current_user_can('edit_posts'); },
            'args' => [
                'topic' => ['required' => true, 'type' => 'string'],
                'page_type' => ['type' => 'string', 'default' => 'landing'],
                'style' => ['type' => 'string', 'default' => 'professional'],
                'include_form' => ['type' => 'boolean', 'default' => true],
                'include_booking' => ['type' => 'boolean', 'default' => true],
                'include_faq' => ['type' => 'boolean', 'default' => true],
                'include_reviews' => ['type' => 'boolean', 'default' => true],
                'services' => ['type' => 'array', 'default' => []],
                'publish' => ['type' => 'boolean', 'default' => false],
            ],
        ]);

        register_rest_route('oncore/v1', '/generate-post', [
            'methods' => 'POST',
            'callback' => [$this, 'api_generate_post'],
            'permission_callback' => function() { return current_user_can('edit_posts'); },
            'args' => [
                'topic' => ['required' => true, 'type' => 'string'],
                'keywords' => ['type' => 'array', 'default' => []],
                'word_count' => ['type' => 'integer', 'default' => 1500],
                'publish' => ['type' => 'boolean', 'default' => false],
            ],
        ]);
    }

    /**
     * Generate a full landing page via REST API
     */
    public function api_generate_page($request) {
        $topic = sanitize_text_field($request->get_param('topic'));
        $page_type = sanitize_text_field($request->get_param('page_type'));
        $style = sanitize_text_field($request->get_param('style'));
        $include_form = (bool) $request->get_param('include_form');
        $include_booking = (bool) $request->get_param('include_booking');
        $include_faq = (bool) $request->get_param('include_faq');
        $include_reviews = (bool) $request->get_param('include_reviews');
        $publish = (bool) $request->get_param('publish');

        $business = $this->get_business_context();
        $result = $this->generate_page_content($topic, $page_type, $style, $business, [
            'form' => $include_form,
            'booking' => $include_booking,
            'faq' => $include_faq,
            'reviews' => $include_reviews,
        ]);

        if (is_wp_error($result)) {
            return new WP_REST_Response(['error' => $result->get_error_message()], 500);
        }

        // Create the WP page
        $page_id = wp_insert_post([
            'post_title' => $result['title'],
            'post_content' => $result['content'],
            'post_status' => $publish ? 'publish' : 'draft',
            'post_type' => 'page',
            'post_name' => sanitize_title($result['title']),
            'meta_input' => [
                '_oncore_generated' => true,
                '_oncore_topic' => $topic,
                '_oncore_sxo_score' => $result['sxo_score'] ?? 0,
                '_yoast_wpseo_title' => $result['meta_title'] ?? $result['title'],
                '_yoast_wpseo_metadesc' => $result['meta_description'] ?? '',
            ],
        ]);

        if (is_wp_error($page_id)) {
            return new WP_REST_Response(['error' => $page_id->get_error_message()], 500);
        }

        return new WP_REST_Response([
            'success' => true,
            'page_id' => $page_id,
            'url' => get_permalink($page_id),
            'edit_url' => admin_url("post.php?post={$page_id}&action=edit"),
            'title' => $result['title'],
            'sxo_score' => $result['sxo_score'] ?? 0,
            'word_count' => $result['word_count'] ?? 0,
        ], 201);
    }

    /**
     * Generate a blog post via REST API
     */
    public function api_generate_post($request) {
        $topic = sanitize_text_field($request->get_param('topic'));
        $keywords = array_map('sanitize_text_field', $request->get_param('keywords') ?: []);
        $word_count = (int) $request->get_param('word_count');
        $publish = (bool) $request->get_param('publish');

        $business = $this->get_business_context();
        $result = $this->generate_post_content($topic, $keywords, $word_count, $business);

        if (is_wp_error($result)) {
            return new WP_REST_Response(['error' => $result->get_error_message()], 500);
        }

        $post_id = wp_insert_post([
            'post_title' => $result['title'],
            'post_content' => $result['content'],
            'post_status' => $publish ? 'publish' : 'draft',
            'post_type' => 'post',
            'post_name' => sanitize_title($result['title']),
            'meta_input' => [
                '_oncore_generated' => true,
                '_oncore_topic' => $topic,
                '_yoast_wpseo_title' => $result['meta_title'] ?? $result['title'],
                '_yoast_wpseo_metadesc' => $result['meta_description'] ?? '',
            ],
        ]);

        if (is_wp_error($post_id)) {
            return new WP_REST_Response(['error' => $post_id->get_error_message()], 500);
        }

        return new WP_REST_Response([
            'success' => true,
            'post_id' => $post_id,
            'url' => get_permalink($post_id),
            'title' => $result['title'],
        ], 201);
    }

    /**
     * AJAX handler for admin UI
     */
    public function ajax_generate() {
        check_ajax_referer('oncore_nonce', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Unauthorized');

        $topic = sanitize_text_field($_POST['topic'] ?? '');
        $page_type = sanitize_text_field($_POST['page_type'] ?? 'landing');
        $style = sanitize_text_field($_POST['style'] ?? 'professional');
        $publish = !empty($_POST['publish']);

        if (empty($topic)) wp_send_json_error('Topic is required');

        $business = $this->get_business_context();
        $result = $this->generate_page_content($topic, $page_type, $style, $business, [
            'form' => true, 'booking' => true, 'faq' => true, 'reviews' => true,
        ]);

        if (is_wp_error($result)) wp_send_json_error($result->get_error_message());

        $page_id = wp_insert_post([
            'post_title' => $result['title'],
            'post_content' => $result['content'],
            'post_status' => $publish ? 'publish' : 'draft',
            'post_type' => 'page',
            'post_name' => sanitize_title($result['title']),
        ]);

        if (is_wp_error($page_id)) wp_send_json_error($page_id->get_error_message());

        wp_send_json_success([
            'page_id' => $page_id,
            'url' => get_permalink($page_id),
            'edit_url' => admin_url("post.php?post={$page_id}&action=edit"),
            'title' => $result['title'],
        ]);
    }

    /**
     * Preview without saving
     */
    public function ajax_preview() {
        check_ajax_referer('oncore_nonce', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Unauthorized');

        $topic = sanitize_text_field($_POST['topic'] ?? '');
        if (empty($topic)) wp_send_json_error('Topic is required');

        $business = $this->get_business_context();
        $result = $this->generate_page_content($topic, 'landing', 'professional', $business, [
            'form' => true, 'booking' => true, 'faq' => true, 'reviews' => true,
        ]);

        if (is_wp_error($result)) wp_send_json_error($result->get_error_message());
        wp_send_json_success($result);
    }

    /**
     * Generate page content using Claude API
     */
    private function generate_page_content($topic, $page_type, $style, $business, $includes) {
        $api_key = get_option('oncore_ai_api_key', '');
        if (empty($api_key)) {
            return new WP_Error('no_api_key', 'AI API key not configured. Go to 0nCore → AI Generator to add your Anthropic API key.');
        }

        $booking_shortcodes = '';
        if ($includes['booking']) {
            $booking_shortcodes = "\n- Include [oncore_booking service_id=\"219925\" label=\"Book Now\"] buttons where appropriate";
        }
        $form_shortcodes = '';
        if ($includes['form']) {
            $form_shortcodes = "\n- Include a [oncore_form title=\"Free Consultation\" fields=\"name,email,phone\" tags=\"{$topic}-interest\"] section";
        }

        $system_prompt = "You are an SXO (Search Experience Optimization) page generator for WordPress. You generate Gutenberg block markup that creates beautiful, high-converting landing pages.

SXO Principles:
- BLUF (Bottom Line Up Front) — lead with the value proposition
- Table Trap — structured data that Google can feature
- Information Gain — content that adds value beyond competitors
- Schema.org markup is handled separately, focus on content only

Business Context:
- Name: {$business['name']}
- Phone: {$business['phone']}
- Email: {$business['email']}
- Address: {$business['address']}

Output ONLY valid WordPress Gutenberg block markup. Use these blocks:
- <!-- wp:heading --> for H1, H2, H3
- <!-- wp:paragraph --> for text
- <!-- wp:list --> for bullet/numbered lists
- <!-- wp:separator --> for dividers
- <!-- wp:columns --> and <!-- wp:column --> for layouts
- <!-- wp:group --> for sections with backgrounds
- <!-- wp:image --> for images (use Unsplash URLs)
- <!-- wp:buttons --> and <!-- wp:button --> for CTAs
- <!-- wp:shortcode --> for 0nCore shortcodes

Include these 0nCore shortcodes where appropriate:{$booking_shortcodes}{$form_shortcodes}
- Use [oncore_phone] for click-to-call links
- Use [oncore_map] at the bottom for location

Style: {$style}
Page type: {$page_type}";

        $user_prompt = "Generate a complete SXO landing page for: {$topic}

Requirements:
1. Compelling H1 with the main keyword
2. Hero section with value proposition (2-3 sentences)
3. Benefits section (3 columns) with clear headings
4. Service/product details section with descriptions
5. Social proof / testimonials section (3 reviews)" .
($includes['faq'] ? "\n6. FAQ section (5-6 questions with detailed answers)" : "") .
($includes['form'] ? "\n7. Lead capture form section" : "") . "
8. Final CTA section
9. Generate a meta title (under 60 chars) and meta description (under 160 chars)

Return the content in this JSON format:
{
  \"title\": \"Page Title\",
  \"meta_title\": \"SEO Title | Business Name\",
  \"meta_description\": \"Meta description under 160 chars\",
  \"content\": \"<!-- wp:heading -->\\n<h1>...</h1>\\n<!-- /wp:heading -->\\n...\",
  \"sxo_score\": 85,
  \"word_count\": 1200
}";

        $response = wp_remote_post($this->anthropic_api, [
            'headers' => [
                'Content-Type' => 'application/json',
                'x-api-key' => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => wp_json_encode([
                'model' => 'claude-sonnet-4-20250514',
                'max_tokens' => 8192,
                'system' => $system_prompt,
                'messages' => [
                    ['role' => 'user', 'content' => $user_prompt],
                ],
            ]),
            'timeout' => 120,
        ]);

        if (is_wp_error($response)) {
            return new WP_Error('api_error', 'Claude API request failed: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code !== 200) {
            $msg = $body['error']['message'] ?? "API error (HTTP {$code})";
            return new WP_Error('api_error', $msg);
        }

        $text = $body['content'][0]['text'] ?? '';

        // Parse JSON from response
        $json_match = [];
        if (preg_match('/\{[\s\S]*\}/m', $text, $json_match)) {
            $parsed = json_decode($json_match[0], true);
            if ($parsed && isset($parsed['content'])) {
                return $parsed;
            }
        }

        // Fallback: treat entire response as content
        return [
            'title' => $topic,
            'meta_title' => $topic,
            'meta_description' => '',
            'content' => $text,
            'sxo_score' => 0,
            'word_count' => str_word_count(strip_tags($text)),
        ];
    }

    /**
     * Generate blog post content
     */
    private function generate_post_content($topic, $keywords, $word_count, $business) {
        $api_key = get_option('oncore_ai_api_key', '');
        if (empty($api_key)) {
            return new WP_Error('no_api_key', 'AI API key not configured.');
        }

        $kw_str = !empty($keywords) ? implode(', ', $keywords) : $topic;

        $response = wp_remote_post($this->anthropic_api, [
            'headers' => [
                'Content-Type' => 'application/json',
                'x-api-key' => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => wp_json_encode([
                'model' => 'claude-sonnet-4-20250514',
                'max_tokens' => 8192,
                'system' => "You are an SXO blog writer. Generate WordPress Gutenberg block markup for blog posts. Use BLUF architecture, include H2/H3 headers, bullet lists, and a clear CTA. Business: {$business['name']}. Keywords to target: {$kw_str}.",
                'messages' => [
                    ['role' => 'user', 'content' => "Write a {$word_count}-word SXO blog post about: {$topic}\n\nReturn JSON: {\"title\": \"...\", \"meta_title\": \"...\", \"meta_description\": \"...\", \"content\": \"<!-- wp:heading -->...\"}"],
                ],
            ]),
            'timeout' => 120,
        ]);

        if (is_wp_error($response)) return $response;

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (wp_remote_retrieve_response_code($response) !== 200) {
            return new WP_Error('api_error', $body['error']['message'] ?? 'API error');
        }

        $text = $body['content'][0]['text'] ?? '';
        $json_match = [];
        if (preg_match('/\{[\s\S]*\}/m', $text, $json_match)) {
            $parsed = json_decode($json_match[0], true);
            if ($parsed && isset($parsed['content'])) return $parsed;
        }

        return ['title' => $topic, 'content' => $text, 'meta_title' => $topic, 'meta_description' => ''];
    }

    /**
     * Get business context from settings
     */
    private function get_business_context() {
        return [
            'name' => get_option('oncore_business_name', get_bloginfo('name')),
            'phone' => get_option('oncore_business_phone', ''),
            'email' => get_option('oncore_business_email', get_option('admin_email')),
            'address' => get_option('oncore_business_address', ''),
        ];
    }
}
