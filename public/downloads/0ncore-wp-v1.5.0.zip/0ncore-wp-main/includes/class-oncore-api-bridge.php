<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore API Bridge — Full WordPress Control via REST API
 *
 * This is the core differentiator. Exposes EVERY WordPress capability
 * through authenticated REST endpoints that Claude / 0nMCP can call.
 *
 * Endpoints:
 *   POST /wp-json/oncore/v1/pages          — Create/update pages
 *   POST /wp-json/oncore/v1/posts          — Create/update posts
 *   POST /wp-json/oncore/v1/media          — Upload media from URL
 *   POST /wp-json/oncore/v1/menus          — Manage navigation menus
 *   POST /wp-json/oncore/v1/settings       — Update site settings
 *   POST /wp-json/oncore/v1/theme          — Customize theme/CSS
 *   POST /wp-json/oncore/v1/plugins        — List/manage plugins
 *   POST /wp-json/oncore/v1/widgets        — Manage widgets
 *   GET  /wp-json/oncore/v1/site-info      — Full site snapshot
 *   POST /wp-json/oncore/v1/bulk           — Execute multiple operations
 *   POST /wp-json/oncore/v1/execute        — Natural language → action
 *
 * Auth: JWT token via Authorization header OR 0nCore license key
 */
class OnCore_API_Bridge {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    private function check_auth($request) {
        // Check JWT auth (from jwt-auth plugin)
        if (is_user_logged_in() && current_user_can('edit_posts')) return true;

        // Check 0nCore API key header
        $api_key = $request->get_header('X-OnCore-Key');
        if ($api_key && $api_key === get_option('oncore_api_key', '')) {
            return !empty($api_key);
        }

        // Check license key as auth fallback
        $license = $request->get_header('X-OnCore-License');
        if ($license && $license === get_option('oncore_license_key', '')) {
            return !empty($license);
        }

        return false;
    }

    public function register_routes() {
        $ns = 'oncore/v1';
        $auth = function($req) { return $this->check_auth($req); };

        // ── Site Info (full snapshot for Claude context) ──
        register_rest_route($ns, '/site-info', [
            'methods' => 'GET',
            'callback' => [$this, 'get_site_info'],
            'permission_callback' => $auth,
        ]);

        // ── Pages ──
        register_rest_route($ns, '/pages', [
            'methods' => 'POST',
            'callback' => [$this, 'manage_page'],
            'permission_callback' => $auth,
        ]);

        // ── Posts ──
        register_rest_route($ns, '/posts', [
            'methods' => 'POST',
            'callback' => [$this, 'manage_post'],
            'permission_callback' => $auth,
        ]);

        // ── Media ──
        register_rest_route($ns, '/media', [
            'methods' => 'POST',
            'callback' => [$this, 'upload_media'],
            'permission_callback' => $auth,
        ]);

        // ── Theme / CSS ──
        register_rest_route($ns, '/theme', [
            'methods' => 'POST',
            'callback' => [$this, 'manage_theme'],
            'permission_callback' => $auth,
        ]);

        // ── Site Settings ──
        register_rest_route($ns, '/settings', [
            'methods' => 'POST',
            'callback' => [$this, 'manage_settings'],
            'permission_callback' => $auth,
        ]);

        // ── Menus ──
        register_rest_route($ns, '/menus', [
            'methods' => 'POST',
            'callback' => [$this, 'manage_menus'],
            'permission_callback' => $auth,
        ]);

        // ── Bulk Operations ──
        register_rest_route($ns, '/bulk', [
            'methods' => 'POST',
            'callback' => [$this, 'bulk_execute'],
            'permission_callback' => $auth,
        ]);

        // ── Natural Language Execute ──
        register_rest_route($ns, '/execute', [
            'methods' => 'POST',
            'callback' => [$this, 'nl_execute'],
            'permission_callback' => $auth,
        ]);

        // ── List All Content ──
        register_rest_route($ns, '/content', [
            'methods' => 'GET',
            'callback' => [$this, 'list_content'],
            'permission_callback' => $auth,
        ]);
    }

    /**
     * GET /site-info — Full site snapshot for Claude context
     */
    public function get_site_info() {
        $theme = wp_get_theme();
        $pages = get_pages(['sort_column' => 'menu_order', 'number' => 100]);
        $posts = get_posts(['numberposts' => 20, 'post_status' => 'any']);
        $menus = wp_get_nav_menus();

        return new WP_REST_Response([
            'site' => [
                'name' => get_bloginfo('name'),
                'description' => get_bloginfo('description'),
                'url' => home_url(),
                'admin_url' => admin_url(),
                'language' => get_bloginfo('language'),
                'timezone' => get_option('timezone_string', 'UTC'),
                'wp_version' => get_bloginfo('version'),
            ],
            'theme' => [
                'name' => $theme->get('Name'),
                'version' => $theme->get('Version'),
                'template' => $theme->get_template(),
                'supports_blocks' => current_theme_supports('editor-styles'),
            ],
            'oncore' => [
                'version' => ONCORE_VERSION,
                'license' => OnCore_License::get_license(),
                'tracking' => [
                    'pixel' => get_option('oncore_fb_pixel_id', '') ? true : false,
                    'ga4' => get_option('oncore_ga4_id', '') ? true : false,
                    'utm' => get_option('oncore_utm_tracking', '1') === '1',
                ],
                'crm' => [
                    'webhook' => !empty(get_option('oncore_crm_webhook', '')),
                    'api' => !empty(get_option('oncore_crm_pit', '')),
                ],
                'booking' => get_option('oncore_booking_business_id', ''),
                'business' => [
                    'name' => get_option('oncore_business_name', ''),
                    'phone' => get_option('oncore_business_phone', ''),
                    'email' => get_option('oncore_business_email', ''),
                    'address' => get_option('oncore_business_address', ''),
                ],
            ],
            'pages' => array_map(function($p) {
                return [
                    'id' => $p->ID, 'title' => $p->post_title,
                    'slug' => $p->post_name, 'status' => $p->post_status,
                    'url' => get_permalink($p->ID), 'parent' => $p->post_parent,
                    'template' => get_page_template_slug($p->ID),
                    'modified' => $p->post_modified,
                ];
            }, $pages),
            'posts' => array_map(function($p) {
                return [
                    'id' => $p->ID, 'title' => $p->post_title,
                    'slug' => $p->post_name, 'status' => $p->post_status,
                    'url' => get_permalink($p->ID),
                    'modified' => $p->post_modified,
                ];
            }, $posts),
            'menus' => array_map(function($m) {
                return ['id' => $m->term_id, 'name' => $m->name, 'slug' => $m->slug];
            }, $menus),
            'plugins' => array_keys(get_option('active_plugins', [])),
            'shortcodes' => [
                'oncore_form', 'oncore_booking', 'oncore_booking_list',
                'oncore_phone', 'oncore_cta', 'oncore_map',
            ],
        ]);
    }

    /**
     * POST /pages — Create or update a page
     */
    public function manage_page($request) {
        $params = $request->get_json_params();
        $action = $params['action'] ?? 'create';

        $post_data = [
            'post_type' => 'page',
            'post_title' => sanitize_text_field($params['title'] ?? ''),
            'post_content' => wp_kses_post($params['content'] ?? ''),
            'post_status' => sanitize_text_field($params['status'] ?? 'draft'),
            'post_name' => sanitize_title($params['slug'] ?? $params['title'] ?? ''),
        ];

        if (!empty($params['parent'])) $post_data['post_parent'] = intval($params['parent']);
        if (!empty($params['template'])) $post_data['page_template'] = sanitize_text_field($params['template']);
        if (!empty($params['menu_order'])) $post_data['menu_order'] = intval($params['menu_order']);

        if ($action === 'update' && !empty($params['id'])) {
            $post_data['ID'] = intval($params['id']);
            $id = wp_update_post($post_data, true);
        } else {
            $id = wp_insert_post($post_data, true);
        }

        if (is_wp_error($id)) {
            return new WP_REST_Response(['error' => $id->get_error_message()], 500);
        }

        // Handle meta/SEO
        if (!empty($params['meta_title'])) update_post_meta($id, '_yoast_wpseo_title', sanitize_text_field($params['meta_title']));
        if (!empty($params['meta_description'])) update_post_meta($id, '_yoast_wpseo_metadesc', sanitize_text_field($params['meta_description']));
        if (!empty($params['meta'])) {
            foreach ($params['meta'] as $key => $val) {
                update_post_meta($id, sanitize_key($key), sanitize_text_field($val));
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'id' => $id,
            'url' => get_permalink($id),
            'edit_url' => admin_url("post.php?post={$id}&action=edit"),
        ], $action === 'create' ? 201 : 200);
    }

    /**
     * POST /posts — Create or update a blog post
     */
    public function manage_post($request) {
        $params = $request->get_json_params();
        $action = $params['action'] ?? 'create';

        $post_data = [
            'post_type' => 'post',
            'post_title' => sanitize_text_field($params['title'] ?? ''),
            'post_content' => wp_kses_post($params['content'] ?? ''),
            'post_status' => sanitize_text_field($params['status'] ?? 'draft'),
            'post_name' => sanitize_title($params['slug'] ?? $params['title'] ?? ''),
            'post_excerpt' => sanitize_text_field($params['excerpt'] ?? ''),
        ];

        if ($action === 'update' && !empty($params['id'])) {
            $post_data['ID'] = intval($params['id']);
            $id = wp_update_post($post_data, true);
        } else {
            $id = wp_insert_post($post_data, true);
        }

        if (is_wp_error($id)) {
            return new WP_REST_Response(['error' => $id->get_error_message()], 500);
        }

        // Categories
        if (!empty($params['categories'])) {
            $cat_ids = [];
            foreach ((array)$params['categories'] as $cat) {
                $term = term_exists($cat, 'category');
                if (!$term) $term = wp_insert_term($cat, 'category');
                if (!is_wp_error($term)) $cat_ids[] = is_array($term) ? $term['term_id'] : $term;
            }
            if ($cat_ids) wp_set_post_categories($id, $cat_ids);
        }

        // Tags
        if (!empty($params['tags'])) {
            wp_set_post_tags($id, array_map('sanitize_text_field', (array)$params['tags']));
        }

        // SEO meta
        if (!empty($params['meta_title'])) update_post_meta($id, '_yoast_wpseo_title', sanitize_text_field($params['meta_title']));
        if (!empty($params['meta_description'])) update_post_meta($id, '_yoast_wpseo_metadesc', sanitize_text_field($params['meta_description']));

        return new WP_REST_Response([
            'success' => true,
            'id' => $id,
            'url' => get_permalink($id),
            'edit_url' => admin_url("post.php?post={$id}&action=edit"),
        ], $action === 'create' ? 201 : 200);
    }

    /**
     * POST /media — Upload media from URL (sideload)
     */
    public function upload_media($request) {
        $params = $request->get_json_params();
        $url = esc_url_raw($params['url'] ?? '');
        $title = sanitize_text_field($params['title'] ?? '');
        $alt = sanitize_text_field($params['alt'] ?? $title);

        if (empty($url)) {
            return new WP_REST_Response(['error' => 'URL required'], 400);
        }

        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $tmp = download_url($url, 30);
        if (is_wp_error($tmp)) {
            return new WP_REST_Response(['error' => $tmp->get_error_message()], 500);
        }

        $filename = basename(wp_parse_url($url, PHP_URL_PATH));
        if (empty($filename)) $filename = 'oncore-upload-' . time() . '.jpg';

        $file_array = ['name' => $filename, 'tmp_name' => $tmp];
        $attachment_id = media_handle_sideload($file_array, 0, $title);

        if (is_wp_error($attachment_id)) {
            @unlink($tmp);
            return new WP_REST_Response(['error' => $attachment_id->get_error_message()], 500);
        }

        if ($alt) update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt);

        return new WP_REST_Response([
            'success' => true,
            'id' => $attachment_id,
            'url' => wp_get_attachment_url($attachment_id),
            'sizes' => wp_get_attachment_image_src($attachment_id, 'full'),
        ], 201);
    }

    /**
     * POST /theme — Inject custom CSS, modify customizer settings
     */
    public function manage_theme($request) {
        $params = $request->get_json_params();
        $action = $params['action'] ?? 'add_css';

        switch ($action) {
            case 'add_css':
                $existing = get_option('oncore_custom_css', '');
                $new_css = wp_strip_all_tags($params['css'] ?? '');
                update_option('oncore_custom_css', $existing . "\n" . $new_css);
                // Also add to WP custom CSS
                $custom_css_post_id = wp_get_custom_css_post() ? wp_get_custom_css_post()->ID : 0;
                if ($custom_css_post_id) {
                    $current = get_post_field('post_content', $custom_css_post_id);
                    wp_update_post(['ID' => $custom_css_post_id, 'post_content' => $current . "\n/* 0nCore */\n" . $new_css]);
                } else {
                    wp_update_custom_css_post($new_css);
                }
                return new WP_REST_Response(['success' => true, 'action' => 'css_added']);

            case 'set_css':
                $css = wp_strip_all_tags($params['css'] ?? '');
                update_option('oncore_custom_css', $css);
                wp_update_custom_css_post($css);
                return new WP_REST_Response(['success' => true, 'action' => 'css_set']);

            case 'get_css':
                return new WP_REST_Response([
                    'css' => wp_get_custom_css(),
                    'oncore_css' => get_option('oncore_custom_css', ''),
                ]);

            default:
                return new WP_REST_Response(['error' => "Unknown theme action: {$action}"], 400);
        }
    }

    /**
     * POST /settings — Update WordPress settings
     */
    public function manage_settings($request) {
        $params = $request->get_json_params();
        $updated = [];

        $allowed = [
            'blogname', 'blogdescription', 'show_on_front', 'page_on_front',
            'page_for_posts', 'posts_per_page', 'permalink_structure',
        ];

        foreach ($params as $key => $value) {
            if (in_array($key, $allowed, true)) {
                update_option($key, sanitize_text_field($value));
                $updated[] = $key;
            }
        }

        // 0nCore settings
        $oncore_keys = array_filter(array_keys($params), fn($k) => str_starts_with($k, 'oncore_'));
        foreach ($oncore_keys as $key) {
            update_option(sanitize_key($key), sanitize_text_field($params[$key]));
            $updated[] = $key;
        }

        if (!empty($params['permalink_structure'])) flush_rewrite_rules();

        return new WP_REST_Response(['success' => true, 'updated' => $updated]);
    }

    /**
     * POST /menus — Create/update navigation menus
     */
    public function manage_menus($request) {
        $params = $request->get_json_params();
        $action = $params['action'] ?? 'create';

        switch ($action) {
            case 'create':
                $menu_id = wp_create_nav_menu(sanitize_text_field($params['name'] ?? 'Main Menu'));
                if (is_wp_error($menu_id)) {
                    return new WP_REST_Response(['error' => $menu_id->get_error_message()], 500);
                }

                // Add items
                if (!empty($params['items'])) {
                    foreach ($params['items'] as $i => $item) {
                        wp_update_nav_menu_item($menu_id, 0, [
                            'menu-item-title' => sanitize_text_field($item['title'] ?? ''),
                            'menu-item-url' => esc_url_raw($item['url'] ?? ''),
                            'menu-item-status' => 'publish',
                            'menu-item-position' => $i + 1,
                            'menu-item-type' => $item['type'] ?? 'custom',
                            'menu-item-object' => $item['object'] ?? '',
                            'menu-item-object-id' => intval($item['object_id'] ?? 0),
                        ]);
                    }
                }

                // Assign to location
                if (!empty($params['location'])) {
                    $locations = get_theme_mod('nav_menu_locations', []);
                    $locations[$params['location']] = $menu_id;
                    set_theme_mod('nav_menu_locations', $locations);
                }

                return new WP_REST_Response(['success' => true, 'menu_id' => $menu_id], 201);

            case 'list':
                $menus = wp_get_nav_menus();
                return new WP_REST_Response(array_map(function($m) {
                    $items = wp_get_nav_menu_items($m->term_id);
                    return [
                        'id' => $m->term_id,
                        'name' => $m->name,
                        'items' => array_map(fn($i) => ['id' => $i->ID, 'title' => $i->title, 'url' => $i->url], $items ?: []),
                    ];
                }, $menus));

            default:
                return new WP_REST_Response(['error' => "Unknown menu action: {$action}"], 400);
        }
    }

    /**
     * GET /content — List all pages and posts
     */
    public function list_content($request) {
        $type = $request->get_param('type') ?? 'all';
        $result = [];

        if ($type === 'all' || $type === 'pages') {
            $pages = get_pages(['number' => 200, 'post_status' => 'any']);
            $result['pages'] = array_map(fn($p) => [
                'id' => $p->ID, 'title' => $p->post_title, 'slug' => $p->post_name,
                'status' => $p->post_status, 'url' => get_permalink($p->ID),
                'content_length' => strlen($p->post_content),
            ], $pages);
        }

        if ($type === 'all' || $type === 'posts') {
            $posts = get_posts(['numberposts' => 200, 'post_status' => 'any']);
            $result['posts'] = array_map(fn($p) => [
                'id' => $p->ID, 'title' => $p->post_title, 'slug' => $p->post_name,
                'status' => $p->post_status, 'url' => get_permalink($p->ID),
            ], $posts);
        }

        return new WP_REST_Response($result);
    }

    /**
     * POST /bulk — Execute multiple operations in one request
     */
    public function bulk_execute($request) {
        $params = $request->get_json_params();
        $operations = $params['operations'] ?? [];
        $results = [];

        foreach ($operations as $i => $op) {
            $type = $op['type'] ?? '';
            $data = $op['data'] ?? [];

            switch ($type) {
                case 'page':
                    $sub_request = new WP_REST_Request('POST', '/oncore/v1/pages');
                    $sub_request->set_body(wp_json_encode($data));
                    $sub_request->set_header('Content-Type', 'application/json');
                    $results[] = ['op' => $i, 'type' => 'page', 'result' => $this->manage_page($sub_request)->get_data()];
                    break;
                case 'post':
                    $sub_request = new WP_REST_Request('POST', '/oncore/v1/posts');
                    $sub_request->set_body(wp_json_encode($data));
                    $sub_request->set_header('Content-Type', 'application/json');
                    $results[] = ['op' => $i, 'type' => 'post', 'result' => $this->manage_post($sub_request)->get_data()];
                    break;
                case 'media':
                    $sub_request = new WP_REST_Request('POST', '/oncore/v1/media');
                    $sub_request->set_body(wp_json_encode($data));
                    $sub_request->set_header('Content-Type', 'application/json');
                    $results[] = ['op' => $i, 'type' => 'media', 'result' => $this->upload_media($sub_request)->get_data()];
                    break;
                case 'setting':
                    $sub_request = new WP_REST_Request('POST', '/oncore/v1/settings');
                    $sub_request->set_body(wp_json_encode($data));
                    $sub_request->set_header('Content-Type', 'application/json');
                    $results[] = ['op' => $i, 'type' => 'setting', 'result' => $this->manage_settings($sub_request)->get_data()];
                    break;
                default:
                    $results[] = ['op' => $i, 'type' => $type, 'error' => 'Unknown operation type'];
            }
        }

        return new WP_REST_Response(['success' => true, 'results' => $results, 'total' => count($results)]);
    }

    /**
     * POST /execute — Natural language command → WordPress action
     * Claude describes what to do, this endpoint does it.
     */
    public function nl_execute($request) {
        $params = $request->get_json_params();
        $command = $params['command'] ?? '';

        // Simple command parser — no AI needed for structured commands
        $parts = explode(':', $command, 2);
        $action = strtolower(trim($parts[0]));
        $detail = trim($parts[1] ?? '');

        switch ($action) {
            case 'create page':
                return $this->manage_page(new WP_REST_Request('POST', '/oncore/v1/pages'));

            case 'set homepage':
                if (is_numeric($detail)) {
                    update_option('show_on_front', 'page');
                    update_option('page_on_front', intval($detail));
                    return new WP_REST_Response(['success' => true, 'homepage_id' => intval($detail)]);
                }
                break;

            case 'set site title':
                update_option('blogname', sanitize_text_field($detail));
                return new WP_REST_Response(['success' => true, 'title' => $detail]);

            case 'list pages':
                return $this->list_content(new WP_REST_Request('GET', '/oncore/v1/content'));

            case 'site info':
                return $this->get_site_info();
        }

        return new WP_REST_Response(['error' => "Unknown command: {$command}", 'hint' => 'Use structured API endpoints instead'], 400);
    }
}
