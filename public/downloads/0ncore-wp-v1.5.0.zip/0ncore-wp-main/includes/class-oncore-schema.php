<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore Schema.org — Auto-injects structured data based on settings
 */
class OnCore_Schema {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_head', [$this, 'inject_schema'], 10);
    }

    public function inject_schema() {
        $name = get_option('oncore_business_name', '');
        if (empty($name)) return;

        $type = get_option('oncore_schema_type', 'LocalBusiness');
        $phone = get_option('oncore_business_phone', '');
        $email = get_option('oncore_business_email', '');
        $address = get_option('oncore_business_address', '');
        $lat = get_option('oncore_business_lat', '');
        $lng = get_option('oncore_business_lng', '');

        $schema = [
            '@context' => 'https://schema.org',
            '@type' => $type,
            '@id' => home_url('/#business'),
            'name' => $name,
            'url' => home_url('/'),
        ];

        if ($phone) {
            $schema['telephone'] = $phone;
            $schema['contactPoint'] = [
                '@type' => 'ContactPoint',
                'telephone' => $phone,
                'contactType' => 'customer service',
            ];
        }
        if ($email) $schema['email'] = $email;
        if ($address) {
            // Parse "Street, City, State Zip" format
            $parts = array_map('trim', explode(',', $address));
            $schema['address'] = [
                '@type' => 'PostalAddress',
                'streetAddress' => $parts[0] ?? '',
                'addressLocality' => $parts[1] ?? '',
                'addressRegion' => trim(explode(' ', trim($parts[2] ?? ''))[0] ?? ''),
                'postalCode' => trim(explode(' ', trim($parts[2] ?? ''))[1] ?? ''),
                'addressCountry' => 'US',
            ];
        }
        if ($lat && $lng) {
            $schema['geo'] = [
                '@type' => 'GeoCoordinates',
                'latitude' => (float)$lat,
                'longitude' => (float)$lng,
            ];
        }

        echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>' . "\n";
    }
}
