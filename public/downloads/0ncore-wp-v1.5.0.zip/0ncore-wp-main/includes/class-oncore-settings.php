<?php
if (!defined('ABSPATH')) exit;

class OnCore_Settings {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_init', [$this, 'register_settings']);
        add_action('wp_ajax_oncore_save_settings', [$this, 'ajax_save']);
        add_action('wp_ajax_oncore_test_crm', [$this, 'ajax_test_crm']);
    }

    public function register_settings() {
        $fields = [
            'oncore_fb_pixel_id', 'oncore_ga4_id',
            'oncore_crm_webhook', 'oncore_crm_pit', 'oncore_crm_location_id',
            'oncore_booking_business_id',
            'oncore_business_name', 'oncore_business_phone', 'oncore_business_email',
            'oncore_business_address', 'oncore_business_lat', 'oncore_business_lng',
            'oncore_schema_type', 'oncore_utm_tracking', 'oncore_auto_crm_capture',
        ];
        foreach ($fields as $field) {
            register_setting('oncore_settings', $field, ['sanitize_callback' => 'sanitize_text_field']);
        }
    }

    public function ajax_save() {
        check_ajax_referer('oncore_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $fields = $_POST['settings'] ?? [];
        foreach ($fields as $key => $value) {
            if (strpos($key, 'oncore_') === 0) {
                update_option(sanitize_key($key), sanitize_text_field($value));
            }
        }
        wp_send_json_success(['message' => 'Settings saved']);
    }

    public function ajax_test_crm() {
        check_ajax_referer('oncore_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $pit = get_option('oncore_crm_pit', '');
        $location = get_option('oncore_crm_location_id', '');
        if (!$pit || !$location) {
            wp_send_json_error('PIT token and Location ID required');
        }

        $response = wp_remote_get("https://services.leadconnectorhq.com/locations/{$location}", [
            'headers' => [
                'Authorization' => "Bearer {$pit}",
                'Version' => '2021-07-28',
                'Accept' => 'application/json',
            ],
            'timeout' => 10,
        ]);

        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($body['location'])) {
            wp_send_json_success([
                'name' => $body['location']['name'] ?? 'Unknown',
                'email' => $body['location']['email'] ?? '',
                'phone' => $body['location']['phone'] ?? '',
            ]);
        } else {
            wp_send_json_error('Invalid CRM response — check PIT token');
        }
    }

    public static function get($key, $default = '') {
        return get_option("oncore_{$key}", $default);
    }
}
