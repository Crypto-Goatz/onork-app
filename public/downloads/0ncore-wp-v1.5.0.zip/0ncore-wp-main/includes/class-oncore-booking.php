<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore Booking — MassageBook integration + service data
 */
class OnCore_Booking {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {}

    /**
     * Get services by category
     */
    public static function get_services($category = 'facials') {
        $all = self::service_catalog();
        return $all[$category] ?? [];
    }

    /**
     * Full service catalog — extends via admin settings or filter
     */
    public static function service_catalog() {
        $catalog = [
            'facials' => [
                ['name' => 'Customized European Spa Facial', 'time' => '60 min', 'price' => '$85', 'id' => '219925', 'desc' => 'Deep cleanse, customized mask, vitamin C serum, moisture lock, and face/neck/shoulder massage.', 'popular' => true],
                ['name' => 'Revitalizing Vitamin C Facial', 'time' => '60 min', 'price' => '$95', 'id' => '219936', 'desc' => 'Brightens dull skin, reduces dark spots with medical-grade vitamin C.'],
                ['name' => 'Active Anti-Aging Facial', 'time' => '60 min', 'price' => '$105', 'id' => '219938', 'desc' => 'Peptide-infused treatment targeting fine lines and age spots.'],
                ['name' => 'Supreme Anti-Aging Facial', 'time' => '75 min', 'price' => '$125', 'id' => '219939', 'desc' => 'Most advanced anti-aging with collagen stimulation and lifting massage.'],
                ['name' => 'Hydrating Rehydra Facial', 'time' => '60 min', 'price' => '$90', 'id' => '219945', 'desc' => 'Intensive moisture therapy with hyaluronic acid infusion.'],
                ['name' => 'Anti-Acne Facial', 'time' => '60 min', 'price' => '$90', 'id' => '219940', 'desc' => 'Targeted treatment for breakouts with gentle extractions.'],
                ['name' => 'Digital Detox Facial', 'time' => '60 min', 'price' => '$90', 'id' => '219941', 'desc' => 'Repairs blue light and environmental damage.'],
                ['name' => 'Sensitive Skin Therapeutic', 'time' => '60 min', 'price' => '$85', 'id' => '219935', 'desc' => 'Calming treatment for reactive and sensitive skin.'],
                ['name' => 'Deep Clean Facial', 'time' => '30 min', 'price' => '$55', 'id' => '219947', 'desc' => 'Quick refresh for busy schedules.'],
                ['name' => '90-Minute Specialty Facial', 'time' => '90 min', 'price' => '$145', 'id' => '219942', 'desc' => 'Extended luxury treatment — our most indulgent experience.'],
                ['name' => 'Illuminating Facial', 'time' => '60 min', 'price' => '$95', 'id' => '219944', 'desc' => 'Targets hyperpigmentation for even, luminous skin.'],
                ['name' => 'Enzymatic Peel', 'time' => '45 min', 'price' => '$75', 'id' => '219943', 'desc' => 'Gentle chemical exfoliation to resurface and refine pores.'],
            ],
            'massage' => [
                ['name' => 'Classic Swedish Massage', 'time' => '60 min', 'price' => '$85', 'id' => '219950', 'desc' => 'Relaxing full-body massage with long flowing strokes.', 'popular' => true],
                ['name' => 'Signature Combination', 'time' => '60 min', 'price' => '$95', 'id' => '219951', 'desc' => 'Custom blend of techniques for your specific needs.'],
                ['name' => 'Aromatherapy Massage', 'time' => '60 min', 'price' => '$95', 'id' => '219952', 'desc' => 'Essential oils enhance this deeply relaxing massage.'],
                ['name' => 'Hot Stone Massage', 'time' => '60 min', 'price' => '$110', 'id' => '219953', 'desc' => 'Heated basalt stones melt tension and stress.'],
                ['name' => 'Therapeutic Deep Tissue', 'time' => '60 min', 'price' => '$100', 'id' => '219954', 'desc' => 'Targeted pressure for chronic pain and tension.'],
                ['name' => 'Maternity Massage', 'time' => '60 min', 'price' => '$85', 'id' => '219955', 'desc' => 'Safe, nurturing massage for expecting mothers.'],
                ['name' => 'Thai Reflexology', 'time' => '30 min', 'price' => '$50', 'id' => '219956', 'desc' => 'Traditional foot reflexology techniques.'],
            ],
        ];

        return apply_filters('oncore_service_catalog', $catalog);
    }

    /**
     * Get booking URL for a service
     */
    public static function get_url($service_id) {
        $business_id = get_option('oncore_booking_business_id', '1554118');
        return "https://www.massagebook.com/business/{$business_id}/booking/select-add-ons?service_id={$service_id}";
    }
}
