<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore Shortcodes
 *
 * [oncore_form]              — Lead capture form → CRM
 * [oncore_booking]           — MassageBook booking button/embed
 * [oncore_booking_list]      — Full service booking menu
 * [oncore_phone]             — Click-to-call with tracking
 * [oncore_cta]               — Call-to-action block
 * [oncore_reviews]           — Review cards
 * [oncore_hours]             — Business hours
 * [oncore_map]               — Google Maps embed
 * [oncore_tracking_event]    — Fire custom tracking events
 */
class OnCore_Shortcodes {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_shortcode('oncore_form', [$this, 'form']);
        add_shortcode('oncore_booking', [$this, 'booking']);
        add_shortcode('oncore_booking_list', [$this, 'booking_list']);
        add_shortcode('oncore_phone', [$this, 'phone']);
        add_shortcode('oncore_cta', [$this, 'cta']);
        add_shortcode('oncore_map', [$this, 'map']);
    }

    public function form($atts) {
        return OnCore_Forms::render($atts);
    }

    public function booking($atts) {
        $a = shortcode_atts([
            'service_id' => '219925',
            'label' => 'Book Now',
            'style' => 'button',
        ], $atts);

        $business_id = get_option('oncore_booking_business_id', '1554118');
        $url = "https://www.massagebook.com/business/{$business_id}/booking/select-add-ons?service_id={$a['service_id']}";

        return sprintf(
            '<a href="%s" target="_blank" class="oncore-booking-btn" onclick="oncore_track_booking(\'%s\')">%s</a>',
            esc_url($url),
            esc_attr($a['service_id']),
            esc_html($a['label'])
        );
    }

    public function booking_list($atts) {
        $a = shortcode_atts(['category' => 'facials'], $atts);
        $business_id = get_option('oncore_booking_business_id', '1554118');
        $services = OnCore_Booking::get_services($a['category']);

        ob_start();
        echo '<div class="oncore-booking-grid">';
        foreach ($services as $s) {
            $url = "https://www.massagebook.com/business/{$business_id}/booking/select-add-ons?service_id={$s['id']}";
            printf(
                '<div class="oncore-service-card%s">
                    %s
                    <div class="oncore-service-top"><span class="oncore-service-name">%s</span><span class="oncore-service-price">%s<br><small>%s</small></span></div>
                    <p class="oncore-service-desc">%s</p>
                    <a href="%s" target="_blank" class="oncore-service-book" onclick="oncore_track_booking(\'%s\')">Book This</a>
                </div>',
                !empty($s['popular']) ? ' oncore-popular' : '',
                !empty($s['popular']) ? '<span class="oncore-popular-badge">Most Popular</span>' : '',
                esc_html($s['name']),
                esc_html($s['price']),
                esc_html($s['time']),
                esc_html($s['desc']),
                esc_url($url),
                esc_attr($s['id'])
            );
        }
        echo '</div>';
        return ob_get_clean();
    }

    public function phone($atts) {
        $a = shortcode_atts(['label' => ''], $atts);
        $phone = get_option('oncore_business_phone', '');
        if (empty($phone)) return '';
        $label = $a['label'] ?: $phone;
        return sprintf(
            '<a href="tel:%s" class="oncore-phone" onclick="oncore_track_call()">%s</a>',
            esc_attr(preg_replace('/[^+0-9]/', '', $phone)),
            esc_html($label)
        );
    }

    public function cta($atts, $content = '') {
        $a = shortcode_atts([
            'title' => 'Ready to Get Started?',
            'button' => 'Book Now',
            'url' => '#',
            'service_id' => '219925',
            'style' => 'dark',
        ], $atts);

        $business_id = get_option('oncore_booking_business_id', '1554118');
        if ($a['url'] === '#') {
            $a['url'] = "https://www.massagebook.com/business/{$business_id}/booking/select-add-ons?service_id={$a['service_id']}";
        }

        return sprintf(
            '<div class="oncore-cta oncore-cta-%s"><h2>%s</h2>%s<a href="%s" target="_blank" class="oncore-cta-btn" onclick="oncore_track_booking(\'cta\')">%s</a></div>',
            esc_attr($a['style']),
            esc_html($a['title']),
            $content ? '<p>' . wp_kses_post($content) . '</p>' : '',
            esc_url($a['url']),
            esc_html($a['button'])
        );
    }

    public function map($atts) {
        $address = get_option('oncore_business_address', '');
        if (empty($address)) return '';
        $encoded = urlencode($address);
        return "<div class='oncore-map'><iframe src='https://www.google.com/maps?q={$encoded}&output=embed' width='100%' height='300' style='border:0;border-radius:12px;' allowfullscreen loading='lazy'></iframe></div>";
    }
}
