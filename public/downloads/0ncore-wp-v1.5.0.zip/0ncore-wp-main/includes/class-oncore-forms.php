<?php
if (!defined('ABSPATH')) exit;

/**
 * 0nCore Forms — Lead capture forms that auto-submit to CRM
 * Shortcode: [oncore_form] with customizable fields
 */
class OnCore_Forms {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_ajax_oncore_form_submit', [$this, 'handle_submit']);
        add_action('wp_ajax_nopriv_oncore_form_submit', [$this, 'handle_submit']);
    }

    /**
     * Handle form submission via AJAX
     */
    public function handle_submit() {
        check_ajax_referer('oncore_public_nonce', 'nonce');

        $data = [
            'firstName' => sanitize_text_field($_POST['firstName'] ?? ''),
            'lastName' => sanitize_text_field($_POST['lastName'] ?? ''),
            'email' => sanitize_email($_POST['email'] ?? ''),
            'phone' => sanitize_text_field($_POST['phone'] ?? ''),
            'service' => sanitize_text_field($_POST['service'] ?? ''),
            'skinConcern' => sanitize_text_field($_POST['skinConcern'] ?? ''),
            'message' => sanitize_textarea_field($_POST['message'] ?? ''),
            'tags' => array_filter(array_map('sanitize_text_field', explode(',', $_POST['tags'] ?? 'website-lead,0ncore'))),
            'source' => sanitize_text_field($_POST['source'] ?? 'website'),
        ];

        if (empty($data['firstName']) || empty($data['email'])) {
            wp_send_json_error('Name and email are required');
        }

        $crm = OnCore_CRM::instance();

        // Try webhook first (simpler, no PIT needed)
        $webhook = get_option('oncore_crm_webhook', '');
        if (!empty($webhook)) {
            $result = $crm->webhook_submit($data);
            wp_send_json_success(['method' => 'webhook', 'ok' => $result]);
        }

        // Fall back to direct API
        $pit = get_option('oncore_crm_pit', '');
        if (!empty($pit)) {
            $result = $crm->upsert_contact($data);
            if (is_wp_error($result)) {
                wp_send_json_error($result->get_error_message());
            }
            wp_send_json_success(['method' => 'api', 'contact' => $result]);
        }

        // No CRM configured — just log
        wp_send_json_success(['method' => 'none', 'message' => 'Form received (no CRM configured)']);
    }

    /**
     * Render a form (used by shortcode)
     */
    public static function render($atts = []) {
        $a = shortcode_atts([
            'title' => 'Get In Touch',
            'subtitle' => "We'll get back to you within 24 hours.",
            'button' => 'Send Message',
            'tags' => 'website-lead,0ncore',
            'service' => '',
            'fields' => 'name,email,phone,message',
            'style' => 'card',
            'success' => 'Thank you! We\'ll be in touch shortly.',
        ], $atts);

        $fields = array_map('trim', explode(',', $a['fields']));
        $form_id = 'oncore-form-' . wp_rand(1000, 9999);

        ob_start();
        ?>
        <div class="oncore-form-wrap oncore-form-<?php echo esc_attr($a['style']); ?>" id="<?php echo esc_attr($form_id); ?>-wrap">
            <?php if ($a['style'] === 'card'): ?>
            <div class="oncore-form-header">
                <h3><?php echo esc_html($a['title']); ?></h3>
                <p><?php echo esc_html($a['subtitle']); ?></p>
            </div>
            <?php endif; ?>
            <form class="oncore-form" id="<?php echo esc_attr($form_id); ?>"
                  data-tags="<?php echo esc_attr($a['tags']); ?>"
                  data-service="<?php echo esc_attr($a['service']); ?>"
                  data-success="<?php echo esc_attr($a['success']); ?>">
                <?php if (in_array('name', $fields)): ?>
                <div class="oncore-field oncore-field-row">
                    <div class="oncore-field-half">
                        <label>First Name *</label>
                        <input type="text" name="firstName" required placeholder="First name">
                    </div>
                    <div class="oncore-field-half">
                        <label>Last Name</label>
                        <input type="text" name="lastName" placeholder="Last name">
                    </div>
                </div>
                <?php endif; ?>
                <?php if (in_array('email', $fields)): ?>
                <div class="oncore-field">
                    <label>Email *</label>
                    <input type="email" name="email" required placeholder="you@example.com">
                </div>
                <?php endif; ?>
                <?php if (in_array('phone', $fields)): ?>
                <div class="oncore-field">
                    <label>Phone</label>
                    <input type="tel" name="phone" placeholder="(555) 123-4567">
                </div>
                <?php endif; ?>
                <?php if (in_array('service', $fields)): ?>
                <div class="oncore-field">
                    <label>Service Interest</label>
                    <input type="text" name="service" placeholder="What service are you interested in?" value="<?php echo esc_attr($a['service']); ?>">
                </div>
                <?php endif; ?>
                <?php if (in_array('skin', $fields)): ?>
                <div class="oncore-field">
                    <label>Primary Skin Concern</label>
                    <select name="skinConcern">
                        <option value="">Select...</option>
                        <option value="aging">Fine lines & aging</option>
                        <option value="acne">Acne & breakouts</option>
                        <option value="dryness">Dryness & dehydration</option>
                        <option value="dullness">Dullness & uneven tone</option>
                        <option value="sensitivity">Sensitivity & redness</option>
                        <option value="pigmentation">Dark spots</option>
                        <option value="general">General maintenance</option>
                    </select>
                </div>
                <?php endif; ?>
                <?php if (in_array('message', $fields)): ?>
                <div class="oncore-field">
                    <label>Message</label>
                    <textarea name="message" rows="3" placeholder="How can we help?"></textarea>
                </div>
                <?php endif; ?>
                <button type="submit" class="oncore-submit"><?php echo esc_html($a['button']); ?></button>
                <p class="oncore-privacy">We respect your privacy. No spam, ever.</p>
            </form>
            <div class="oncore-form-success" style="display:none">
                <div class="oncore-check">&#10003;</div>
                <h3><?php echo esc_html(explode('!', $a['success'])[0]); ?>!</h3>
                <p><?php echo esc_html($a['success']); ?></p>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
