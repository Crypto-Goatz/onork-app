<?php
/**
 * 0nCore Theme Functions
 * Minimal — FSE handles most rendering. This file:
 * - Registers block patterns
 * - Enqueues Google Fonts (Inter)
 * - Adds theme support
 */

if (!defined('ABSPATH')) exit;

define('ONCORE_THEME_VERSION', '1.0.0');

// Theme support
add_action('after_setup_theme', function() {
    add_theme_support('wp-block-styles');
    add_theme_support('editor-styles');
    add_theme_support('responsive-embeds');
});

// Enqueue Google Fonts
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style(
        'oncore-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap',
        [],
        null
    );
    wp_enqueue_style('oncore-custom', get_template_directory_uri() . '/assets/css/custom.css', [], ONCORE_THEME_VERSION);
});

// Editor fonts
add_action('enqueue_block_editor_assets', function() {
    wp_enqueue_style(
        'oncore-editor-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap',
        [],
        null
    );
});

// Register block patterns
add_action('init', function() {
    register_block_pattern_category('oncore', ['label' => '0nCore']);
});
