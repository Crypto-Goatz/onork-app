// 0nLink popup.js
(async () => {
  const $ = (id) => document.getElementById(id);
  const setStatus = (msg, err) => { $('status-msg').textContent = msg; $('status-msg').className = err ? 'error' : ''; };

  // Check if we're on LinkedIn
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const onLinkedIn = tab?.url?.includes('linkedin.com');

  if (onLinkedIn) {
    $('on-linkedin').style.display = 'block';
    $('not-linkedin').style.display = 'none';
    $('conn-dot').classList.add('on');
    $('conn-text').textContent = 'Active on LinkedIn';
  } else {
    $('on-linkedin').style.display = 'none';
    $('not-linkedin').style.display = 'block';
    $('conn-text').textContent = 'Not on LinkedIn';
  }

  // Load analytics
  chrome.storage.local.get({ analytics: { totalGenerated: 0, totalCopied: 0, totalPosted: 0 } }, (r) => {
    const a = r.analytics;
    $('s-gen').textContent = a.totalGenerated || 0;
    $('s-copied').textContent = a.totalCopied || 0;
    $('s-posted').textContent = a.totalPosted || 0;
  });

  // Button handlers
  function sendMsg(action) {
    if (!tab?.id) return;
    chrome.tabs.sendMessage(tab.id, { action }, (r) => {
      if (chrome.runtime.lastError) setStatus('Extension loading — refresh LinkedIn', true);
    });
    window.close();
  }

  $('btn-open')?.addEventListener('click', () => sendMsg('openModal'));
  $('btn-snip')?.addEventListener('click', () => sendMsg('startSnip'));
  $('btn-create')?.addEventListener('click', () => sendMsg('openCreate'));
  $('btn-settings')?.addEventListener('click', () => chrome.runtime.openOptionsPage());
  $('footer-settings')?.addEventListener('click', () => chrome.runtime.openOptionsPage());
  $('btn-goto-li')?.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://www.linkedin.com/feed/' });
    window.close();
  });
})();
