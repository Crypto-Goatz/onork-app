// =============================================================================
// ROCKETLINK v3.0 - SETTINGS PAGE
// =============================================================================

const defaults = {
  apiMode: 'anthropic',
  anthropicApiKey: '',
  webhookUrl: '',
  lunarCrushApiKey: '',
  model: 'claude-sonnet-4-20250514',
  linkedInClientId: '',
  linkedInClientSecret: '',
  linkedIn: { connected: false, profile: null },
  activeProfile: 'rocketopp',
  profiles: {
    rocketopp: {
      name: 'RocketOpp Default',
      systemPrompt: `You are Mike Mento's LinkedIn assistant for RocketOpp (0nLink). Generate strategic comments and posts that position RocketOpp as builders (not gurus) and drive qualified leads to the Rocket+ beta community.

BRAND VOICE:
- Aggressive but data-backed
- Anti-guru positioning: "We BUILD, we don't just teach"
- Direct, no-BS, urgent
- Builder credibility - reference beta testing, 7 apps in development

CORE STATS (use naturally from the stats library):
{{STATS}}

PRODUCTS/SERVICES (mention when relevant):
{{PRODUCTS}}

RESPONSE RULES:
1. Never drop links in comments
2. Never sound salesy - be a builder sharing insights
3. Always validate before pivoting ("Good point, but...")
4. Keep under 250 words for comments, 300 for posts
5. Use line breaks for scannability
6. End with engagement hook (question or curiosity)
7. Include relevant hashtags at the end (3-5 max)

GROUP URL (for DMs only): https://www.linkedin.com/groups/16354077/`,
      groupUrl: 'https://www.linkedin.com/groups/16354077/'
    }
  },
  ui: { autoAnalyze: true, showStats: true, autoHashtags: true }
};

// Tab switching
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active');
  });
});

// Toggle buttons
document.querySelectorAll('.toggle').forEach(toggle => {
  toggle.addEventListener('click', () => toggle.classList.toggle('active'));
});

// Load settings
async function loadSettings() {
  const result = await chrome.storage.local.get(defaults);
  
  // API tab
  document.getElementById('anthropic-key').value = result.anthropicApiKey || '';
  document.getElementById('model').value = result.model || 'claude-sonnet-4-20250514';
  document.getElementById('webhook-url').value = result.webhookUrl || '';
  document.getElementById('api-mode').value = result.apiMode || 'anthropic';
  document.getElementById('lunarcrush-key').value = result.lunarCrushApiKey || '';
  document.getElementById('gemini-key').value = result.geminiApiKey || '';
  document.getElementById('gemini-model').value = result.geminiModel || 'gemini-2.5-flash-image';
  
  // LinkedIn tab
  document.getElementById('linkedin-client-id').value = result.linkedInClientId || '';
  document.getElementById('linkedin-client-secret').value = result.linkedInClientSecret || '';
  updateLinkedInStatus(result.linkedIn);
  
  // Profile tab
  const profile = result.profiles?.[result.activeProfile] || defaults.profiles.rocketopp;
  document.getElementById('profile-name').value = profile.name || '';
  document.getElementById('system-prompt').value = profile.systemPrompt || '';
  document.getElementById('group-url').value = profile.groupUrl || '';
  
  // Preferences
  document.getElementById('toggle-auto-analyze').classList.toggle('active', result.ui?.autoAnalyze !== false);
  document.getElementById('toggle-show-stats').classList.toggle('active', result.ui?.showStats !== false);
  document.getElementById('toggle-auto-hashtags').classList.toggle('active', result.ui?.autoHashtags !== false);
  
  // Load GHL settings
  loadGHLSettings();
}

function updateLinkedInStatus(linkedIn) {
  const nameEl = document.getElementById('linkedin-name');
  const emailEl = document.getElementById('linkedin-email');
  const connectBtn = document.getElementById('connect-linkedin');
  const disconnectBtn = document.getElementById('disconnect-linkedin');
  
  if (linkedIn?.connected && linkedIn?.profile) {
    nameEl.textContent = linkedIn.profile.name || 'Connected';
    emailEl.textContent = linkedIn.profile.email || '';
    emailEl.className = 'linkedin-connected';
    emailEl.textContent = '✓ Connected';
    connectBtn.style.display = 'none';
    disconnectBtn.style.display = 'inline-flex';
  } else {
    nameEl.textContent = 'Not Connected';
    emailEl.className = 'linkedin-disconnected';
    emailEl.textContent = 'Connect to post directly to LinkedIn';
    connectBtn.style.display = 'inline-flex';
    disconnectBtn.style.display = 'none';
  }
}

function showStatus(elementId, message, isError = false) {
  const el = document.getElementById(elementId);
  if (!el) return;
  el.innerHTML = `<div class="status ${isError ? 'error' : 'success'}">${message}</div>`;
  setTimeout(() => el.innerHTML = '', 5000);
}

// Save API settings
document.getElementById('save-api').addEventListener('click', async () => {
  await chrome.storage.local.set({
    anthropicApiKey: document.getElementById('anthropic-key').value.trim(),
    model: document.getElementById('model').value,
    webhookUrl: document.getElementById('webhook-url').value.trim(),
    apiMode: document.getElementById('api-mode').value,
    lunarCrushApiKey: document.getElementById('lunarcrush-key').value.trim(),
    geminiApiKey: document.getElementById('gemini-key').value.trim(),
    geminiModel: document.getElementById('gemini-model').value
  });
  showStatus('api-status', '✓ API settings saved!');
});

// Test Gemini
document.getElementById('test-gemini').addEventListener('click', async () => {
  const key = document.getElementById('gemini-key').value.trim();
  if (!key) {
    showStatus('api-status', '✗ Enter a Gemini API key first', true);
    return;
  }
  
  try {
    showStatus('api-status', '🔄 Testing Gemini connection...');
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent`,
      {
        method: 'POST',
        headers: {
          'x-goog-api-key': key,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: 'Describe a sunset in one word.' }] }]
        })
      }
    );
    
    if (response.ok) {
      showStatus('api-status', '✓ Gemini connection successful!');
    } else {
      const error = await response.json();
      showStatus('api-status', `✗ Gemini error: ${error.error?.message || 'Unknown error'}`, true);
    }
  } catch (e) {
    showStatus('api-status', `✗ Connection failed: ${e.message}`, true);
  }
});

// Test Anthropic
document.getElementById('test-anthropic').addEventListener('click', async () => {
  const key = document.getElementById('anthropic-key').value.trim();
  if (!key) {
    showStatus('api-status', '✗ Enter an API key first', true);
    return;
  }
  
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: document.getElementById('model').value,
        max_tokens: 50,
        messages: [{ role: 'user', content: 'Say "0nLink connected!" in exactly those words.' }]
      })
    });
    
    if (response.ok) {
      const data = await response.json();
      showStatus('api-status', `✓ Connected! Response: ${data.content[0].text}`);
    } else {
      const error = await response.json();
      showStatus('api-status', `✗ Error: ${error.error?.message || response.status}`, true);
    }
  } catch (e) {
    showStatus('api-status', `✗ Connection failed: ${e.message}`, true);
  }
});

// Save LinkedIn settings
document.getElementById('save-linkedin').addEventListener('click', async () => {
  await chrome.storage.local.set({
    linkedInClientId: document.getElementById('linkedin-client-id').value.trim(),
    linkedInClientSecret: document.getElementById('linkedin-client-secret').value.trim()
  });
  showStatus('api-status', '✓ LinkedIn credentials saved!');
});

// Connect LinkedIn (placeholder - actual OAuth needs more setup)
document.getElementById('connect-linkedin').addEventListener('click', () => {
  alert('LinkedIn OAuth requires a registered LinkedIn Developer App.\n\n1. Create an app at linkedin.com/developers\n2. Add your Client ID and Secret above\n3. The OAuth flow will be enabled\n\nFor now, use copy/paste to share generated posts.');
});

// Disconnect LinkedIn
document.getElementById('disconnect-linkedin').addEventListener('click', async () => {
  await chrome.storage.local.set({
    linkedIn: { connected: false, accessToken: '', refreshToken: '', profile: null }
  });
  updateLinkedInStatus({ connected: false });
});

// =============================================================================
// GOHIGHLEVEL INTEGRATION
// =============================================================================

// GHL defaults - Pre-configured for RocketOpp
const ghlDefaults = {
  privateToken: 'pit-beb322c7-c0f6-4a57-829f-17b5e6264339',
  locationId: '6MSqx0trfxgLxeHBJE1k',
  linkedinAccountId: '',
  linkedinAccountName: '',
  connected: false
};

// Load GHL settings
async function loadGHLSettings() {
  const result = await chrome.storage.local.get(['ghlSettings']);
  const settings = result.ghlSettings || ghlDefaults;
  
  document.getElementById('ghl-private-token').value = settings.privateToken || '';
  document.getElementById('ghl-location-id').value = settings.locationId || '';
  
  updateGHLStatus(settings);
  
  if (settings.connected && settings.linkedinAccountId) {
    const select = document.getElementById('ghl-linkedin-account');
    select.innerHTML = `<option value="${settings.linkedinAccountId}">${settings.linkedinAccountName || 'LinkedIn Account'}</option>`;
  }
}

// Update GHL connection status display
function updateGHLStatus(settings) {
  const nameEl = document.getElementById('ghl-connection-name');
  const detailEl = document.getElementById('ghl-connection-detail');
  
  if (settings.connected) {
    nameEl.textContent = 'Connected ✓';
    nameEl.style.color = '#10B981';
    detailEl.textContent = settings.linkedinAccountName 
      ? `LinkedIn: ${settings.linkedinAccountName}` 
      : 'Select a LinkedIn account below';
    detailEl.className = 'linkedin-connected';
  } else {
    nameEl.textContent = 'Not Connected';
    nameEl.style.color = '#e0e0e6';
    detailEl.textContent = 'Enter your GHL credentials below';
    detailEl.className = 'linkedin-disconnected';
  }
}

// Test GHL connection
document.getElementById('ghl-test-connection').addEventListener('click', async () => {
  const token = document.getElementById('ghl-private-token').value.trim();
  const locationId = document.getElementById('ghl-location-id').value.trim();
  
  if (!token || !locationId) {
    showStatus('ghl-test-status', '✗ Enter both token and location ID', true);
    return;
  }
  
  showStatus('ghl-test-status', '⏳ Testing connection...');
  
  try {
    const response = await fetch(
      `https://services.leadconnectorhq.com/social-media-posting/${locationId}/accounts`,
      {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Version': '2021-07-28'
        }
      }
    );
    
    if (response.ok) {
      const data = await response.json();
      const accounts = data.accounts || data || [];
      
      // Find LinkedIn accounts
      const linkedinAccounts = accounts.filter(acc => 
        acc.platform === 'linkedin' || 
        acc.type === 'linkedin' ||
        (acc.name && acc.name.toLowerCase().includes('linkedin'))
      );
      
      // Update account dropdown
      const select = document.getElementById('ghl-linkedin-account');
      select.innerHTML = '<option value="">-- Select LinkedIn Account --</option>';
      
      if (linkedinAccounts.length > 0) {
        linkedinAccounts.forEach(acc => {
          const option = document.createElement('option');
          option.value = acc.id || acc._id;
          option.textContent = acc.name || acc.accountName || 'LinkedIn Account';
          select.appendChild(option);
        });
        showStatus('ghl-test-status', `✓ Connected! Found ${linkedinAccounts.length} LinkedIn account(s)`);
      } else {
        showStatus('ghl-test-status', `✓ Connected but no LinkedIn accounts found. Total accounts: ${accounts.length}. Connect LinkedIn in GHL Social Planner first.`);
      }
      
      // Save as connected
      await chrome.storage.local.set({
        ghlSettings: {
          privateToken: token,
          locationId: locationId,
          linkedinAccountId: '',
          linkedinAccountName: '',
          connected: true
        }
      });
      
      updateGHLStatus({ connected: true });
      
    } else {
      const error = await response.json().catch(() => ({}));
      showStatus('ghl-test-status', `✗ Error: ${error.message || response.status} - Check your token and location ID`, true);
      
      await chrome.storage.local.set({
        ghlSettings: { ...ghlDefaults, privateToken: token, locationId: locationId, connected: false }
      });
      updateGHLStatus({ connected: false });
    }
  } catch (e) {
    showStatus('ghl-test-status', `✗ Connection failed: ${e.message}`, true);
  }
});

// Save GHL settings
document.getElementById('ghl-save-settings').addEventListener('click', async () => {
  const token = document.getElementById('ghl-private-token').value.trim();
  const locationId = document.getElementById('ghl-location-id').value.trim();
  const select = document.getElementById('ghl-linkedin-account');
  const linkedinAccountId = select.value;
  const linkedinAccountName = select.options[select.selectedIndex]?.text || '';
  
  const result = await chrome.storage.local.get(['ghlSettings']);
  const current = result.ghlSettings || ghlDefaults;
  
  await chrome.storage.local.set({
    ghlSettings: {
      privateToken: token,
      locationId: locationId,
      linkedinAccountId: linkedinAccountId || current.linkedinAccountId,
      linkedinAccountName: linkedinAccountName || current.linkedinAccountName,
      connected: current.connected
    }
  });
  
  showStatus('ghl-test-status', '✓ GHL settings saved!');
});

// Refresh accounts
document.getElementById('ghl-refresh-accounts').addEventListener('click', () => {
  document.getElementById('ghl-test-connection').click();
});

// LinkedIn account selection change
document.getElementById('ghl-linkedin-account').addEventListener('change', async (e) => {
  const select = e.target;
  const accountId = select.value;
  const accountName = select.options[select.selectedIndex]?.text || '';
  
  if (accountId) {
    const result = await chrome.storage.local.get(['ghlSettings']);
    const settings = result.ghlSettings || ghlDefaults;
    
    await chrome.storage.local.set({
      ghlSettings: {
        ...settings,
        linkedinAccountId: accountId,
        linkedinAccountName: accountName
      }
    });
    
    showStatus('ghl-accounts-status', `✓ Selected: ${accountName}`);
    updateGHLStatus({ ...settings, linkedinAccountName: accountName, connected: true });
  }
});

// =============================================================================
// END GOHIGHLEVEL
// =============================================================================

// Save Profile
document.getElementById('save-profile').addEventListener('click', async () => {
  const result = await chrome.storage.local.get(['profiles', 'activeProfile']);
  const profiles = result.profiles || defaults.profiles;
  const activeProfile = result.activeProfile || 'rocketopp';
  
  profiles[activeProfile] = {
    name: document.getElementById('profile-name').value.trim(),
    systemPrompt: document.getElementById('system-prompt').value.trim(),
    groupUrl: document.getElementById('group-url').value.trim()
  };
  
  await chrome.storage.local.set({ profiles });
  alert('Profile saved!');
});

// Reset Profile
document.getElementById('reset-profile').addEventListener('click', async () => {
  if (!confirm('Reset to default RocketOpp profile?')) return;
  
  const result = await chrome.storage.local.get(['profiles']);
  const profiles = result.profiles || {};
  profiles.rocketopp = defaults.profiles.rocketopp;
  
  await chrome.storage.local.set({ profiles, activeProfile: 'rocketopp' });
  
  document.getElementById('profile-name').value = defaults.profiles.rocketopp.name;
  document.getElementById('system-prompt').value = defaults.profiles.rocketopp.systemPrompt;
  document.getElementById('group-url').value = defaults.profiles.rocketopp.groupUrl;
  
  alert('Profile reset to default!');
});

// Export data
document.getElementById('export-data').addEventListener('click', async () => {
  const data = await chrome.storage.local.get(null);
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `rocketlink-backup-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
});

// Import data
document.getElementById('import-data').addEventListener('click', () => {
  document.getElementById('import-file').click();
});

document.getElementById('import-file').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    await chrome.storage.local.set(data);
    alert('Data imported! Refreshing...');
    loadSettings();
  } catch (err) {
    alert('Error importing data: ' + err.message);
  }
});

// Reset all
document.getElementById('reset-all').addEventListener('click', async () => {
  if (!confirm('⚠️ This will delete ALL your data, settings, and history.\n\nAre you sure?')) return;
  if (!confirm('FINAL WARNING: This cannot be undone. Continue?')) return;
  
  await chrome.storage.local.clear();
  alert('All data cleared. Refreshing...');
  loadSettings();
});

// Initialize
loadSettings();
