// =============================================================================
// 0nLink v1.0 — LinkedIn AI Growth Engine
// Content Script — Shadow DOM Injection + SPA Navigation Handling
// =============================================================================

(function () {
  'use strict';

  let fabCreated = false;
  let navObserver = null;

  function createFAB() {
    if (fabCreated || document.getElementById('onlink-fab')) return;

    const fab = document.createElement('div');
    fab.id = 'onlink-fab';

    // Shadow DOM so LinkedIn CSS can't touch us
    const shadow = fab.attachShadow({ mode: 'open' });
    shadow.innerHTML = `
      <style>
        :host { position: fixed; bottom: 28px; right: 28px; z-index: 2147483647; }
        button {
          width: 52px; height: 52px;
          background: linear-gradient(135deg, #00ff88 0%, #00cc66 100%);
          border: none; border-radius: 50%;
          cursor: pointer;
          box-shadow: 0 4px 24px rgba(0, 255, 136, 0.45), 0 2px 8px rgba(0,0,0,0.4);
          display: flex; align-items: center; justify-content: center;
          transition: all 0.2s cubic-bezier(0.4,0,0.2,1);
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }
        button:hover { transform: scale(1.1); box-shadow: 0 6px 32px rgba(0,255,136,0.6), 0 2px 8px rgba(0,0,0,0.4); }
        svg { width: 26px; height: 26px; }
      </style>
      <button title="Open 0nLink">
        <svg viewBox="0 0 32 32" fill="none">
          <circle cx="16" cy="16" r="12" fill="#0a0f0a"/>
          <text x="16" y="21" text-anchor="middle" font-family="monospace" font-size="13" font-weight="900" fill="#00ff88">0n</text>
        </svg>
      </button>
    `;

    document.body.appendChild(fab);
    shadow.querySelector('button').addEventListener('click', () => {
      OnModal.init().then(() => OnModal.toggle());
    });
    fabCreated = true;
  }

  function init() {
    setTimeout(() => {
      createFAB();
      OnModal.init();
    }, 1800);

    // Watch for FAB removal by LinkedIn's re-renders
    const bodyObserver = new MutationObserver(() => {
      if (!document.getElementById('onlink-fab')) {
        fabCreated = false;
        createFAB();
      }
    });
    bodyObserver.observe(document.body, { childList: true, subtree: false });

    // SPA navigation — LinkedIn uses pushState
    const _push = history.pushState.bind(history);
    history.pushState = function (...args) {
      _push(...args);
      setTimeout(() => {
        if (!document.getElementById('onlink-fab')) { fabCreated = false; createFAB(); }
      }, 600);
    };
    window.addEventListener('popstate', () => {
      setTimeout(() => {
        if (!document.getElementById('onlink-fab')) { fabCreated = false; createFAB(); }
      }, 600);
    });
  }

  // Message bridge from popup
  chrome.runtime.onMessage.addListener((req, _sender, reply) => {
    if (req.action === 'openModal') {
      OnModal.init().then(() => OnModal.open());
      reply({ success: true });
    } else if (req.action === 'startSnip') {
      OnModal.init().then(() => { OnModal.open(); OnModal.startSnip(); });
      reply({ success: true });
    } else if (req.action === 'openCreate') {
      OnModal.init().then(() => { OnModal.open(); OnModal.switchTab('create'); });
      reply({ success: true });
    }
    return true;
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
