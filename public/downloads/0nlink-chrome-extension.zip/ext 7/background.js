// 0nLink — Background Service Worker
chrome.alarms.create('keepalive', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener(() => {});

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg.action === 'getStorage') {
    chrome.storage.local.get(msg.keys, reply);
    return true;
  }
  if (msg.action === 'setStorage') {
    chrome.storage.local.set(msg.data, () => reply({ ok: true }));
    return true;
  }
});
