// =============================================================================
// ROCKETLINK v3.0 - SNIPPING TOOL
// =============================================================================

const RocketSnipper = {
  isActive: false,
  startX: 0,
  startY: 0,
  overlay: null,
  box: null,
  hint: null,
  onCapture: null,

  start(callback) {
    if (this.isActive) return;
    this.isActive = true;
    this.onCapture = callback;
    this.createOverlay();
    this.attachListeners();
  },

  createOverlay() {
    this.overlay = document.createElement('div');
    this.overlay.className = 'rocket-snipper-overlay';
    document.body.appendChild(this.overlay);

    this.box = document.createElement('div');
    this.box.className = 'rocket-snipper-box';
    this.box.innerHTML = '<span class="rocket-snipper-label">📋 Release to capture</span>';
    this.box.style.display = 'none';
    document.body.appendChild(this.box);

    this.hint = document.createElement('div');
    this.hint.className = 'rocket-snipper-hint';
    this.hint.innerHTML = '🎯 Click and drag over the post. Press ESC to cancel.';
    document.body.appendChild(this.hint);
  },

  attachListeners() {
    this.overlay.addEventListener('mousedown', this.handleMouseDown.bind(this));
    document.addEventListener('mousemove', this.handleMouseMove.bind(this));
    document.addEventListener('mouseup', this.handleMouseUp.bind(this));
    document.addEventListener('keydown', this.handleKeyDown.bind(this));
  },

  handleMouseDown(e) {
    this.startX = e.clientX;
    this.startY = e.clientY;
    this.box.style.display = 'flex';
    this.box.style.left = this.startX + 'px';
    this.box.style.top = this.startY + 'px';
    this.box.style.width = '0px';
    this.box.style.height = '0px';
  },

  handleMouseMove(e) {
    if (!this.isActive || this.box.style.display === 'none') return;
    const left = Math.min(this.startX, e.clientX);
    const top = Math.min(this.startY, e.clientY);
    const width = Math.abs(e.clientX - this.startX);
    const height = Math.abs(e.clientY - this.startY);
    this.box.style.left = left + 'px';
    this.box.style.top = top + 'px';
    this.box.style.width = width + 'px';
    this.box.style.height = height + 'px';
  },

  handleMouseUp(e) {
    if (!this.isActive || this.box.style.display === 'none') return;
    const rect = {
      left: parseInt(this.box.style.left),
      top: parseInt(this.box.style.top),
      width: parseInt(this.box.style.width),
      height: parseInt(this.box.style.height)
    };
    if (rect.width < 50 || rect.height < 30) {
      this.cleanup();
      return;
    }
    const capturedText = this.captureTextInRect(rect);
    this.cleanup();
    if (capturedText && this.onCapture) {
      this.onCapture(capturedText);
    }
  },

  captureTextInRect(rect) {
    const elements = document.elementsFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
    let bestText = '';

    for (const el of elements) {
      if (el.className && el.className.includes && el.className.includes('rocket-')) continue;
      const postSelectors = [
        '.feed-shared-update-v2__description',
        '.feed-shared-text',
        '.update-components-text',
        '.feed-shared-inline-show-more-text',
        '.feed-shared-update-v2__commentary',
        '.break-words'
      ];

      for (const selector of postSelectors) {
        const postEl = el.closest(selector) || el.querySelector(selector);
        if (postEl) {
          const text = postEl.innerText.trim();
          if (text.length > bestText.length) bestText = text;
        }
      }
    }

    if (!bestText) bestText = this.getTextInArea(rect);
    return bestText;
  },

  getTextInArea(rect) {
    const textNodes = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    while (walker.nextNode()) {
      const node = walker.currentNode;
      const range = document.createRange();
      range.selectNodeContents(node);
      const nodeRect = range.getBoundingClientRect();
      if (nodeRect.left >= rect.left - 10 && nodeRect.top >= rect.top - 10 &&
          nodeRect.right <= rect.left + rect.width + 10 && nodeRect.bottom <= rect.top + rect.height + 10) {
        const text = node.textContent.trim();
        if (text) textNodes.push(text);
      }
    }
    return textNodes.join(' ').trim();
  },

  handleKeyDown(e) {
    if (e.key === 'Escape' && this.isActive) this.cleanup();
  },

  cleanup() {
    this.isActive = false;
    if (this.overlay) { this.overlay.remove(); this.overlay = null; }
    if (this.box) { this.box.remove(); this.box = null; }
    if (this.hint) { this.hint.remove(); this.hint = null; }
    document.removeEventListener('mousemove', this.handleMouseMove);
    document.removeEventListener('mouseup', this.handleMouseUp);
    document.removeEventListener('keydown', this.handleKeyDown);
  }
};

window.RocketSnipper = RocketSnipper;
