// =============================================================================
// 0nLink v1.0 — MAIN MODAL COMPONENT
// 11 tabs: Dashboard, Respond, Create, Images, Hashtags, Predictions,
//          Research, GHL Export, Products, Follow-ups, History
// =============================================================================

const OnModal = {
  isOpen: false,
  isMinimized: false,
  isDragging: false,
  currentTab: 'respond',
  dragOffset: { x: 0, y: 0 },
  postContent: '',
  generatedResponse: '',
  trends: [],
  selectedTrend: null,
  predictions: [],
  selectedPrediction: null,
  generatedPosts: [],
  selectedExportFacts: [],

  // ── INIT ──────────────────────────────────────────────────────────────────
  async init() {
    if (document.getElementById('onlink-modal-host')) return;
    const settings = await RocketStorage.getAll();
    this.createModal(settings);
    this.attachEventListeners();
    this.loadPosition(settings.ui?.modalPosition);
    this.loadTrends();
    this.loadHashtagClusters();
    this.loadProducts();
    this.loadStats();
    this.loadHistory();
    this.loadPredictions();
    this.initDashboard();
  },

  // ── CREATE MODAL DOM ───────────────────────────────────────────────────────
  createModal(settings) {
    // Host element + Shadow DOM for full isolation
    const host = document.createElement('div');
    host.id = 'onlink-modal-host';
    host.style.cssText = 'position:fixed;top:0;left:0;width:0;height:0;z-index:2147483646;pointer-events:none;';
    document.body.appendChild(host);

    const shadow = host.attachShadow({ mode: 'open' });

    const styleEl = document.createElement('style');
    styleEl.textContent = this.getCSS();
    shadow.appendChild(styleEl);

    const modal = document.createElement('div');
    modal.id = 'onlink-modal';
    modal.className = 'onl-modal';
    modal.style.display = 'none';
    modal.innerHTML = this.getModalHTML();
    shadow.appendChild(modal);

    // Store reference to shadow root
    this._shadow = shadow;
    this._modal = modal;
  },

  // ── CSS ────────────────────────────────────────────────────────────────────
  getCSS() {
    return `
:host { all: initial; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; }

/* ── VARIABLES ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:host {
  --c-bg0: #060a06;
  --c-bg1: #0c110c;
  --c-bg2: #121812;
  --c-bg3: #18201a;
  --c-bg4: #1e281f;
  --c-border: rgba(0, 255, 136, 0.08);
  --c-border2: rgba(0, 255, 136, 0.18);
  --c-green: #00ff88;
  --c-green2: #00cc66;
  --c-green3: #00995c;
  --c-green-dim: rgba(0, 255, 136, 0.15);
  --c-green-glow: rgba(0, 255, 136, 0.25);
  --c-text0: #f0fff4;
  --c-text1: rgba(240, 255, 244, 0.85);
  --c-text2: rgba(240, 255, 244, 0.55);
  --c-text3: rgba(240, 255, 244, 0.35);
  --c-accent: #00e5ff;
  --c-accent2: #0099aa;
  --c-warn: #ffbe0b;
  --c-error: #ff4757;
  --c-success: #00ff88;
  --r-sm: 8px; --r-md: 12px; --r-lg: 16px; --r-xl: 20px;
  --trans: all 0.18s cubic-bezier(0.4,0,0.2,1);
  --shadow: 0 24px 80px rgba(0,0,0,0.7), 0 0 0 1px var(--c-border2);
  --glow: 0 0 40px rgba(0,255,136,0.12);
}

/* ── MODAL SHELL ── */
.onl-modal {
  pointer-events: all;
  position: fixed;
  top: 80px; left: 20px;
  width: 460px;
  max-height: calc(100vh - 100px);
  background: var(--c-bg0);
  border: 1px solid var(--c-border2);
  border-radius: var(--r-xl);
  box-shadow: var(--shadow), var(--glow);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  animation: slideIn 0.22s cubic-bezier(0.34,1.56,0.64,1);
  user-select: none;
}
@keyframes slideIn {
  from { opacity:0; transform: translateY(-12px) scale(0.97); }
  to   { opacity:1; transform: translateY(0) scale(1); }
}

/* ── HEADER ── */
.onl-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 16px 12px;
  background: linear-gradient(135deg, var(--c-bg1) 0%, var(--c-bg2) 100%);
  border-bottom: 1px solid var(--c-border);
  cursor: grab;
  flex-shrink: 0;
}
.onl-header:active { cursor: grabbing; }
.onl-logo { display: flex; align-items: center; gap: 10px; }
.onl-logo-badge {
  width: 34px; height: 34px;
  background: linear-gradient(135deg, var(--c-green) 0%, var(--c-green2) 100%);
  border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  font-size: 13px; font-weight: 900; color: var(--c-bg0);
  font-family: monospace;
  box-shadow: 0 0 16px var(--c-green-glow);
  flex-shrink: 0;
}
.onl-logo-text { line-height: 1.1; }
.onl-logo-name { font-size: 15px; font-weight: 800; color: var(--c-text0); letter-spacing: -0.3px; }
.onl-logo-sub { font-size: 10px; color: var(--c-text3); text-transform: uppercase; letter-spacing: 0.8px; }
.onl-header-controls { display: flex; gap: 4px; }
.onl-ctrl {
  width: 28px; height: 28px;
  background: transparent; border: 1px solid var(--c-border);
  border-radius: 7px; color: var(--c-text2);
  font-size: 14px; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: var(--trans);
}
.onl-ctrl:hover { background: var(--c-bg3); color: var(--c-text0); border-color: var(--c-border2); }
.onl-ctrl.red:hover { background: rgba(255,71,87,0.15); color: var(--c-error); border-color: rgba(255,71,87,0.3); }

/* ── MINI ACTIONS ── */
.onl-mini {
  display: flex; gap: 4px; padding: 8px 12px;
  background: var(--c-bg1);
  border-bottom: 1px solid var(--c-border);
  overflow-x: auto;
  flex-shrink: 0;
}
.onl-mini::-webkit-scrollbar { display: none; }
.onl-mini-btn {
  display: flex; align-items: center; gap: 5px;
  padding: 5px 10px;
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: 20px; cursor: pointer;
  font-size: 11px; font-weight: 600; color: var(--c-text2);
  white-space: nowrap; transition: var(--trans);
}
.onl-mini-btn:hover { background: var(--c-bg3); color: var(--c-green); border-color: var(--c-green-dim); }

/* ── TABS ── */
.onl-tabs {
  display: flex; gap: 2px; padding: 8px 10px 0;
  background: var(--c-bg1);
  overflow-x: auto; flex-shrink: 0;
}
.onl-tabs::-webkit-scrollbar { height: 2px; }
.onl-tabs::-webkit-scrollbar-thumb { background: var(--c-border2); border-radius: 2px; }
.onl-tab {
  padding: 6px 12px;
  background: transparent; border: none;
  border-radius: 8px 8px 0 0;
  font-size: 11px; font-weight: 600; color: var(--c-text3);
  cursor: pointer; white-space: nowrap;
  transition: var(--trans);
  border-bottom: 2px solid transparent;
}
.onl-tab:hover { color: var(--c-text1); background: var(--c-bg3); }
.onl-tab.active {
  color: var(--c-green); background: var(--c-bg2);
  border-bottom-color: var(--c-green);
}

/* ── BODY ── */
.onl-body {
  flex: 1; overflow-y: auto;
  padding: 16px;
  background: var(--c-bg1);
}
.onl-body::-webkit-scrollbar { width: 4px; }
.onl-body::-webkit-scrollbar-track { background: transparent; }
.onl-body::-webkit-scrollbar-thumb { background: var(--c-border2); border-radius: 4px; }

.onl-tab-content { display: none; }
.onl-tab-content.active { display: block; }

/* ── FOOTER ── */
.onl-footer {
  padding: 8px 16px;
  background: var(--c-bg0);
  border-top: 1px solid var(--c-border);
  flex-shrink: 0;
}
.onl-status {
  font-size: 11px; color: var(--c-text3); text-align: center; min-height: 14px;
  transition: var(--trans);
}
.onl-status.success { color: var(--c-success); }
.onl-status.error { color: var(--c-error); }
.onl-status.info { color: var(--c-accent); }
.onl-status.warn { color: var(--c-warn); }

/* ── SECTION ── */
.onl-section { margin-bottom: 20px; }
.onl-section:last-child { margin-bottom: 0; }
.onl-label-row { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
.onl-label { font-size: 11px; font-weight: 700; color: var(--c-text2); text-transform: uppercase; letter-spacing: 0.7px; }
.onl-hint { font-size: 11px; color: var(--c-text3); margin-bottom: 10px; line-height: 1.5; }

/* ── INPUTS ── */
.onl-input, .onl-textarea, .onl-select {
  width: 100%;
  background: var(--c-bg0); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); color: var(--c-text0);
  font-family: inherit; font-size: 13px;
  transition: var(--trans);
  padding: 9px 12px;
}
.onl-input::placeholder, .onl-textarea::placeholder { color: var(--c-text3); }
.onl-input:focus, .onl-textarea:focus, .onl-select:focus {
  outline: none; border-color: var(--c-green2);
  box-shadow: 0 0 0 2px var(--c-green-dim);
}
.onl-textarea { resize: vertical; min-height: 90px; line-height: 1.5; }
.onl-select { appearance: none; cursor: pointer; }
.onl-select option { background: var(--c-bg2); }

/* ── BUTTONS ── */
.onl-btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 6px;
  padding: 9px 16px; border: none; border-radius: var(--r-sm);
  font-family: inherit; font-size: 12px; font-weight: 700;
  cursor: pointer; transition: var(--trans); white-space: nowrap;
}
.onl-btn:disabled { opacity: 0.45; cursor: not-allowed; }
.onl-btn-row { display: flex; gap: 8px; margin-top: 10px; flex-wrap: wrap; }
.onl-btn-full { width: 100%; }

.onl-btn-primary {
  background: linear-gradient(135deg, var(--c-green) 0%, var(--c-green2) 100%);
  color: var(--c-bg0);
  box-shadow: 0 0 20px var(--c-green-dim);
}
.onl-btn-primary:hover:not(:disabled) { box-shadow: 0 0 28px var(--c-green-glow); transform: translateY(-1px); }

.onl-btn-secondary {
  background: var(--c-bg3); border: 1px solid var(--c-border);
  color: var(--c-text1);
}
.onl-btn-secondary:hover:not(:disabled) { background: var(--c-bg4); border-color: var(--c-border2); color: var(--c-text0); }

.onl-btn-accent {
  background: linear-gradient(135deg, var(--c-accent) 0%, var(--c-accent2) 100%);
  color: var(--c-bg0);
}
.onl-btn-accent:hover:not(:disabled) { box-shadow: 0 0 20px rgba(0,229,255,0.3); transform: translateY(-1px); }

.onl-btn-success {
  background: rgba(0,255,136,0.15); border: 1px solid rgba(0,255,136,0.3);
  color: var(--c-green);
}
.onl-btn-success:hover:not(:disabled) { background: rgba(0,255,136,0.22); }

.onl-btn-danger {
  background: rgba(255,71,87,0.12); border: 1px solid rgba(255,71,87,0.25);
  color: var(--c-error);
}
.onl-btn-danger:hover:not(:disabled) { background: rgba(255,71,87,0.2); }

.onl-btn-sm { padding: 5px 10px; font-size: 11px; }
.onl-btn-text { background: transparent; border: none; color: var(--c-green); font-size: 11px; font-weight: 600; cursor: pointer; padding: 0; font-family: inherit; }
.onl-btn-text:hover { color: var(--c-green2); }
.onl-spinner { width: 12px; height: 12px; border: 2px solid transparent; border-top-color: currentColor; border-radius: 50%; animation: spin 0.7s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

/* ── CARDS & LISTS ── */
.onl-card {
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-md); padding: 12px;
  transition: var(--trans);
}
.onl-card:hover { border-color: var(--c-border2); }

.onl-post-preview {
  background: var(--c-bg0); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); padding: 12px;
  font-size: 13px; color: var(--c-text1); line-height: 1.6;
  min-height: 80px; white-space: pre-wrap;
}
.onl-placeholder { color: var(--c-text3); font-style: italic; font-size: 12px; }

/* ── TYPE GRID ── */
.onl-type-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 6px; }
.onl-type-btn {
  display: flex; flex-direction: column; align-items: center; gap: 3px;
  padding: 9px 6px;
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); cursor: pointer; transition: var(--trans);
}
.onl-type-btn:hover { border-color: var(--c-border2); background: var(--c-bg3); }
.onl-type-btn.active { border-color: var(--c-green2); background: var(--c-green-dim); }
.onl-type-icon { font-size: 18px; }
.onl-type-label { font-size: 10px; font-weight: 700; color: var(--c-text2); text-align: center; }

/* ── CHAR COUNT ── */
.onl-char-count { font-size: 10px; color: var(--c-text3); }
.onl-char-count.warn { color: var(--c-warn); }
.onl-char-count.over { color: var(--c-error); }

/* ── TREND CARDS ── */
.onl-trend-card {
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); padding: 10px 12px;
  cursor: pointer; margin-bottom: 6px; transition: var(--trans);
}
.onl-trend-card:hover { border-color: var(--c-green2); background: var(--c-bg3); }
.onl-trend-card.selected { border-color: var(--c-green); background: var(--c-green-dim); }
.onl-trend-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 5px; }
.onl-trend-topic { font-size: 13px; font-weight: 600; color: var(--c-text0); flex: 1; }
.onl-trend-score {
  font-size: 11px; font-weight: 800; color: var(--c-bg0);
  background: linear-gradient(135deg, var(--c-green), var(--c-green2));
  padding: 2px 7px; border-radius: 10px;
}
.onl-trend-metrics { display: flex; gap: 10px; font-size: 11px; color: var(--c-text3); }

/* ── STYLE GRID ── */
.onl-style-grid { display: grid; grid-template-columns: repeat(2,1fr); gap: 8px; }
.onl-style-btn {
  display: flex; flex-direction: column; align-items: center; gap: 4px;
  padding: 12px 8px;
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); cursor: pointer; transition: var(--trans);
}
.onl-style-btn:hover { border-color: var(--c-green2); }
.onl-style-btn.active { border-color: var(--c-green); background: var(--c-green-dim); }
.onl-style-icon { font-size: 20px; }
.onl-style-name { font-size: 11px; font-weight: 700; color: var(--c-text1); }
.onl-style-desc { font-size: 10px; color: var(--c-text3); text-align: center; }

/* ── HASHTAGS ── */
.onl-selected-hashtags {
  background: var(--c-bg0); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); padding: 10px 12px;
  min-height: 44px;
}
.onl-selected-list { display: flex; flex-wrap: wrap; gap: 6px; }
.onl-selected-tag {
  display: inline-flex; align-items: center; gap: 4px;
  background: var(--c-green-dim); border: 1px solid rgba(0,255,136,0.25);
  border-radius: 20px; padding: 3px 10px;
  font-size: 11px; font-weight: 600; color: var(--c-green);
}
.onl-selected-tag .remove { cursor: pointer; opacity: 0.6; }
.onl-selected-tag .remove:hover { opacity: 1; }
.onl-hashtag-clusters { display: flex; flex-direction: column; gap: 10px; }
.onl-cluster-header { display: flex; justify-content: space-between; margin-bottom: 6px; }
.onl-cluster-name { font-size: 12px; font-weight: 700; color: var(--c-text1); cursor: pointer; }
.onl-cluster-count { font-size: 10px; color: var(--c-text3); }
.onl-cluster-tags { display: flex; flex-wrap: wrap; gap: 5px; }
.onl-tag {
  display: inline-block;
  background: var(--c-bg3); border: 1px solid var(--c-border);
  border-radius: 20px; padding: 3px 9px;
  font-size: 11px; color: var(--c-text2); cursor: pointer; transition: var(--trans);
}
.onl-tag:hover { border-color: var(--c-green2); color: var(--c-green); }
.onl-tag.selected { background: var(--c-green-dim); border-color: rgba(0,255,136,0.3); color: var(--c-green); }

/* ── PREDICTION CARDS ── */
.onl-prediction-card {
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); padding: 10px 12px;
  cursor: pointer; margin-bottom: 6px; transition: var(--trans);
}
.onl-prediction-card:hover { border-color: var(--c-border2); }
.onl-prediction-card.selected { border-color: var(--c-accent); background: rgba(0,229,255,0.05); }
.onl-prediction-header { display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; margin-bottom: 5px; }
.onl-prediction-q { font-size: 12px; color: var(--c-text1); flex: 1; line-height: 1.4; }
.onl-prediction-prob {
  font-size: 11px; font-weight: 800; color: var(--c-bg0);
  padding: 2px 8px; border-radius: 10px; white-space: nowrap;
}
.onl-prediction-meta { display: flex; gap: 10px; font-size: 10px; color: var(--c-text3); }

/* ── STAT ITEMS ── */
.onl-stat-item {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 12px;
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); margin-bottom: 6px;
}
.onl-stat-item-left { display: flex; align-items: center; gap: 10px; flex: 1; min-width: 0; }
.onl-stat-value { font-size: 15px; font-weight: 800; color: var(--c-green); white-space: nowrap; }
.onl-stat-info { flex: 1; min-width: 0; }
.onl-stat-desc { font-size: 12px; color: var(--c-text1); display: block; }
.onl-stat-source { font-size: 10px; color: var(--c-text3); }
.onl-stat-actions { display: flex; align-items: center; gap: 5px; }
.onl-stat-action {
  background: transparent; border: none; cursor: pointer;
  font-size: 14px; padding: 2px; opacity: 0.6; transition: var(--trans);
}
.onl-stat-action:hover { opacity: 1; transform: scale(1.1); }

/* ── STATUS GRID (dashboard) ── */
.onl-conn-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.onl-status-card {
  display: flex; flex-direction: column; gap: 3px;
  padding: 10px 12px;
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-sm);
}
.onl-status-icon { font-size: 18px; }
.onl-status-label { font-size: 10px; color: var(--c-text3); text-transform: uppercase; letter-spacing: 0.5px; }
.onl-status-value { font-size: 11px; font-weight: 700; color: var(--c-text1); }

/* ── STATS GRID ── */
.onl-stats-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 6px; }
.onl-stat-card {
  display: flex; flex-direction: column; align-items: center; gap: 2px;
  padding: 10px 6px;
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); text-align: center;
}
.onl-stat-card-value { font-size: 18px; font-weight: 800; color: var(--c-green); }
.onl-stat-card-label { font-size: 9px; color: var(--c-text3); text-transform: uppercase; letter-spacing: 0.5px; }

/* ── QUEUE GRID ── */
.onl-queue-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.onl-queue-card {
  display: flex; flex-direction: column; align-items: center; gap: 6px;
  padding: 12px;
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); text-align: center;
}
.onl-queue-count { font-size: 24px; font-weight: 800; color: var(--c-green); }
.onl-queue-label { font-size: 10px; color: var(--c-text3); }

/* ── AUTO TOGGLES ── */
.onl-auto-toggle {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 12px;
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); margin-bottom: 6px;
}
.onl-auto-title { font-size: 12px; font-weight: 600; color: var(--c-text0); }
.onl-auto-desc { font-size: 10px; color: var(--c-text3); }
.onl-toggle {
  width: 36px; height: 20px;
  background: var(--c-bg3); border: 1px solid var(--c-border);
  border-radius: 10px; cursor: pointer; transition: var(--trans);
  position: relative; flex-shrink: 0;
}
.onl-toggle::after {
  content: ''; position: absolute;
  top: 2px; left: 2px;
  width: 14px; height: 14px;
  background: var(--c-text3); border-radius: 50%;
  transition: var(--trans);
}
.onl-toggle.active { background: var(--c-green-dim); border-color: var(--c-green2); }
.onl-toggle.active::after { background: var(--c-green); transform: translateX(16px); }

/* ── PRODUCT ITEMS ── */
.onl-product-item {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 12px;
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); margin-bottom: 6px;
}
.onl-product-name { font-size: 12px; font-weight: 600; color: var(--c-text0); }
.onl-product-desc { font-size: 11px; color: var(--c-text3); }
.onl-product-toggle {
  width: 36px; height: 20px;
  background: var(--c-bg3); border: 1px solid var(--c-border);
  border-radius: 10px; cursor: pointer; transition: var(--trans);
  position: relative; flex-shrink: 0;
}
.onl-product-toggle::after {
  content: ''; position: absolute;
  top: 2px; left: 2px;
  width: 14px; height: 14px;
  background: var(--c-text3); border-radius: 50%; transition: var(--trans);
}
.onl-product-toggle.active { background: var(--c-green-dim); border-color: var(--c-green2); }
.onl-product-toggle.active::after { background: var(--c-green); transform: translateX(16px); }

/* ── FOLLOW-UPS ── */
.onl-followup-list { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.onl-followup-btn {
  display: flex; align-items: center; gap: 6px;
  padding: 10px 12px;
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); cursor: pointer; transition: var(--trans);
  font-family: inherit; font-size: 12px; font-weight: 600; color: var(--c-text1);
}
.onl-followup-btn:hover { border-color: var(--c-green2); color: var(--c-green); background: var(--c-bg3); }
.onl-followup-preview {
  background: var(--c-bg0); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); padding: 12px;
  font-size: 12px; color: var(--c-text2); line-height: 1.6;
  min-height: 80px; white-space: pre-wrap;
}

/* ── HISTORY ── */
.onl-history-list { display: flex; flex-direction: column; gap: 8px; }
.onl-history-item {
  background: var(--c-bg2); border: 1px solid var(--c-border);
  border-radius: var(--r-sm); padding: 10px 12px;
}
.onl-history-meta { display: flex; justify-content: space-between; margin-bottom: 5px; }
.onl-history-type {
  font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;
  padding: 2px 7px; border-radius: 10px;
  background: var(--c-green-dim); color: var(--c-green);
}
.onl-history-time { font-size: 10px; color: var(--c-text3); }
.onl-history-text { font-size: 12px; color: var(--c-text2); line-height: 1.5; max-height: 60px; overflow: hidden; }

/* ── IMAGEGEN ── */
.onl-imagegen-opts { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px; }
.onl-opt-group label { display: block; font-size: 10px; color: var(--c-text3); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
.onl-image-container { margin-top: 12px; border-radius: var(--r-sm); overflow: hidden; border: 1px solid var(--c-border); }
.onl-image-container img { width: 100%; display: block; }
.onl-saved-images-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 6px; margin-top: 8px; }
.onl-saved-img-thumb { border-radius: 6px; overflow: hidden; cursor: pointer; border: 2px solid transparent; transition: var(--trans); aspect-ratio: 1; }
.onl-saved-img-thumb:hover { border-color: var(--c-green2); }
.onl-saved-img-thumb img { width: 100%; height: 100%; object-fit: cover; }
.onl-variations-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 8px; margin-top: 8px; }
.onl-variation-item { border-radius: var(--r-sm); overflow: hidden; border: 1px solid var(--c-border); cursor: pointer; transition: var(--trans); }
.onl-variation-item:hover { border-color: var(--c-green2); }
.onl-variation-item img { width: 100%; display: block; }

/* ── PULSE ── */
.onl-pulse { animation: pulse 1.4s ease-in-out infinite; }
@keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.4; } }

/* ── DRAGGING ── */
.onl-modal.dragging { transition: none !important; }

/* ── MINIMIZED ── */
.onl-modal.minimized .onl-mini,
.onl-modal.minimized .onl-tabs,
.onl-modal.minimized .onl-body,
.onl-modal.minimized .onl-footer { display: none; }
.onl-modal.minimized { max-height: auto; }

/* ── GHL EXPORT ── */
.onl-export-opts { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 12px; }
.onl-export-opt label { display: block; font-size: 10px; color: var(--c-text3); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
.onl-export-preview { display: flex; flex-direction: column; gap: 6px; margin-top: 10px; }
.onl-export-post { background: var(--c-bg2); border: 1px solid var(--c-border); border-radius: var(--r-sm); padding: 10px 12px; }
.onl-export-post-meta { display: flex; justify-content: space-between; font-size: 10px; color: var(--c-text3); margin-bottom: 5px; }
.onl-export-post-text { font-size: 12px; color: var(--c-text2); line-height: 1.5; }
`;
  },

  // ── HTML TEMPLATE ──────────────────────────────────────────────────────────
  getModalHTML() {
    return `
<div class="onl-header" id="onl-drag-handle">
  <div class="onl-logo">
    <div class="onl-logo-badge">0n</div>
    <div class="onl-logo-text">
      <div class="onl-logo-name">0nLink</div>
      <div class="onl-logo-sub">LinkedIn AI Engine</div>
    </div>
  </div>
  <div class="onl-header-controls">
    <button class="onl-ctrl" id="onl-minimize" title="Minimize">─</button>
    <button class="onl-ctrl" id="onl-settings" title="Settings">⚙</button>
    <button class="onl-ctrl red" id="onl-close" title="Close">✕</button>
  </div>
</div>

<div class="onl-mini">
  <button class="onl-mini-btn" data-action="snip">✂ Snip</button>
  <button class="onl-mini-btn" data-action="respond">💬 Respond</button>
  <button class="onl-mini-btn" data-action="create">✏ Create</button>
  <button class="onl-mini-btn" data-action="hashtags"># Tags</button>
  <button class="onl-mini-btn" data-action="expand">↗ Full</button>
</div>

<div class="onl-tabs">
  <button class="onl-tab" data-tab="dashboard">📊 Dashboard</button>
  <button class="onl-tab active" data-tab="respond">💬 Respond</button>
  <button class="onl-tab" data-tab="create">✏ Create</button>
  <button class="onl-tab" data-tab="imagegen">🖼 Images</button>
  <button class="onl-tab" data-tab="hashtags"># Hashtags</button>
  <button class="onl-tab" data-tab="predictions">🎯 Predictions</button>
  <button class="onl-tab" data-tab="research">🔬 Research</button>
  <button class="onl-tab" data-tab="export">📤 GHL</button>
  <button class="onl-tab" data-tab="products">📦 Products</button>
  <button class="onl-tab" data-tab="followups">🔄 Follow-ups</button>
  <button class="onl-tab" data-tab="history">📜 History</button>
</div>

<div class="onl-body">
  ${this.renderDashboard()}
  ${this.renderRespond()}
  ${this.renderCreate()}
  ${this.renderImageGen()}
  ${this.renderHashtags()}
  ${this.renderPredictions()}
  ${this.renderResearch()}
  ${this.renderExport()}
  ${this.renderProducts()}
  ${this.renderFollowups()}
  ${this.renderHistory()}
</div>

<div class="onl-footer">
  <div class="onl-status" id="onl-status"></div>
</div>`;
  },

  // ── TAB RENDERS ───────────────────────────────────────────────────────────
  renderDashboard() { return `
<div class="onl-tab-content" id="onl-tab-dashboard">
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">🔌 Connections</span><button class="onl-btn-text" id="onl-refresh-dashboard">↻ Refresh</button></div>
    <div class="onl-conn-grid">
      <div class="onl-status-card"><span class="onl-status-icon" id="ghl-status-icon">⏳</span><span class="onl-status-label">GHL API</span><span class="onl-status-value" id="ghl-status-text">Checking…</span></div>
      <div class="onl-status-card"><span class="onl-status-icon" id="li-status-icon">⏳</span><span class="onl-status-label">LinkedIn</span><span class="onl-status-value" id="li-status-text">Checking…</span></div>
    </div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">📈 7-Day Stats</span></div>
    <div class="onl-stats-grid">
      <div class="onl-stat-card"><span class="onl-stat-card-value" id="stat-total">-</span><span class="onl-stat-card-label">Total</span></div>
      <div class="onl-stat-card"><span class="onl-stat-card-value" id="stat-published">-</span><span class="onl-stat-card-label">Published</span></div>
      <div class="onl-stat-card"><span class="onl-stat-card-value" id="stat-scheduled">-</span><span class="onl-stat-card-label">Scheduled</span></div>
      <div class="onl-stat-card"><span class="onl-stat-card-value" id="stat-failed">-</span><span class="onl-stat-card-label">Failed</span></div>
    </div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">📋 Queues</span></div>
    <div class="onl-queue-grid">
      <div class="onl-queue-card"><span class="onl-queue-count" id="pending-facts-count">0</span><span class="onl-queue-label">Facts to Verify</span><button class="onl-btn onl-btn-accent onl-btn-sm" id="onl-review-facts">Review</button></div>
      <div class="onl-queue-card"><span class="onl-queue-count" id="pending-posts-count">0</span><span class="onl-queue-label">Posts to Approve</span><button class="onl-btn onl-btn-primary onl-btn-sm" id="onl-review-posts">Review</button></div>
    </div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">🤖 Automation</span></div>
    <div class="onl-auto-toggle"><div><div class="onl-auto-title">Auto-Discovery</div><div class="onl-auto-desc">Find new facts daily</div></div><button class="onl-toggle" id="onl-toggle-autodiscovery"></button></div>
    <div class="onl-auto-toggle"><div><div class="onl-auto-title">Auto-Publish</div><div class="onl-auto-desc">Queue posts automatically</div></div><button class="onl-toggle" id="onl-toggle-autopublish"></button></div>
    <div class="onl-btn-row">
      <button class="onl-btn onl-btn-secondary" id="onl-run-discovery">🔍 Run Discovery</button>
      <button class="onl-btn onl-btn-secondary" id="onl-generate-week">📅 Generate Week</button>
    </div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">📝 Recent Posts</span><span class="onl-hint" id="onl-posts-updated" style="margin:0"></span></div>
    <div id="onl-recent-posts"><p class="onl-placeholder">Loading…</p></div>
  </div>
</div>`; },

  renderRespond() { return `
<div class="onl-tab-content active" id="onl-tab-respond">
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Post Content</span></div>
    <div class="onl-post-preview" id="onl-post-preview"><span class="onl-placeholder">Click "Snip Post" to capture a post, or paste</span></div>
    <div class="onl-btn-row">
      <button class="onl-btn onl-btn-primary" id="onl-snip">✂ Snip Post</button>
      <button class="onl-btn onl-btn-secondary" id="onl-paste">📋 Paste</button>
      <button class="onl-btn onl-btn-secondary" id="onl-clear">🗑</button>
    </div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Response Type</span></div>
    <div class="onl-type-grid">
      <button class="onl-type-btn active" data-type="auto"><span class="onl-type-icon">🧠</span><span class="onl-type-label">Auto</span></button>
      <button class="onl-type-btn" data-type="gap"><span class="onl-type-icon">📉</span><span class="onl-type-label">The Gap</span></button>
      <button class="onl-type-btn" data-type="elevation"><span class="onl-type-icon">🏔</span><span class="onl-type-label">Elevate</span></button>
      <button class="onl-type-btn" data-type="dataDrop"><span class="onl-type-icon">📊</span><span class="onl-type-label">Data Drop</span></button>
      <button class="onl-type-btn" data-type="contrarian"><span class="onl-type-icon">🔄</span><span class="onl-type-label">Contrarian</span></button>
      <button class="onl-type-btn" data-type="toolListicle"><span class="onl-type-icon">🛠</span><span class="onl-type-label">Tool List</span></button>
    </div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Generated Response</span><span class="onl-char-count" id="onl-char-count">0 / 3000</span></div>
    <textarea class="onl-textarea" id="onl-response" placeholder="Your AI-generated response…" style="min-height:140px"></textarea>
    <div class="onl-btn-row">
      <button class="onl-btn onl-btn-primary onl-btn-full" id="onl-generate">
        <span id="onl-gen-text">⚡ Generate Response</span>
        <span id="onl-gen-loading" style="display:none"><span class="onl-spinner"></span> Generating…</span>
      </button>
    </div>
    <div class="onl-btn-row">
      <button class="onl-btn onl-btn-success" id="onl-copy">📋 Copy</button>
      <button class="onl-btn onl-btn-secondary" id="onl-save">💾 Save</button>
    </div>
  </div>
</div>`; },

  renderCreate() { return `
<div class="onl-tab-content" id="onl-tab-create">
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">🔥 Trending Topics</span><button class="onl-btn-text" id="onl-refresh-trends">↻ Refresh</button></div>
    <div id="onl-trends-list"><p class="onl-placeholder onl-pulse">Loading trends…</p></div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Or Enter Topic</span></div>
    <input class="onl-input" id="onl-custom-topic" placeholder="e.g., AI Automation, MCP Orchestration…" />
    <div class="onl-btn-row">
      <button class="onl-btn onl-btn-primary onl-btn-full" id="onl-generate-post">
        <span id="onl-genpost-text">✏ Generate Post</span>
        <span id="onl-genpost-loading" style="display:none"><span class="onl-spinner"></span> Creating…</span>
      </button>
    </div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Generated Post</span><span class="onl-char-count" id="onl-post-char-count">0 / 3000</span></div>
    <textarea class="onl-textarea" id="onl-generated-post" placeholder="Your AI-generated post…" style="min-height:180px"></textarea>
    <div class="onl-btn-row">
      <button class="onl-btn onl-btn-success" id="onl-copy-post">📋 Copy</button>
      <button class="onl-btn onl-btn-accent" id="onl-post-linkedin">🔗 Post to LinkedIn</button>
    </div>
  </div>
</div>`; },

  renderImageGen() { return `
<div class="onl-tab-content" id="onl-tab-imagegen">
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">🎨 Brand Styles</span></div>
    <div class="onl-style-grid">
      <button class="onl-style-btn" data-style="elevated"><span class="onl-style-icon">🏔</span><span class="onl-style-name">Elevated</span><span class="onl-style-desc">5 years ahead</span></button>
      <button class="onl-style-btn" data-style="builder"><span class="onl-style-icon">🔨</span><span class="onl-style-name">Builder</span><span class="onl-style-desc">Ship vs talk</span></button>
      <button class="onl-style-btn" data-style="automation"><span class="onl-style-icon">⚡</span><span class="onl-style-name">Automation</span><span class="onl-style-desc">Flow vs chaos</span></button>
      <button class="onl-style-btn" data-style="results"><span class="onl-style-icon">📊</span><span class="onl-style-name">Results</span><span class="onl-style-desc">Impact gap</span></button>
    </div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">✍ Custom Prompt</span></div>
    <textarea class="onl-textarea" id="onl-image-prompt" rows="4" placeholder="Describe your image…&#10;&#10;Example: A powerful conceptual image showing an AI company 5 years ahead, standing on an elevated platform with clean MCP workflows…"></textarea>
    <div class="onl-imagegen-opts">
      <div class="onl-opt-group"><label>Model</label><select class="onl-select" id="onl-image-model"><option value="gemini-2.5-flash-image">⚡ Flash</option><option value="gemini-3-pro-image-preview">🎨 Pro 4K</option></select></div>
      <div class="onl-opt-group"><label>Aspect</label><select class="onl-select" id="onl-image-aspect"><option value="1:1">1:1 Square</option><option value="4:5">4:5 Portrait</option><option value="16:9" selected>16:9 Wide</option><option value="9:16">9:16 Vertical</option></select></div>
      <div class="onl-opt-group"><label>Size</label><select class="onl-select" id="onl-image-size"><option value="1K">1K</option><option value="2K" selected>2K</option><option value="4K">4K</option></select></div>
      <div class="onl-opt-group"><label>Style</label><select class="onl-select" id="onl-image-enhancer"><option value="photorealistic" selected>Photo-realistic</option><option value="corporate">Corporate</option><option value="tech">Tech/Futuristic</option><option value="contrast">High Contrast</option><option value="conceptual">Conceptual</option></select></div>
    </div>
    <div class="onl-btn-row">
      <button class="onl-btn onl-btn-primary" id="onl-generate-image">🖼 Generate</button>
      <button class="onl-btn onl-btn-secondary" id="onl-generate-variations">🎲 3 Variations</button>
    </div>
    <div id="onl-imagegen-status" class="onl-status" style="margin-top:8px"></div>
  </div>
  <div id="onl-image-preview-section" style="display:none" class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Generated Image</span><div class="onl-btn-row" style="margin:0;gap:6px"><button class="onl-btn-text" id="onl-download-image">⬇ Save</button><button class="onl-btn-text" id="onl-copy-image">📋 Copy</button></div></div>
    <div class="onl-image-container"><img id="onl-generated-image" src="" alt="Generated"/></div>
  </div>
  <div id="onl-variations-section" style="display:none" class="onl-section">
    <span class="onl-label">Variations</span>
    <div class="onl-variations-grid" id="onl-variations-grid"></div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">💾 Saved Images</span><button class="onl-btn-text" id="onl-refresh-saved">↻</button></div>
    <div class="onl-saved-images-grid" id="onl-saved-images"><p class="onl-placeholder">No saved images</p></div>
  </div>
</div>`; },

  renderHashtags() { return `
<div class="onl-tab-content" id="onl-tab-hashtags">
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Selected Hashtags</span></div>
    <div class="onl-selected-hashtags"><div class="onl-selected-list" id="onl-selected-list"><span class="onl-placeholder">Click clusters below to add</span></div></div>
    <div class="onl-btn-row">
      <button class="onl-btn onl-btn-success onl-btn-sm" id="onl-copy-hashtags">📋 Copy</button>
      <button class="onl-btn onl-btn-secondary onl-btn-sm" id="onl-clear-hashtags">🗑 Clear</button>
      <button class="onl-btn onl-btn-accent onl-btn-sm" id="onl-ai-suggest">🤖 AI Suggest</button>
    </div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Hashtag Clusters</span></div>
    <p class="onl-hint">Click a cluster header to add all, or click individual tags</p>
    <div class="onl-hashtag-clusters" id="onl-hashtag-clusters"></div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Add Custom</span></div>
    <div class="onl-btn-row" style="margin:0">
      <input class="onl-input" id="onl-custom-hashtag" placeholder="#YourHashtag" style="flex:1"/>
      <button class="onl-btn onl-btn-secondary" id="onl-add-hashtag">+ Add</button>
    </div>
  </div>
</div>`; },

  renderPredictions() { return `
<div class="onl-tab-content" id="onl-tab-predictions">
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">🎯 Polymarket</span><button class="onl-btn-text" id="onl-refresh-predictions">↻ Refresh</button></div>
    <p class="onl-hint">Real-time crowd intelligence. Click to use in posts.</p>
    <div id="onl-predictions-list"><p class="onl-placeholder onl-pulse">Loading…</p></div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">🔍 Search</span></div>
    <div class="onl-btn-row" style="margin:0">
      <input class="onl-input" id="onl-prediction-search" placeholder="Search: AI, economy, tech…" style="flex:1"/>
      <button class="onl-btn onl-btn-secondary" id="onl-search-predictions">Go</button>
    </div>
    <div class="onl-btn-row" style="flex-wrap:wrap;margin-top:8px">
      <button class="onl-btn onl-btn-secondary onl-btn-sm onl-pred-filter" data-filter="ai">🤖 AI</button>
      <button class="onl-btn onl-btn-secondary onl-btn-sm onl-pred-filter" data-filter="economy">💰 Economy</button>
      <button class="onl-btn onl-btn-secondary onl-btn-sm onl-pred-filter" data-filter="tech">💻 Tech</button>
      <button class="onl-btn onl-btn-secondary onl-btn-sm onl-pred-filter" data-filter="crypto">₿ Crypto</button>
      <button class="onl-btn onl-btn-secondary onl-btn-sm onl-pred-filter" data-filter="business">📈 Biz</button>
    </div>
  </div>
  <div id="onl-selected-prediction" style="display:none" class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Selected</span></div>
    <div class="onl-card" id="onl-prediction-detail"></div>
    <div class="onl-btn-row">
      <button class="onl-btn onl-btn-success onl-btn-sm" id="onl-copy-prediction">📋 Copy Insight</button>
      <button class="onl-btn onl-btn-primary onl-btn-sm" id="onl-add-to-post">➕ Add to Post</button>
      <button class="onl-btn onl-btn-secondary onl-btn-sm" id="onl-save-as-stat">💾 Save as Stat</button>
    </div>
  </div>
</div>`; },

  renderResearch() { return `
<div class="onl-tab-content" id="onl-tab-research">
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">✅ Verified Facts</span><button class="onl-btn-text" id="onl-add-stat">+ Add New</button></div>
    <p class="onl-hint">🥇 Tier 1 sources only. Click to copy.</p>
    <div id="onl-stats-list"></div>
  </div>
  <div id="onl-pending-section" style="display:none" class="onl-section">
    <div class="onl-label-row"><span class="onl-label">⏳ Pending Review</span><span class="onl-char-count" id="onl-pending-count">0</span></div>
    <div id="onl-pending-list"></div>
  </div>
  <div id="onl-add-stat-form" style="display:none" class="onl-section">
    <div class="onl-label-row"><span class="onl-label">New Fact</span></div>
    <div style="display:flex;flex-direction:column;gap:6px">
      <input class="onl-input" id="onl-new-stat-value" placeholder="Value (e.g. 88%)"/>
      <input class="onl-input" id="onl-new-stat-desc" placeholder="Description"/>
      <input class="onl-input" id="onl-new-stat-source" placeholder="Source (McKinsey, Gartner…)"/>
      <input class="onl-input" id="onl-new-stat-url" placeholder="Source URL (optional)"/>
      <input class="onl-input" id="onl-new-stat-date" placeholder="Report Date (YYYY-MM)"/>
    </div>
    <div class="onl-btn-row">
      <button class="onl-btn onl-btn-primary" id="onl-save-new-stat">Save Fact</button>
      <button class="onl-btn onl-btn-secondary" id="onl-cancel-stat">Cancel</button>
    </div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">🤖 Auto-Discover</span></div>
    <p class="onl-hint">AI finds new Tier 1 stats. You approve before they're added.</p>
    <select class="onl-select" id="onl-discover-category" style="margin-bottom:8px">
      <option value="ai-adoption">AI Adoption Stats</option>
      <option value="ai-impact">AI Business Impact</option>
      <option value="ai-agents">AI Agents</option>
      <option value="digital-transform">Digital Transformation</option>
      <option value="smb-tech">SMB Technology</option>
      <option value="workforce-ai">Workforce & AI</option>
      <option value="marketing-ai">Marketing AI</option>
    </select>
    <button class="onl-btn onl-btn-accent onl-btn-full" id="onl-discover-facts">
      <span id="onl-discover-text">🔍 Discover New Facts</span>
      <span id="onl-discover-loading" style="display:none"><span class="onl-spinner"></span> Researching…</span>
    </button>
    <div id="onl-discover-result" style="margin-top:10px"></div>
  </div>
</div>`; },

  renderExport() {
    const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate() + 1);
    const tmStr = tomorrow.toISOString().split('T')[0];
    return `
<div class="onl-tab-content" id="onl-tab-export">
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">📤 GHL Bulk Generator</span></div>
    <p class="onl-hint">Generate CSV for GoHighLevel Social Planner import.</p>
    <div class="onl-export-opts">
      <div class="onl-export-opt"><label>Start Date</label><input class="onl-input" type="date" id="onl-export-start-date" value="${tmStr}"/></div>
      <div class="onl-export-opt"><label>Posts/Day</label><select class="onl-select" id="onl-export-posts-per-day"><option value="1">1</option><option value="2" selected>2</option><option value="3">3</option></select></div>
      <div class="onl-export-opt"><label>Total Days</label><select class="onl-select" id="onl-export-days"><option value="7">7 days</option><option value="14" selected>14 days</option><option value="30">30 days</option></select></div>
      <div class="onl-export-opt"><label>Post Times</label><select class="onl-select" id="onl-export-times"><option value="morning">Morning (9,12)</option><option value="afternoon" selected>Afternoon (9,17)</option><option value="evening">Evening (12,18)</option><option value="peak">Peak (10,12,17)</option></select></div>
      <div class="onl-export-opt"><label>Hashtag Set</label><select class="onl-select" id="onl-export-hashtags"><option value="ai_business" selected>AI Business</option><option value="ai_agents">AI Agents</option><option value="entrepreneurship">Entrepreneurship</option></select></div>
    </div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Include Facts</span><div class="onl-btn-row" style="margin:0;gap:4px"><button class="onl-btn-text" id="onl-select-all-facts">All</button><span style="color:var(--c-text3);font-size:11px">/</span><button class="onl-btn-text" id="onl-deselect-all-facts">None</button></div></div>
    <div id="onl-export-facts-list" style="max-height:120px;overflow-y:auto;background:var(--c-bg0);border:1px solid var(--c-border);border-radius:var(--r-sm);padding:8px"></div>
  </div>
  <button class="onl-btn onl-btn-primary onl-btn-full" id="onl-generate-bulk">
    <span id="onl-bulk-text">⚡ Generate Posts</span>
    <span id="onl-bulk-loading" style="display:none"><span class="onl-spinner"></span> Generating…</span>
  </button>
  <div id="onl-export-preview-section" style="display:none;margin-top:16px" class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Preview</span><span class="onl-char-count" id="onl-export-count"></span></div>
    <div class="onl-export-preview" id="onl-export-preview"></div>
    <div class="onl-btn-row" style="margin-top:12px">
      <button class="onl-btn onl-btn-primary" id="onl-download-csv">⬇ Download CSV</button>
      <button class="onl-btn onl-btn-secondary" id="onl-copy-sheets">📋 Google Sheets</button>
      <button class="onl-btn onl-btn-accent" id="onl-publish-ghl">🚀 Publish to GHL<span id="onl-ghl-btn-loading" style="display:none"> <span class="onl-spinner"></span></span></button>
    </div>
    <div id="onl-ghl-publish-status" style="margin-top:10px"></div>
  </div>
</div>`;
  },

  renderProducts() { return `
<div class="onl-tab-content" id="onl-tab-products">
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">📦 Products & Services</span><button class="onl-btn-text" id="onl-add-product">+ Add New</button></div>
    <p class="onl-hint">Toggle to include in AI responses.</p>
    <div id="onl-products-list"></div>
  </div>
  <div id="onl-add-product-form" style="display:none" class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Add Product</span></div>
    <div style="display:flex;flex-direction:column;gap:6px">
      <input class="onl-input" id="onl-new-product-name" placeholder="Product Name"/>
      <input class="onl-input" id="onl-new-product-desc" placeholder="Brief description"/>
    </div>
    <div class="onl-btn-row">
      <button class="onl-btn onl-btn-primary" id="onl-save-new-product">Save</button>
      <button class="onl-btn onl-btn-secondary" id="onl-cancel-product">Cancel</button>
    </div>
  </div>
</div>`; },

  renderFollowups() { return `
<div class="onl-tab-content" id="onl-tab-followups">
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Quick Follow-ups</span></div>
    <p class="onl-hint">Click to preview, double-click to copy to clipboard.</p>
    <div class="onl-followup-list">
      <button class="onl-followup-btn" data-followup="agree">👍 Agree</button>
      <button class="onl-followup-btn" data-followup="askHow">🤔 How to fix it</button>
      <button class="onl-followup-btn" data-followup="pushback">⚡ Pushback</button>
      <button class="onl-followup-btn" data-followup="wantLink">🔗 Want the link?</button>
    </div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Preview</span><button class="onl-btn-text" id="onl-copy-followup">📋 Copy</button></div>
    <div class="onl-followup-preview" id="onl-followup-preview"><span class="onl-placeholder">Select a follow-up above</span></div>
  </div>
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">📤 DM Template</span><button class="onl-btn-text" id="onl-copy-dm">📋 Copy DM</button></div>
    <div class="onl-followup-preview" id="onl-dm-preview" style="font-size:11px"></div>
  </div>
</div>`; },

  renderHistory() { return `
<div class="onl-tab-content" id="onl-tab-history">
  <div class="onl-section">
    <div class="onl-label-row"><span class="onl-label">Response History</span><button class="onl-btn-text onl-btn-danger" id="onl-clear-history">Clear All</button></div>
    <div class="onl-history-list" id="onl-history-list"><p class="onl-placeholder">No history yet</p></div>
  </div>
</div>`; },

  // ── EVENT LISTENERS ───────────────────────────────────────────────────────
  attachEventListeners() {
    const $ = (id) => this._shadow.getElementById(id);
    const $$ = (sel) => this._shadow.querySelectorAll(sel);

    // Header controls
    $('onl-drag-handle').addEventListener('mousedown', (e) => this.startDrag(e));
    document.addEventListener('mousemove', (e) => this.drag(e));
    document.addEventListener('mouseup', () => this.endDrag());
    $('onl-minimize').addEventListener('click', () => this.toggleMinimize());
    $('onl-settings').addEventListener('click', () => this.openSettings());
    $('onl-close').addEventListener('click', () => this.close());

    // Mini actions
    $$('.onl-mini-btn').forEach(b => b.addEventListener('click', () => this.handleMini(b.dataset.action)));

    // Tabs
    $$('.onl-tab').forEach(t => t.addEventListener('click', () => this.switchTab(t.dataset.tab)));

    // ── RESPOND
    $('onl-snip').addEventListener('click', () => this.startSnip());
    $('onl-paste').addEventListener('click', () => this.pasteContent());
    $('onl-clear').addEventListener('click', () => this.clearContent());
    $('onl-generate').addEventListener('click', () => this.generate());
    $('onl-copy').addEventListener('click', () => this.copyResponse());
    $('onl-save').addEventListener('click', () => this.saveToHistory());
    $('onl-response').addEventListener('input', (e) => this.updateCharCount(e.target.value, 'onl-char-count'));
    $$('.onl-type-btn').forEach(b => b.addEventListener('click', () => this.selectType(b.dataset.type)));

    // ── CREATE
    $('onl-refresh-trends').addEventListener('click', () => this.loadTrends());
    $('onl-generate-post').addEventListener('click', () => this.generatePost());
    $('onl-copy-post').addEventListener('click', () => this.copyPost());
    $('onl-post-linkedin').addEventListener('click', () => this.postToLinkedIn());
    $('onl-generated-post').addEventListener('input', (e) => this.updateCharCount(e.target.value, 'onl-post-char-count'));

    // ── IMAGES
    $('onl-generate-image').addEventListener('click', () => this.generateImage());
    $('onl-generate-variations').addEventListener('click', () => this.generateImageVariations());
    $('onl-download-image').addEventListener('click', () => this.downloadImage());
    $('onl-copy-image').addEventListener('click', () => this.copyImage());
    $('onl-refresh-saved').addEventListener('click', () => this.loadSavedImages());
    $$('.onl-style-btn').forEach(b => b.addEventListener('click', () => this.generateBrandStyle(b.dataset.style)));

    // ── HASHTAGS
    $('onl-copy-hashtags').addEventListener('click', () => this.copySelectedHashtags());
    $('onl-clear-hashtags').addEventListener('click', () => this.clearSelectedHashtags());
    $('onl-ai-suggest').addEventListener('click', () => this.aiSuggestHashtags());
    $('onl-add-hashtag').addEventListener('click', () => this.addCustomHashtag());

    // ── PREDICTIONS
    $('onl-refresh-predictions').addEventListener('click', () => this.loadPredictions());
    $('onl-search-predictions').addEventListener('click', () => this.searchPredictions());
    $('onl-prediction-search').addEventListener('keypress', (e) => { if (e.key === 'Enter') this.searchPredictions(); });
    $$('.onl-pred-filter').forEach(b => b.addEventListener('click', () => this.filterPredictions(b.dataset.filter)));
    $('onl-copy-prediction').addEventListener('click', () => this.copySelectedPrediction());
    $('onl-add-to-post').addEventListener('click', () => this.addPredictionToPost());
    $('onl-save-as-stat').addEventListener('click', () => this.savePredictionAsStat());

    // ── RESEARCH
    $('onl-add-stat').addEventListener('click', () => $('onl-add-stat-form').style.display = 'block');
    $('onl-cancel-stat').addEventListener('click', () => $('onl-add-stat-form').style.display = 'none');
    $('onl-save-new-stat').addEventListener('click', () => this.saveNewStat());
    $('onl-discover-facts').addEventListener('click', () => this.discoverFacts());

    // ── EXPORT
    $('onl-generate-bulk').addEventListener('click', () => this.generateBulkPosts());
    $('onl-download-csv').addEventListener('click', () => this.downloadGHLCSV());
    $('onl-copy-sheets').addEventListener('click', () => this.copyForSheets());
    $('onl-publish-ghl').addEventListener('click', () => this.publishToGHL());
    $('onl-select-all-facts').addEventListener('click', () => this.selectAllExportFacts(true));
    $('onl-deselect-all-facts').addEventListener('click', () => this.selectAllExportFacts(false));

    // ── PRODUCTS
    $('onl-add-product').addEventListener('click', () => $('onl-add-product-form').style.display = 'block');
    $('onl-cancel-product').addEventListener('click', () => $('onl-add-product-form').style.display = 'none');
    $('onl-save-new-product').addEventListener('click', () => this.saveNewProduct());

    // ── FOLLOWUPS
    $$('.onl-followup-btn').forEach(b => b.addEventListener('click', () => this.handleFollowup(b.dataset.followup)));
    $('onl-copy-followup').addEventListener('click', () => this.copyFollowup());
    $('onl-copy-dm').addEventListener('click', () => this.copyDM());

    // ── HISTORY
    $('onl-clear-history').addEventListener('click', () => this.clearHistory());

    // ── DASHBOARD
    $('onl-refresh-dashboard').addEventListener('click', () => this.loadDashboard());
    $('onl-review-facts').addEventListener('click', () => this.switchTab('research'));
    $('onl-review-posts').addEventListener('click', () => $('onl-tab-dashboard').querySelector('#onl-recent-posts')?.scrollIntoView());
    $('onl-toggle-autodiscovery').addEventListener('click', (e) => this.toggleAutoToggle(e.target, 'autoDiscovery'));
    $('onl-toggle-autopublish').addEventListener('click', (e) => this.toggleAutoToggle(e.target, 'autoPublish'));
    $('onl-run-discovery').addEventListener('click', () => { this.switchTab('research'); this.discoverFacts(); });
    $('onl-generate-week').addEventListener('click', () => this.generateWeekPosts());

    // Load DM template on followup tab
    this.loadDMTemplate();
  },

  // ── CORE ACTIONS ──────────────────────────────────────────────────────────
  open() { this._modal.style.display = 'flex'; this.isOpen = true; },
  close() { this._modal.style.display = 'none'; this.isOpen = false; },
  toggle() { this.isOpen ? this.close() : this.open(); },

  toggleMinimize() {
    this.isMinimized = !this.isMinimized;
    this._modal.classList.toggle('minimized', this.isMinimized);
    this._shadow.getElementById('onl-minimize').textContent = this.isMinimized ? '□' : '─';
  },

  openSettings() { chrome.runtime.sendMessage({ action: 'openSettings' }); },

  switchTab(tab) {
    this.currentTab = tab;
    this._shadow.querySelectorAll('.onl-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
    this._shadow.querySelectorAll('.onl-tab-content').forEach(c => c.classList.toggle('active', c.id === `onl-tab-${tab}`));
  },

  handleMini(action) {
    switch (action) {
      case 'snip': this.isMinimized && this.toggleMinimize(); this.startSnip(); break;
      case 'respond': this.isMinimized && this.toggleMinimize(); this.switchTab('respond'); break;
      case 'create': this.isMinimized && this.toggleMinimize(); this.switchTab('create'); break;
      case 'hashtags': this.isMinimized && this.toggleMinimize(); this.switchTab('hashtags'); break;
      case 'expand': this.toggleMinimize(); break;
    }
  },

  showStatus(msg, type = 'info', duration = 3000) {
    const el = this._shadow.getElementById('onl-status');
    if (!el) return;
    el.textContent = msg;
    el.className = `onl-status ${type}`;
    if (duration > 0) setTimeout(() => { el.textContent = ''; el.className = 'onl-status'; }, duration);
  },

  updateCharCount(val, id) {
    const el = this._shadow.getElementById(id);
    if (!el) return;
    const len = val.length;
    el.textContent = `${len} / 3000`;
    el.className = `onl-char-count${len > 2700 ? ' warn' : ''}${len > 3000 ? ' over' : ''}`;
  },

  // ── DRAG ──────────────────────────────────────────────────────────────────
  startDrag(e) {
    this.isDragging = true;
    this._modal.classList.add('dragging');
    const rect = this._modal.getBoundingClientRect();
    this.dragOffset = { x: e.clientX - rect.left, y: e.clientY - rect.top };
  },
  drag(e) {
    if (!this.isDragging) return;
    const x = e.clientX - this.dragOffset.x;
    const y = e.clientY - this.dragOffset.y;
    this._modal.style.left = `${Math.max(0, Math.min(window.innerWidth - 460, x))}px`;
    this._modal.style.top = `${Math.max(0, Math.min(window.innerHeight - 100, y))}px`;
  },
  endDrag() {
    if (!this.isDragging) return;
    this.isDragging = false;
    this._modal.classList.remove('dragging');
    const rect = this._modal.getBoundingClientRect();
    RocketStorage.set({ 'ui.modalPosition': { x: rect.left, y: rect.top } });
  },
  loadPosition(pos) {
    if (pos) { this._modal.style.left = `${pos.x}px`; this._modal.style.top = `${pos.y}px`; }
  },

  // ── RESPOND ───────────────────────────────────────────────────────────────
  startSnip() {
    this.close();
    setTimeout(() => {
      if (typeof RocketSnipper !== 'undefined') {
        RocketSnipper.start((text) => {
          if (text) { this.open(); this.setPostContent(text); this.showStatus('✅ Content captured!', 'success'); }
          else { this.open(); this.showStatus('No text captured', 'error'); }
        });
      } else { this.open(); this.showStatus('Snipper loading…', 'warn'); }
    }, 100);
  },
  async pasteContent() {
    try {
      const text = await navigator.clipboard.readText();
      if (text) this.setPostContent(text);
    } catch { this.showStatus('Clipboard access denied', 'error'); }
  },
  setPostContent(text) {
    this.postContent = text;
    const el = this._shadow.getElementById('onl-post-preview');
    el.textContent = text;
    el.classList.remove('onl-placeholder');
    if (typeof RocketAPI !== 'undefined') {
      const analysis = RocketAPI.analyzePost(text);
      this.selectType(analysis.recommended);
    }
  },
  clearContent() {
    this.postContent = '';
    const el = this._shadow.getElementById('onl-post-preview');
    el.innerHTML = '<span class="onl-placeholder">Click "Snip Post" to capture a post, or paste</span>';
  },
  selectType(type) {
    this.currentType = type;
    this._shadow.querySelectorAll('.onl-type-btn').forEach(b => b.classList.toggle('active', b.dataset.type === type));
  },
  async generate() {
    const settings = await RocketStorage.getAll();
    if (!settings.anthropicApiKey && !settings.webhookUrl) {
      this.showStatus('⚠ API key required — configure in Settings', 'error'); return;
    }
    if (!this.postContent) {
      this.showStatus('⚠ Snip or paste a post first', 'warn'); return;
    }
    const text = this._shadow.getElementById('onl-gen-text');
    const load = this._shadow.getElementById('onl-gen-loading');
    const btn = this._shadow.getElementById('onl-generate');
    btn.disabled = true; text.style.display = 'none'; load.style.display = 'inline-flex';
    try {
      const result = await RocketAPI.generateResponse(this.postContent, { type: this.currentType || 'auto' });
      this.generatedResponse = result.content;
      this._shadow.getElementById('onl-response').value = result.content;
      this.updateCharCount(result.content, 'onl-char-count');
      await RocketStorage.trackAnalytics(this.currentType || 'auto', 'generated');
      this.showStatus('✅ Response generated!', 'success');
    } catch (e) { this.showStatus(e.message, 'error'); }
    btn.disabled = false; text.style.display = ''; load.style.display = 'none';
  },
  async copyResponse() {
    const val = this._shadow.getElementById('onl-response').value;
    if (!val) { this.showStatus('Nothing to copy', 'warn'); return; }
    await this.copyText(val);
    await RocketStorage.trackAnalytics(this.currentType || 'auto', 'copied');
    this.showStatus('📋 Copied!', 'success');
  },
  async saveToHistory() {
    const val = this._shadow.getElementById('onl-response').value;
    if (!val) return;
    await RocketStorage.addHistory({ type: this.currentType || 'respond', text: val, postContent: this.postContent });
    this.loadHistory();
    this.showStatus('💾 Saved to history', 'success');
  },

  // ── CREATE ────────────────────────────────────────────────────────────────
  async loadTrends() {
    const list = this._shadow.getElementById('onl-trends-list');
    list.innerHTML = '<p class="onl-placeholder onl-pulse">Loading…</p>';
    this.trends = typeof RocketLunarCrush !== 'undefined'
      ? await RocketLunarCrush.getTrendingTopics(8) : [];
    if (!this.trends.length) { list.innerHTML = '<p class="onl-placeholder">No trends — add LunarCrush key in Settings</p>'; return; }
    list.innerHTML = this.trends.map(t => `
      <div class="onl-trend-card" data-topic="${t.name}" data-score="${t.score}" data-mentions="${t.mentions||0}" data-sentiment="${t.sentiment||0}" data-change="${t.change24h||0}">
        <div class="onl-trend-header"><span class="onl-trend-topic">${t.name}</span><span class="onl-trend-score">${t.score}/100</span></div>
        <div class="onl-trend-metrics"><span>📣 ${((t.mentions||0)/1000).toFixed(1)}K</span><span>💬 ${t.sentiment||0}%</span><span>${(t.change24h||0)>0?'📈':'📉'} ${(t.change24h||0)>0?'+':''}${(t.change24h||0).toFixed(1)}%</span></div>
      </div>`).join('');
    list.querySelectorAll('.onl-trend-card').forEach(card => {
      card.addEventListener('click', () => {
        list.querySelectorAll('.onl-trend-card').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        this._shadow.getElementById('onl-custom-topic').value = card.dataset.topic;
        this.selectedTrend = { name: card.dataset.topic, score: +card.dataset.score, mentions: +card.dataset.mentions, sentiment: +card.dataset.sentiment, change24h: +card.dataset.change };
      });
    });
  },
  async generatePost() {
    const settings = await RocketStorage.getAll();
    if (!settings.anthropicApiKey) { this.showStatus('⚠ API key required', 'error'); return; }
    const topic = this._shadow.getElementById('onl-custom-topic').value.trim();
    if (!topic) { this.showStatus('⚠ Enter a topic', 'warn'); return; }
    const text = this._shadow.getElementById('onl-genpost-text');
    const load = this._shadow.getElementById('onl-genpost-loading');
    const btn = this._shadow.getElementById('onl-generate-post');
    btn.disabled = true; text.style.display = 'none'; load.style.display = 'inline-flex';
    try {
      const result = await RocketAPI.generatePost(topic, this.selectedTrend);
      this._shadow.getElementById('onl-generated-post').value = result.content;
      this.updateCharCount(result.content, 'onl-post-char-count');
      await RocketStorage.trackAnalytics('create', 'generated');
      this.showStatus('✅ Post generated!', 'success');
    } catch (e) { this.showStatus(e.message, 'error'); }
    btn.disabled = false; text.style.display = ''; load.style.display = 'none';
  },
  async copyPost() {
    const val = this._shadow.getElementById('onl-generated-post').value;
    if (!val) { this.showStatus('Nothing to copy', 'warn'); return; }
    await this.copyText(val);
    this.showStatus('📋 Copied!', 'success');
  },
  async postToLinkedIn() {
    const val = this._shadow.getElementById('onl-generated-post').value;
    if (!val) { this.showStatus('Generate a post first', 'warn'); return; }
    if (typeof RocketLinkedIn !== 'undefined') {
      const result = await RocketLinkedIn.injectPostText(val);
      if (result.success) { this.showStatus('✅ Injected into LinkedIn!', 'success'); await RocketStorage.trackAnalytics('create', 'posted'); }
      else { this.showStatus(result.error || 'Injection failed', 'error'); }
    } else { this.showStatus('LinkedIn module loading…', 'warn'); }
  },

  // ── IMAGE GEN ─────────────────────────────────────────────────────────────
  async generateImage() {
    const settings = await RocketStorage.getAll();
    if (!settings.geminiApiKey) { this.showStatus('⚠ Gemini API key required', 'error'); return; }
    const prompt = this._shadow.getElementById('onl-image-prompt').value.trim();
    if (!prompt) { this.showStatus('Enter a prompt', 'warn'); return; }
    const btn = this._shadow.getElementById('onl-generate-image');
    btn.disabled = true; btn.textContent = '⏳ Generating…';
    const statusEl = this._shadow.getElementById('onl-imagegen-status');
    statusEl.textContent = 'Generating image…'; statusEl.className = 'onl-status info';
    try {
      const opts = { model: this._shadow.getElementById('onl-image-model').value, aspect: this._shadow.getElementById('onl-image-aspect').value, size: this._shadow.getElementById('onl-image-size').value, enhancer: this._shadow.getElementById('onl-image-enhancer').value };
      const result = await RocketImageGen.generateImage(prompt, opts, settings.geminiApiKey);
      if (result.success) {
        this._shadow.getElementById('onl-generated-image').src = result.imageUrl;
        this._shadow.getElementById('onl-image-preview-section').style.display = 'block';
        statusEl.textContent = '✅ Image generated!'; statusEl.className = 'onl-status success';
        await RocketImageGen.saveImage(result);
      } else throw new Error(result.error);
    } catch (e) { statusEl.textContent = e.message; statusEl.className = 'onl-status error'; }
    btn.disabled = false; btn.textContent = '🖼 Generate';
  },
  async generateImageVariations() {
    const prompt = this._shadow.getElementById('onl-image-prompt').value.trim();
    if (!prompt) { this.showStatus('Enter a prompt first', 'warn'); return; }
    this.showStatus('Generating 3 variations…', 'info');
    const settings = await RocketStorage.getAll();
    if (!settings.geminiApiKey) { this.showStatus('⚠ Gemini key required', 'error'); return; }
    try {
      const results = await Promise.all([1,2,3].map(() => RocketImageGen.generateImage(prompt, {}, settings.geminiApiKey)));
      const grid = this._shadow.getElementById('onl-variations-grid');
      this._shadow.getElementById('onl-variations-section').style.display = 'block';
      grid.innerHTML = results.filter(r => r.success).map(r => `<div class="onl-variation-item"><img src="${r.imageUrl}" /></div>`).join('');
      this.showStatus('✅ Variations ready!', 'success');
    } catch (e) { this.showStatus(e.message, 'error'); }
  },
  downloadImage() {
    const img = this._shadow.getElementById('onl-generated-image');
    if (!img.src) return;
    const a = document.createElement('a'); a.href = img.src; a.download = `0nlink-image-${Date.now()}.png`; a.click();
  },
  async copyImage() {
    const img = this._shadow.getElementById('onl-generated-image');
    if (!img.src) return;
    try {
      const resp = await fetch(img.src);
      const blob = await resp.blob();
      await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]);
      this.showStatus('📋 Image copied!', 'success');
    } catch { this.showStatus('Copy failed', 'error'); }
  },
  loadSavedImages() {
    const container = this._shadow.getElementById('onl-saved-images');
    RocketStorage.getAll().then(s => {
      const images = s.savedImages || [];
      if (!images.length) { container.innerHTML = '<p class="onl-placeholder">No saved images</p>'; return; }
      container.innerHTML = images.slice(-12).reverse().map(img => `
        <div class="onl-saved-img-thumb"><img src="${img.url}" title="${img.prompt?.substring(0,60)}…" /></div>`).join('');
      container.querySelectorAll('.onl-saved-img-thumb').forEach((el, i) => {
        el.addEventListener('click', () => {
          this._shadow.getElementById('onl-generated-image').src = images[i].url;
          this._shadow.getElementById('onl-image-preview-section').style.display = 'block';
        });
      });
    });
  },
  generateBrandStyle(style) {
    const prompts = {
      elevated: 'A powerful conceptual image: an advanced AI company 5 years ahead of competition, standing on an elevated platform with clean MCP workflows, while below a chaotic crowd struggles with broken AI tools. Photo-realistic, no text, cinematic lighting.',
      builder: 'A split image: left side shows a person actively building and shipping software at a terminal with green code glowing, right side shows a person talking on stage. The builder side is lit in bright green, the talker side is dim. Photo-realistic, high contrast.',
      automation: 'An artistic visualization of smooth AI workflow automation: clean data pipelines flowing like water through minimal architecture, versus chaotic tangled manual processes. Green energy flows, dark background, no text. Conceptual art style.',
      results: 'A powerful data visualization: 88% of businesses adopt AI (large glowing number), but only 39% see real impact (smaller number). The 49-point gap visualized as a chasm. Dark background, green/red contrast, minimal, no text.'
    };
    this._shadow.getElementById('onl-image-prompt').value = prompts[style] || '';
    this._shadow.querySelectorAll('.onl-style-btn').forEach(b => b.classList.toggle('active', b.dataset.style === style));
    this.showStatus(`Style loaded: ${style}`, 'info');
  },

  // ── HASHTAGS ──────────────────────────────────────────────────────────────
  async loadHashtagClusters() {
    const container = this._shadow.getElementById('onl-hashtag-clusters');
    const clusters = typeof RocketHashtags !== 'undefined' ? await RocketHashtags.getAllClusters() : [];
    container.innerHTML = clusters.map(c => `
      <div class="onl-card" style="margin-bottom:8px">
        <div class="onl-cluster-header"><span class="onl-cluster-name" data-cluster="${c.id}">${c.name}</span><span class="onl-cluster-count">${c.tags.length}</span></div>
        <div class="onl-cluster-tags">${c.tags.map(t => `<span class="onl-tag" data-tag="${t}">${t}</span>`).join('')}</div>
      </div>`).join('');
    container.querySelectorAll('.onl-cluster-name').forEach(name => {
      name.addEventListener('click', () => {
        const tags = [...name.closest('.onl-card').querySelectorAll('.onl-tag')].map(t => t.dataset.tag);
        this.addHashtags(tags);
      });
    });
    container.querySelectorAll('.onl-tag').forEach(tag => {
      tag.addEventListener('click', (e) => { e.stopPropagation(); this.addHashtags([tag.dataset.tag]); tag.classList.toggle('selected'); });
    });
    this.updateSelectedHashtagsDisplay();
  },
  async addHashtags(tags) {
    const current = await RocketStorage.getSelectedHashtags();
    await RocketStorage.setSelectedHashtags([...new Set([...current, ...tags])].slice(0, 10));
    this.updateSelectedHashtagsDisplay();
  },
  async updateSelectedHashtagsDisplay() {
    const selected = await RocketStorage.getSelectedHashtags();
    const list = this._shadow.getElementById('onl-selected-list');
    if (!selected.length) { list.innerHTML = '<span class="onl-placeholder">Click clusters below to add</span>'; return; }
    list.innerHTML = selected.map(t => `<span class="onl-selected-tag">${t}<span class="remove" data-tag="${t}">×</span></span>`).join('');
    list.querySelectorAll('.remove').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const current = await RocketStorage.getSelectedHashtags();
        await RocketStorage.setSelectedHashtags(current.filter(t => t !== btn.dataset.tag));
        this.updateSelectedHashtagsDisplay();
      });
    });
  },
  async copySelectedHashtags() {
    const selected = await RocketStorage.getSelectedHashtags();
    if (!selected.length) { this.showStatus('No hashtags selected', 'warn'); return; }
    await this.copyText(selected.join(' '));
    this.showStatus('📋 Hashtags copied!', 'success');
  },
  async clearSelectedHashtags() {
    await RocketStorage.setSelectedHashtags([]);
    this.updateSelectedHashtagsDisplay();
  },
  async aiSuggestHashtags() {
    const content = this._shadow.getElementById('onl-response').value || this._shadow.getElementById('onl-generated-post').value || this.postContent;
    if (!content) { this.showStatus('No content to analyze', 'warn'); return; }
    const suggested = typeof RocketHashtags !== 'undefined' ? RocketHashtags.analyzeAndSuggest(content, 5) : [];
    if (suggested.length) { await this.addHashtags(suggested); this.showStatus(`Added ${suggested.length} tags`, 'success'); }
    else { this.showStatus('No suggestions found', 'warn'); }
  },
  async addCustomHashtag() {
    const input = this._shadow.getElementById('onl-custom-hashtag');
    let tag = input.value.trim();
    if (!tag) return;
    if (!tag.startsWith('#')) tag = '#' + tag;
    await this.addHashtags([tag]);
    if (typeof RocketHashtags !== 'undefined') await RocketStorage.addCustomHashtag(tag);
    input.value = '';
    this.showStatus('Tag added', 'success');
  },

  // ── PREDICTIONS ───────────────────────────────────────────────────────────
  async loadPredictions() {
    const list = this._shadow.getElementById('onl-predictions-list');
    list.innerHTML = '<p class="onl-placeholder onl-pulse">Loading…</p>';
    try {
      let markets = typeof RocketPolymarket !== 'undefined' ? await RocketPolymarket.getTrendingMarkets(15) : [];
      markets = typeof RocketPolymarket !== 'undefined' ? RocketPolymarket.filterBusinessRelevant(markets) : [];
      this.predictions = markets;
      this.renderPredictions(markets);
    } catch { list.innerHTML = '<p class="onl-placeholder">Failed to load</p>'; }
  },
  renderPredictions(markets) {
    const list = this._shadow.getElementById('onl-predictions-list');
    if (!markets?.length) { list.innerHTML = '<p class="onl-placeholder">No predictions found</p>'; return; }
    list.innerHTML = markets.slice(0, 8).map(m => {
      const color = typeof RocketPolymarket !== 'undefined' ? RocketPolymarket.getProbabilityColor(m.probability) : '#10b981';
      return `<div class="onl-prediction-card" data-id="${m.id}">
        <div class="onl-prediction-header"><span class="onl-prediction-q">${m.question}</span><span class="onl-prediction-prob" style="background:${color}">${m.probability}%</span></div>
        <div class="onl-prediction-meta"><span>📊 ${typeof RocketPolymarket !== 'undefined' ? RocketPolymarket.formatVolume(m.volume) : m.volume}</span></div>
      </div>`;
    }).join('');
    list.querySelectorAll('.onl-prediction-card').forEach(card => {
      card.addEventListener('click', () => this.selectPrediction(card.dataset.id));
    });
  },
  selectPrediction(id) {
    const market = this.predictions.find(m => m.id === id);
    if (!market) return;
    this.selectedPrediction = market;
    this._shadow.getElementById('onl-selected-prediction').style.display = 'block';
    const detail = this._shadow.getElementById('onl-prediction-detail');
    const color = typeof RocketPolymarket !== 'undefined' ? RocketPolymarket.getProbabilityColor(market.probability) : '#10b981';
    const insight = typeof RocketPolymarket !== 'undefined' ? RocketPolymarket.generateInsight(market) : market.question;
    detail.innerHTML = `<div style="text-align:center;padding:8px"><div style="font-size:28px;font-weight:900;color:${color}">${market.probability}%</div><div style="font-size:12px;color:var(--c-text1);margin-top:4px">${market.question}</div><div style="font-size:11px;color:var(--c-text3);margin-top:8px">${insight}</div></div>`;
    this._shadow.querySelectorAll('.onl-prediction-card').forEach(c => c.classList.remove('selected'));
    this._shadow.querySelector(`.onl-prediction-card[data-id="${id}"]`)?.classList.add('selected');
  },
  async searchPredictions() {
    const q = this._shadow.getElementById('onl-prediction-search').value.trim();
    if (!q) { this.loadPredictions(); return; }
    const list = this._shadow.getElementById('onl-predictions-list');
    list.innerHTML = '<p class="onl-placeholder onl-pulse">Searching…</p>';
    if (typeof RocketPolymarket !== 'undefined') {
      const markets = await RocketPolymarket.searchMarkets(q, 10);
      this.predictions = markets; this.renderPredictions(markets);
    }
  },
  async filterPredictions(filter) {
    const keyMap = { ai: 'artificial intelligence openai gpt claude', economy: 'recession fed interest rate gdp', tech: 'apple google microsoft amazon', crypto: 'bitcoin ethereum crypto btc', business: 'ceo company ipo layoff acquisition' };
    const list = this._shadow.getElementById('onl-predictions-list');
    list.innerHTML = '<p class="onl-placeholder onl-pulse">Filtering…</p>';
    if (typeof RocketPolymarket !== 'undefined') {
      const markets = await RocketPolymarket.searchMarkets(keyMap[filter] || filter, 15);
      this.predictions = markets; this.renderPredictions(markets);
    }
  },
  async copySelectedPrediction() {
    if (!this.selectedPrediction) { this.showStatus('Select a prediction first', 'warn'); return; }
    const text = typeof RocketPolymarket !== 'undefined' ? RocketPolymarket.formatForPost(this.selectedPrediction) : this.selectedPrediction.question;
    await this.copyText(text);
    this.showStatus('📋 Copied!', 'success');
  },
  addPredictionToPost() {
    if (!this.selectedPrediction) { this.showStatus('Select a prediction first', 'warn'); return; }
    const insight = typeof RocketPolymarket !== 'undefined' ? RocketPolymarket.generateInsight(this.selectedPrediction) : this.selectedPrediction.question;
    const ta = this._shadow.getElementById('onl-generated-post');
    ta.value = ta.value ? `${ta.value}\n\n${insight}` : insight;
    this.updateCharCount(ta.value, 'onl-post-char-count');
    this.switchTab('create');
    this.showStatus('Added to post!', 'success');
  },
  async savePredictionAsStat() {
    if (!this.selectedPrediction) { this.showStatus('Select a prediction first', 'warn'); return; }
    const m = this.selectedPrediction;
    await RocketStorage.addStat({ value: `${m.probability}%`, description: `predict: ${m.question}`, source: `Polymarket (${typeof RocketPolymarket !== 'undefined' ? RocketPolymarket.formatVolume(m.volume) : m.volume} vol)` });
    this.loadStats();
    this.showStatus('💾 Saved as stat!', 'success');
  },

  // ── RESEARCH ──────────────────────────────────────────────────────────────
  async loadStats() {
    const container = this._shadow.getElementById('onl-stats-list');
    if (!container) return;
    const settings = await RocketStorage.getAll();
    const stats = settings.research.stats.filter(s => s.enabled !== false);
    if (!stats.length) { container.innerHTML = '<p class="onl-placeholder">No facts yet</p>'; return; }
    container.innerHTML = stats.map(s => {
      const conf = typeof RocketFacts !== 'undefined' ? RocketFacts.calculateConfidence(s) : { overall: 85, grade: 'B' };
      const color = conf.overall >= 90 ? '#00ff88' : conf.overall >= 80 ? '#ffbe0b' : '#ff4757';
      return `<div class="onl-stat-item" data-id="${s.id}">
        <div class="onl-stat-item-left"><span class="onl-stat-value">${s.value}</span><div class="onl-stat-info"><span class="onl-stat-desc">${s.description}</span><span class="onl-stat-source">${s.source}${s.reportDate ? ` (${s.reportDate})` : ''}</span></div></div>
        <div class="onl-stat-actions"><span style="background:${color};color:#060a06;padding:2px 6px;border-radius:4px;font-size:10px;font-weight:800">${conf.grade}</span><button class="onl-stat-action" data-action="copy" data-id="${s.id}" title="Copy">📋</button><button class="onl-stat-action" data-action="verify" data-id="${s.id}" title="Verify">🔍</button><button class="onl-stat-action" data-action="delete" data-id="${s.id}" title="Delete">🗑</button></div>
      </div>`;
    }).join('');
    container.querySelectorAll('.onl-stat-action').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const { action, id } = btn.dataset;
        const settings = await RocketStorage.getAll();
        const stat = settings.research.stats.find(s => s.id === id);
        if (action === 'copy' && stat) { await this.copyText(`${stat.value} ${stat.description} (${stat.source})`); this.showStatus('📋 Stat copied', 'success'); }
        else if (action === 'verify' && stat && typeof RocketFacts !== 'undefined') {
          this.showStatus('Verifying…', 'info');
          const settings2 = await RocketStorage.getAll();
          const r = await RocketFacts.verifyFact(stat, settings2.anthropicApiKey);
          this.showStatus(r.verified ? '✅ Verified!' : (r.notes || 'Could not verify'), r.verified ? 'success' : 'error');
        } else if (action === 'delete') { await RocketStorage.deleteStat(id); this.loadStats(); this.showStatus('Deleted', 'info'); }
      });
    });
    this.loadPendingFacts();
    this.loadExportFacts();
  },
  async loadPendingFacts() {
    const section = this._shadow.getElementById('onl-pending-section');
    const list = this._shadow.getElementById('onl-pending-list');
    const count = this._shadow.getElementById('onl-pending-count');
    if (!section) return;
    const pending = await RocketStorage.getPendingFacts();
    if (!pending.length) { section.style.display = 'none'; return; }
    section.style.display = 'block';
    count.textContent = pending.length;
    this._shadow.getElementById('pending-facts-count').textContent = pending.length;
    list.innerHTML = pending.map(f => `
      <div class="onl-stat-item" data-id="${f.id}">
        <div class="onl-stat-item-left"><span class="onl-stat-value">${f.value}</span><div class="onl-stat-info"><span class="onl-stat-desc">${f.description}</span><span class="onl-stat-source">${f.source}</span></div></div>
        <div class="onl-stat-actions"><button class="onl-btn onl-btn-success onl-btn-sm" data-action="approve" data-id="${f.id}">✅</button><button class="onl-btn onl-btn-danger onl-btn-sm" data-action="reject" data-id="${f.id}">❌</button></div>
      </div>`).join('');
    list.querySelectorAll('button[data-action]').forEach(btn => {
      btn.addEventListener('click', async () => {
        btn.dataset.action === 'approve' ? await RocketStorage.approveFact(btn.dataset.id) : await RocketStorage.rejectFact(btn.dataset.id);
        this.loadStats();
        this.showStatus(btn.dataset.action === 'approve' ? '✅ Approved!' : 'Rejected', btn.dataset.action === 'approve' ? 'success' : 'info');
      });
    });
  },
  async saveNewStat() {
    const val = this._shadow.getElementById('onl-new-stat-value').value.trim();
    const desc = this._shadow.getElementById('onl-new-stat-desc').value.trim();
    const src = this._shadow.getElementById('onl-new-stat-source').value.trim();
    if (!val || !desc) { this.showStatus('Value and description required', 'warn'); return; }
    await RocketStorage.addStat({ value: val, description: desc, source: src || 'Manual', url: this._shadow.getElementById('onl-new-stat-url').value, reportDate: this._shadow.getElementById('onl-new-stat-date').value, status: 'verified', confidenceScore: 75 });
    ['onl-new-stat-value','onl-new-stat-desc','onl-new-stat-source','onl-new-stat-url','onl-new-stat-date'].forEach(id => this._shadow.getElementById(id).value = '');
    this._shadow.getElementById('onl-add-stat-form').style.display = 'none';
    this.loadStats();
    this.showStatus('✅ Fact added!', 'success');
  },
  async discoverFacts() {
    const settings = await RocketStorage.getAll();
    if (!settings.anthropicApiKey) { this.showStatus('⚠ API key required', 'error'); return; }
    const text = this._shadow.getElementById('onl-discover-text');
    const load = this._shadow.getElementById('onl-discover-loading');
    const btn = this._shadow.getElementById('onl-discover-facts');
    const result = this._shadow.getElementById('onl-discover-result');
    btn.disabled = true; text.style.display = 'none'; load.style.display = 'inline-flex'; result.innerHTML = '';
    try {
      if (typeof RocketFacts === 'undefined') throw new Error('Facts engine not loaded');
      const category = this._shadow.getElementById('onl-discover-category').value;
      const facts = await RocketFacts.discoverFacts(category, settings.anthropicApiKey, 3);
      if (facts.error) { result.innerHTML = `<p style="color:var(--c-error)">${facts.error}</p>`; }
      else {
        for (const f of facts) await RocketStorage.addPendingFact(f);
        result.innerHTML = `<p style="color:var(--c-green)">Found ${facts.length} facts! Review them above.</p>`;
        this.loadPendingFacts();
      }
    } catch (e) { result.innerHTML = `<p style="color:var(--c-error)">${e.message}</p>`; }
    btn.disabled = false; text.style.display = ''; load.style.display = 'none';
  },

  // ── GHL EXPORT ────────────────────────────────────────────────────────────
  async loadExportFacts() {
    const container = this._shadow.getElementById('onl-export-facts-list');
    if (!container) return;
    const settings = await RocketStorage.getAll();
    const stats = settings.research.stats.filter(s => s.enabled !== false);
    this.selectedExportFacts = stats.map(s => s.id);
    container.innerHTML = stats.map(s => `
      <label style="display:flex;align-items:center;gap:8px;padding:4px;cursor:pointer;font-size:12px;color:var(--c-text1)">
        <input type="checkbox" checked data-id="${s.id}" style="accent-color:var(--c-green)"/>
        ${s.value} ${s.description}
      </label>`).join('');
    container.querySelectorAll('input[type=checkbox]').forEach(cb => {
      cb.addEventListener('change', () => {
        cb.checked ? this.selectedExportFacts.push(cb.dataset.id) : (this.selectedExportFacts = this.selectedExportFacts.filter(id => id !== cb.dataset.id));
      });
    });
  },
  selectAllExportFacts(sel) {
    this._shadow.getElementById('onl-export-facts-list').querySelectorAll('input').forEach(cb => cb.checked = sel);
    RocketStorage.getAll().then(s => { this.selectedExportFacts = sel ? s.research.stats.filter(st => st.enabled !== false).map(st => st.id) : []; });
  },
  async generateBulkPosts() {
    if (typeof RocketGHLExport === 'undefined') { this.showStatus('GHL export not loaded', 'error'); return; }
    const settings = await RocketStorage.getAll();
    const selectedStats = settings.research.stats.filter(s => this.selectedExportFacts.includes(s.id) && s.enabled !== false);
    if (!selectedStats.length) { this.showStatus('Select at least one fact', 'warn'); return; }
    const text = this._shadow.getElementById('onl-bulk-text');
    const load = this._shadow.getElementById('onl-bulk-loading');
    const btn = this._shadow.getElementById('onl-generate-bulk');
    btn.disabled = true; text.style.display = 'none'; load.style.display = 'inline-flex';
    const timeMap = { morning: ['09:00','12:00'], afternoon: ['09:00','17:00'], evening: ['12:00','18:00'], peak: ['10:00','12:00','17:00'] };
    try {
      const startDate = this._shadow.getElementById('onl-export-start-date').value;
      const postsPerDay = +this._shadow.getElementById('onl-export-posts-per-day').value;
      const totalDays = +this._shadow.getElementById('onl-export-days').value;
      const timesOption = this._shadow.getElementById('onl-export-times').value;
      const hashtagSet = this._shadow.getElementById('onl-export-hashtags').value;
      this.generatedPosts = await RocketGHLExport.generateBulkPosts(selectedStats, { startDate: new Date(startDate), postsPerDay, totalDays, preferredTimes: timeMap[timesOption], hashtagSet, includeProducts: true, products: settings.products.filter(p => p.enabled) });
      const section = this._shadow.getElementById('onl-export-preview-section');
      const preview = this._shadow.getElementById('onl-export-preview');
      const count = this._shadow.getElementById('onl-export-count');
      section.style.display = 'block';
      count.textContent = `${this.generatedPosts.length} posts`;
      const previewPosts = RocketGHLExport.previewPosts(this.generatedPosts, 5);
      preview.innerHTML = previewPosts.map(p => `<div class="onl-export-post"><div class="onl-export-post-meta"><span>#${p.number}</span><span>${p.scheduledFor}</span><span>${p.charCount} chars</span></div><div class="onl-export-post-text">${p.preview}</div></div>`).join('');
      this.showStatus(`✅ Generated ${this.generatedPosts.length} posts!`, 'success');
    } catch (e) { this.showStatus(e.message, 'error'); }
    btn.disabled = false; text.style.display = ''; load.style.display = 'none';
  },
  async downloadGHLCSV() {
    if (!this.generatedPosts.length) { this.showStatus('Generate posts first', 'warn'); return; }
    RocketGHLExport.downloadCSV(this.generatedPosts, '0nlink-ghl-posts');
    await RocketStorage.logGHLExport({ postCount: this.generatedPosts.length, format: 'csv' });
    this.showStatus(`⬇ Downloaded ${this.generatedPosts.length} posts!`, 'success');
  },
  async copyForSheets() {
    if (!this.generatedPosts.length) { this.showStatus('Generate posts first', 'warn'); return; }
    const result = await RocketGHLExport.copyForGoogleSheets(this.generatedPosts);
    result.success ? this.showStatus(`📋 Copied ${result.count} posts — paste into Sheets!`, 'success') : this.showStatus(result.error, 'error');
  },
  async publishToGHL() {
    if (!this.generatedPosts.length) { this.showStatus('Generate posts first', 'warn'); return; }
    if (typeof RocketGHLAPI === 'undefined') { this.showStatus('GHL API not loaded. Configure in Settings.', 'error'); return; }
    const ghlSettings = await RocketGHLAPI.getSettings();
    if (!ghlSettings.connected) { this.showStatus('⚠ GHL not configured — go to Settings', 'error'); return; }
    const btn = this._shadow.getElementById('onl-publish-ghl');
    const loadSpan = this._shadow.getElementById('onl-ghl-btn-loading');
    btn.disabled = true; loadSpan.style.display = 'inline';
    const statusDiv = this._shadow.getElementById('onl-ghl-publish-status');
    statusDiv.innerHTML = '<p style="color:var(--c-accent)">Publishing…</p>';
    try {
      const result = await RocketGHLAPI.scheduleBulkPosts(this.generatedPosts);
      statusDiv.innerHTML = `<div style="padding:10px;background:var(--c-green-dim);border:1px solid rgba(0,255,136,0.25);border-radius:8px"><strong style="color:var(--c-green)">✅ Published to GHL!</strong><p style="font-size:12px;margin-top:4px;color:var(--c-text2)">${result.successful}/${result.total} posts scheduled.${result.failed ? ` ${result.failed} failed.` : ''}</p></div>`;
      await RocketStorage.logGHLExport({ postCount: result.successful, format: 'api' });
    } catch (e) { statusDiv.innerHTML = `<p style="color:var(--c-error)">${e.message}</p>`; }
    btn.disabled = false; loadSpan.style.display = 'none';
  },

  // ── PRODUCTS ──────────────────────────────────────────────────────────────
  async loadProducts() {
    const container = this._shadow.getElementById('onl-products-list');
    if (!container) return;
    const settings = await RocketStorage.getAll();
    container.innerHTML = settings.products.map(p => `
      <div class="onl-product-item">
        <div><div class="onl-product-name">${p.name}</div><div class="onl-product-desc">${p.description}</div></div>
        <button class="onl-product-toggle ${p.mentionInResponses ? 'active' : ''}" data-id="${p.id}" title="Mention in responses"></button>
      </div>`).join('');
    container.querySelectorAll('.onl-product-toggle').forEach(btn => {
      btn.addEventListener('click', async () => {
        const settings = await RocketStorage.getAll();
        const product = settings.products.find(p => p.id === btn.dataset.id);
        if (product) { await RocketStorage.updateProduct(btn.dataset.id, { mentionInResponses: !product.mentionInResponses }); btn.classList.toggle('active'); }
      });
    });
  },
  async saveNewProduct() {
    const name = this._shadow.getElementById('onl-new-product-name').value.trim();
    const desc = this._shadow.getElementById('onl-new-product-desc').value.trim();
    if (!name) { this.showStatus('Name required', 'warn'); return; }
    await RocketStorage.addProduct({ name, description: desc });
    this._shadow.getElementById('onl-add-product-form').style.display = 'none';
    this._shadow.getElementById('onl-new-product-name').value = '';
    this._shadow.getElementById('onl-new-product-desc').value = '';
    this.loadProducts();
    this.showStatus('✅ Product added', 'success');
  },

  // ── FOLLOW-UPS ────────────────────────────────────────────────────────────
  currentFollowup: null,
  async handleFollowup(type) {
    const settings = await RocketStorage.getAll();
    const templates = settings.followUps || {};
    const text = templates[type] || '';
    this.currentFollowup = text;
    const preview = this._shadow.getElementById('onl-followup-preview');
    preview.textContent = text || '(not configured)';
    preview.classList.toggle('onl-placeholder', !text);
  },
  async copyFollowup() {
    if (!this.currentFollowup) { this.showStatus('Select a follow-up first', 'warn'); return; }
    await this.copyText(this.currentFollowup);
    this.showStatus('📋 Copied!', 'success');
  },
  async loadDMTemplate() {
    const settings = await RocketStorage.getAll();
    const dm = settings.followUps?.dmTemplate || '';
    const el = this._shadow.getElementById('onl-dm-preview');
    if (el) el.textContent = dm || '(configure DM template in Settings)';
  },
  async copyDM() {
    const settings = await RocketStorage.getAll();
    const dm = settings.followUps?.dmTemplate || '';
    if (!dm) { this.showStatus('No DM template', 'warn'); return; }
    await this.copyText(dm);
    this.showStatus('📋 DM template copied!', 'success');
  },

  // ── HISTORY ───────────────────────────────────────────────────────────────
  async loadHistory() {
    const container = this._shadow.getElementById('onl-history-list');
    if (!container) return;
    const settings = await RocketStorage.getAll();
    const history = (settings.history || []).slice(0, 20);
    if (!history.length) { container.innerHTML = '<p class="onl-placeholder">No history yet</p>'; return; }
    container.innerHTML = history.map(h => `
      <div class="onl-history-item">
        <div class="onl-history-meta"><span class="onl-history-type">${h.type}</span><span class="onl-history-time">${new Date(h.timestamp).toLocaleString()}</span></div>
        <div class="onl-history-text">${h.text}</div>
        <div class="onl-btn-row" style="margin-top:6px"><button class="onl-btn onl-btn-secondary onl-btn-sm" onclick="navigator.clipboard.writeText('${h.text.replace(/'/g, "\\'")}')">📋 Copy</button></div>
      </div>`).join('');
  },
  async clearHistory() {
    await RocketStorage.set({ history: [] });
    this.loadHistory();
    this.showStatus('History cleared', 'info');
  },

  // ── DASHBOARD ─────────────────────────────────────────────────────────────
  async initDashboard() { this.loadDashboard(); },
  async loadDashboard() {
    const settings = await RocketStorage.getAll();
    // Stats
    const analytics = settings.analytics || {};
    this._shadow.getElementById('stat-total').textContent = analytics.totalGenerated || 0;
    this._shadow.getElementById('stat-published').textContent = analytics.totalPosted || 0;
    this._shadow.getElementById('stat-scheduled').textContent = 0;
    this._shadow.getElementById('stat-failed').textContent = 0;
    // Auto toggles
    if (settings.research?.autoDiscoveryEnabled) this._shadow.getElementById('onl-toggle-autodiscovery').classList.add('active');
    // GHL status
    const ghlEl = this._shadow.getElementById('ghl-status-text');
    const ghlIcon = this._shadow.getElementById('ghl-status-icon');
    if (settings.ghlApiKey || settings.ghlPrivateToken) { ghlEl.textContent = 'Connected'; ghlIcon.textContent = '✅'; }
    else { ghlEl.textContent = 'Not configured'; ghlIcon.textContent = '❌'; }
    // LinkedIn status
    const liEl = this._shadow.getElementById('li-status-text');
    const liIcon = this._shadow.getElementById('li-status-icon');
    if (settings.linkedIn?.connected) { liEl.textContent = 'Connected'; liIcon.textContent = '✅'; }
    else { liEl.textContent = 'Not configured'; liIcon.textContent = '⚠️'; }
  },
  toggleAutoToggle(btn, key) {
    btn.classList.toggle('active');
    const active = btn.classList.contains('active');
    RocketStorage.getAll().then(s => { if (s.research) { s.research[key + 'Enabled'] = active; RocketStorage.set({ research: s.research }); } });
  },
  generateWeekPosts() {
    this.switchTab('export');
    this.showStatus('Configure export settings and click Generate', 'info');
  },

  // ── UTILITIES ─────────────────────────────────────────────────────────────
  async copyText(text) {
    try { await navigator.clipboard.writeText(text); }
    catch { const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
  }
};

window.OnModal = OnModal;
