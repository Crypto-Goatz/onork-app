/**
 * 0nCore Extension — Popup Controller
 */

// State
let activePlatform = 'linkedin'
let activeType = 'post'
let queue = []

// Elements
const topicInput = document.getElementById('topicInput')
const generateBtn = document.getElementById('generateBtn')
const outputArea = document.getElementById('outputArea')
const outputText = document.getElementById('outputText')
const copyBtn = document.getElementById('copyBtn')
const insertBtn = document.getElementById('insertBtn')
const queueBtn = document.getElementById('queueBtn')
const settingsBtn = document.getElementById('settingsBtn')
const settingsPanel = document.getElementById('settingsPanel')
const closeSettings = document.getElementById('closeSettings')
const saveSettings = document.getElementById('saveSettings')
const groqKeyInput = document.getElementById('groqKeyInput')
const emailInput = document.getElementById('emailInput')
const queueList = document.getElementById('queueList')
const queueCount = document.getElementById('queueCount')
const clearQueue = document.getElementById('clearQueue')

// Tab switching
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'))
    document.querySelectorAll('.tab-content').forEach(tc => tc.classList.remove('active'))
    tab.classList.add('active')
    document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active')
  })
})

// Platform chips
document.querySelectorAll('.platform-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    document.querySelectorAll('.platform-chip').forEach(c => c.classList.remove('active'))
    chip.classList.add('active')
    activePlatform = chip.dataset.platform
  })
})

// Type buttons
document.querySelectorAll('.type-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.type-btn').forEach(b => b.classList.remove('active'))
    btn.classList.add('active')
    activeType = btn.dataset.type
  })
})

// Generate
generateBtn.addEventListener('click', async () => {
  const topic = topicInput.value.trim()
  if (!topic) return

  generateBtn.disabled = true
  generateBtn.innerHTML = '<span class="loading">Generating...</span>'

  const platformGuide = {
    linkedin: 'Write for LinkedIn: professional tone, 1-3 paragraphs, use line breaks for readability, include a hook and CTA.',
    twitter: 'Write for X/Twitter: punchy, under 280 characters, use a hook. Optional: suggest a thread version.',
    reddit: 'Write for Reddit: authentic, conversational, add value. No marketing speak.',
    email: 'Write a professional email: clear subject line, concise body, strong CTA.',
    blog: 'Write a blog post intro paragraph: hook, problem, solution preview. SXO optimized.',
  }

  const typeGuide = {
    post: 'Original post with a hook that stops the scroll.',
    comment: 'Thoughtful comment that adds value and sparks conversation.',
    reply: 'Engaging reply that builds on the original point.',
    thread: 'Multi-part thread (3-5 parts) with a compelling narrative arc.',
  }

  const prompt = `${platformGuide[activePlatform] || ''}\n${typeGuide[activeType] || ''}\n\nTopic/Context:\n${topic}\n\nGenerate the ${activeType} now. Return ONLY the content — no labels, no "here's your post", no metadata.`

  chrome.runtime.sendMessage({ type: '0n-generate', prompt, maxTokens: activeType === 'thread' ? 2000 : 800 }, (response) => {
    generateBtn.disabled = false
    generateBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg> Generate'

    if (response?.content) {
      outputText.textContent = response.content
      outputArea.style.display = 'block'
    } else {
      outputText.textContent = response?.error || 'Generation failed. Check your Groq key in settings.'
      outputArea.style.display = 'block'
    }
  })
})

// Copy
copyBtn.addEventListener('click', () => {
  navigator.clipboard.writeText(outputText.textContent)
  copyBtn.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#6EE05A" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>'
  setTimeout(() => {
    copyBtn.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>'
  }, 1500)
})

// Insert into page
insertBtn.addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { type: '0n-insert-content', content: outputText.textContent })
  })
})

// Queue
queueBtn.addEventListener('click', () => {
  queue.push({
    content: outputText.textContent,
    platform: activePlatform,
    type: activeType,
    created: new Date().toISOString(),
  })
  chrome.storage.local.set({ oncore_queue: queue })
  renderQueue()
})

clearQueue.addEventListener('click', () => {
  queue = []
  chrome.storage.local.set({ oncore_queue: [] })
  renderQueue()
})

function renderQueue() {
  queueCount.textContent = `${queue.length} items`
  if (queue.length === 0) {
    queueList.innerHTML = '<div class="empty-state">No content queued.</div>'
    return
  }
  queueList.innerHTML = queue.map((item, i) => `
    <div class="queue-item">
      <span class="queue-item-text">${item.content.slice(0, 60)}...</span>
      <span class="queue-item-meta">${item.platform} · ${item.type}</span>
    </div>
  `).join('')
}

// Load queue
chrome.storage.local.get('oncore_queue', ({ oncore_queue }) => {
  queue = oncore_queue || []
  renderQueue()
})

// Settings
settingsBtn.addEventListener('click', () => { settingsPanel.style.display = 'block' })
closeSettings.addEventListener('click', () => { settingsPanel.style.display = 'none' })

// Load settings
chrome.storage.sync.get('oncore_config', ({ oncore_config }) => {
  if (oncore_config?.groqKey) groqKeyInput.value = oncore_config.groqKey
  if (oncore_config?.email) emailInput.value = oncore_config.email
})

saveSettings.addEventListener('click', () => {
  chrome.storage.sync.set({
    oncore_config: {
      groqKey: groqKeyInput.value.trim(),
      email: emailInput.value.trim(),
    }
  }, () => {
    settingsPanel.style.display = 'none'
  })
})

// Agent run buttons
document.querySelectorAll('.agent-run-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const action = btn.dataset.action
    btn.textContent = 'Running...'
    btn.disabled = true

    const endpoints = {
      blog: '/api/cron/blog',
      usecase: '/api/cron/use-cases',
      health: '/api/remote/agents',
      hipaa: '/api/hipaa/scan',
    }

    chrome.runtime.sendMessage({
      type: '0n-api-call',
      path: endpoints[action] || '/api/remote/agents',
      method: action === 'hipaa' ? 'POST' : 'GET',
      body: action === 'hipaa' ? { publicUrl: 'https://0ncore.com', dashboardUrl: 'https://0ncore.com', public: true } : undefined,
    }, (response) => {
      btn.textContent = response?.error ? 'Failed' : 'Done!'
      setTimeout(() => { btn.textContent = 'Run'; btn.disabled = false }, 2000)
    })
  })
})

// ── 0n account glue — render the carried 0n_ token + product launcher ─────────
(function on0nAccount() {
  const el = document.getElementById('onAccount')
  if (!el) return
  const PRODUCTS = [
    { name: '0nTask', url: 'https://app.0ntask.com' },
    { name: 'web0n', url: 'https://web0n.com' },
    { name: 'CRO9', url: 'https://www.cro9.com' },
    { name: 'Vault', url: 'https://www.0ncore.com/hub' },
  ]
  const mask = (t) => (t && t.length > 16) ? `${t.slice(0, 11)}…${t.slice(-4)}` : (t || '')
  const open = (url) => { try { chrome.tabs.create({ url }) } catch { window.open(url, '_blank') } }

  function render(token, connected) {
    if (!token) {
      el.innerHTML = `
        <div class="oa-label">◆ Login with 0n</div>
        <div class="oa-muted">Sign in once — the extension carries your 0n account everywhere.</div>
        <a class="oa-signin" id="oaSignin" href="#">Open your 0n vault →</a>`
      const s = el.querySelector('#oaSignin')
      if (s) s.addEventListener('click', (e) => { e.preventDefault(); open('https://www.0ncore.com/hub') })
      return
    }
    el.innerHTML = `
      <div class="oa-top">
        <div class="oa-label">◆ Your 0n account</div>
        <div class="oa-count">${connected || 0} app${connected === 1 ? '' : 's'} connected</div>
      </div>
      <div class="oa-tokenrow">
        <code class="oa-token" title="${token}">${mask(token)}</code>
        <button class="oa-btn" id="oaCopy">Copy</button>
      </div>
      <div class="oa-products">
        ${PRODUCTS.map((p, i) => `<a class="oa-prod" data-i="${i}" href="#">${p.name}</a>`).join('')}
      </div>`
    const copy = el.querySelector('#oaCopy')
    if (copy) copy.addEventListener('click', () => {
      navigator.clipboard?.writeText(token); copy.textContent = 'Copied'; setTimeout(() => (copy.textContent = 'Copy'), 1400)
    })
    el.querySelectorAll('.oa-prod').forEach((a) => a.addEventListener('click', (e) => {
      e.preventDefault(); open(PRODUCTS[Number(a.dataset.i)].url)
    }))
  }

  function load() {
    chrome.storage.local.get(['on_token', 'on_connected'], (d) => render(d.on_token || null, d.on_connected || 0))
  }
  load()
  // Live refresh if the content script captures a token while the popup is open.
  try { chrome.runtime.onMessage.addListener((m) => { if (m && m.type === 'ON_TOKEN_CAPTURED') load() }) } catch { /* */ }
})()

// ── Desk browsing: pair this Chrome with the local 0n3 desk agent ──
;(() => {
  const code = document.getElementById('dbCode'), toggle = document.getElementById('dbToggle'), status = document.getElementById('dbStatus'), detail = document.getElementById('dbDetail')
  if (!code || !toggle) return
  const paint = (r) => {
    const cfg = r?.config || {}, st = r?.status || {}
    if (cfg.code) code.value = cfg.code
    const live = cfg.enabled && st.lastSeen && Date.now() - st.lastSeen < 30_000
    status.textContent = !cfg.enabled ? 'off' : live ? `paired · ${st.ops || 0} commands` : 'waiting for the desk agent'
    status.style.color = !cfg.enabled ? '#9fb0cc' : live ? '#6EE05A' : '#f0b429'
    toggle.textContent = cfg.enabled ? 'Turn off' : 'Turn on'
    detail.textContent = cfg.enabled ? (st.lastError || (live ? 'The agent can open pages in the 0n3 session window.' : 'Start the agent on this computer: 0n3 desk run --browser')) : ''
  }
  const refresh = () => chrome.runtime.sendMessage({ type: 'DESK_BROWSE_GET' }, paint)
  toggle.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'DESK_BROWSE_GET' }, (r) => {
      const enabled = !(r?.config?.enabled)
      const c = code.value.trim().toUpperCase()
      if (enabled && c.length !== 6) { detail.textContent = 'Enter the 6-character pairing code the desk agent printed.'; return }
      chrome.runtime.sendMessage({ type: 'DESK_BROWSE_SET', payload: { enabled, code: c } }, paint)
    })
  })
  refresh(); setInterval(refresh, 3000)
})()
