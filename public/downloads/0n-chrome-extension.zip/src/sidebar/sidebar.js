// ═══ 0nCore Sidebar — v4.0 ═══
// 9 tabs: Home, LinkedIn, Compose, Snip & Reply, Console, Council, Tasks, Queue, Settings
// All AI local-first via 0nMCP desktop server (FREE)

// ── State ──
let currentProfile  = null
let selectedType    = 'auto'
let selectedStyle   = 'insight'
let activeMode      = 'comment'
let activeCompStyle = 'insight'
let queue           = []
let uip             = { count: 0 }

// ── Inline TASKS data (no ES module imports in non-module sidebar script) ──
const TASKS = {
  setup_local: { name: 'Setup Local Server', description: 'Get 0nMCP running on your desktop for free AI execution', category: 'setup', steps: [ { instruction: 'Open your terminal (Terminal on Mac, CMD/PowerShell on Windows)', type: 'action' }, { instruction: 'Install 0nMCP globally:', type: 'code', code: 'npm install -g 0nmcp' }, { instruction: 'Start the HTTP server:', type: 'code', code: '0nmcp serve --port 3000' }, { instruction: 'Keep the terminal open. Go to Settings and click "Test Connection".', type: 'action' }, { instruction: 'You should see "Connected!" — all AI is now free through your desktop.', type: 'action' } ] },
  import_credentials: { name: 'Import API Credentials', description: 'Import your .env file or API keys into 0nMCP', category: 'setup', steps: [ { instruction: 'In a new terminal, run the credential import wizard:', type: 'code', code: '0nmcp engine import' }, { instruction: 'Follow the prompts to import from .env, CSV, or JSON', type: 'action' }, { instruction: 'Verify all keys are working:', type: 'code', code: '0nmcp engine verify' }, { instruction: 'Done! All your API keys are now available to 0nMCP tools.', type: 'action' } ] },
  scrape_and_save: { name: 'Scrape & Save to CRM', description: 'Scrape a LinkedIn profile and push it directly to your CRM', category: 'linkedin', steps: [ { instruction: 'Navigate to a LinkedIn profile page', type: 'action' }, { instruction: 'Click the 0nCore icon on the toolbar to scrape the profile', type: 'action' }, { instruction: 'Click "Save Lead" to save locally + auto-sync to CRM', type: 'action' }, { instruction: 'Check your CRM — the contact should appear with LinkedIn data attached.', type: 'action' } ] },
  outreach_sequence: { name: 'LinkedIn Outreach', description: 'Generate a personalized message for a LinkedIn prospect', category: 'linkedin', steps: [ { instruction: 'Navigate to a LinkedIn profile you want to message', type: 'action' }, { instruction: 'The profile will auto-scrape. Go to the LinkedIn tab > Compose.', type: 'action' }, { instruction: 'Select a message type (Auto, Gap, Elevate, etc.)', type: 'action' }, { instruction: 'Click "Generate with 0nCore (FREE)" — AI runs on your desktop, $0 cost.', type: 'action' }, { instruction: 'Review, edit if needed, then copy and paste into LinkedIn messaging.', type: 'action' } ] },
  blog_post: { name: 'Write SXO Blog Post', description: 'Generate an SEO-optimized blog post using the SXO Writer engine', category: 'content', steps: [ { instruction: 'Go to Console tab > click "SXO Writer"', type: 'action' }, { instruction: 'This opens 0nmcp.com/console/sxo-writer in your browser', type: 'action' }, { instruction: 'Enter your topic and click Generate — runs through local 0nMCP', type: 'action' }, { instruction: 'Review the post — it follows SXO architecture (BLUF, Table Trap, Info Gain)', type: 'action' }, { instruction: 'Publish to your blog, CRM blog, and Dev.to simultaneously', type: 'action' } ] },
  multi_ai_council: { name: 'Ask the AI Council', description: 'Get answers from GPT, Gemini, Grok, and Claude simultaneously', category: 'ai', steps: [ { instruction: 'Go to the Council tab', type: 'action' }, { instruction: 'Type your question — it goes to all 4 AI providers in parallel', type: 'action' }, { instruction: 'Review individual responses + the 0n Synthesis (combined best answer)', type: 'action' }, { instruction: 'Tip: Council queries use your API keys configured in Settings', type: 'action' } ] },
  direct_tool: { name: 'Execute a Tool Directly', description: 'Call any of 1,554 0nMCP tools directly from the extension', category: 'advanced', steps: [ { instruction: 'Go to Console tab > scroll to "Direct Tool Execution"', type: 'action' }, { instruction: 'Enter a tool name (e.g. crm_contacts_search)', type: 'action' }, { instruction: 'Enter arguments as JSON (e.g. {"query": "John"})', type: 'action' }, { instruction: 'Click "Execute Tool (FREE)" — runs through local 0nMCP server', type: 'action' }, { instruction: 'Result appears below. All execution is free.', type: 'action' } ] },
}

// Simple TaskRunner
let taskRunner = { currentTask: null, stepIndex: 0 }

// ── Init ──
document.addEventListener('DOMContentLoaded', async () => {
  await checkAuth()
  setupTabs()
  setupSubTabs()
  setupAuth()
  setupHome()
  setupLinkedIn()
  setupCompose()
  setupSnipReply()
  setupConsole()
  setupCouncil()
  setupTasks()
  setupQueue()
  setupSettings()
  hideLoading()

  // Storage change listener (VPIS badge clicks, LinkedIn URL updates)
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return
    if (changes.linkedin_current_url?.newValue) {
      const el = document.getElementById('snip-url')
      if (el) el.value = changes.linkedin_current_url.newValue
    }
    if (changes.popup_trigger?.newValue) {
      switchTab('snip')
    }
  })
})

// ── Auth ──
async function checkAuth() {
  try {
    const res = await send('AUTH_CHECK')
    if (res?.authenticated) {
      showApp(res.user)
      updateServerStatus()
    } else {
      showAuthOverlay()
    }
  } catch {
    showAuthOverlay()
  }
}

function showAuthOverlay() {
  document.getElementById('auth-overlay').classList.remove('hidden')
  document.getElementById('app').classList.add('hidden')
}

function showApp(user) {
  document.getElementById('auth-overlay').classList.add('hidden')
  document.getElementById('app').classList.remove('hidden')
  if (user) {
    const name = user.full_name || user.name || (user.email ? user.email.split('@')[0] : 'there')
    const nameEl = document.getElementById('user-name')
    const emailEl = document.getElementById('settings-email')
    if (nameEl) nameEl.textContent = name
    if (emailEl) emailEl.textContent = user.email || ''
  }
  loadHomeData()
  loadQueue()
}

function setupAuth() {
  document.getElementById('login-form')?.addEventListener('submit', async (e) => {
    e.preventDefault()
    const email = document.getElementById('login-email').value
    const pass  = document.getElementById('login-pass').value
    if (!email || !pass) return
    setLoading('login-btn', true)
    hideError('login-error')
    try {
      const res = await send('AUTH_LOGIN', { email, password: pass })
      if (res?.success) showApp(res.user)
      else showError('login-error', res?.error || 'Login failed')
    } catch (err) { showError('login-error', err.message) }
    setLoading('login-btn', false)
  })

  document.getElementById('register-form')?.addEventListener('submit', async (e) => {
    e.preventDefault()
    const name  = document.getElementById('reg-name').value
    const email = document.getElementById('reg-email').value
    const pass  = document.getElementById('reg-pass').value
    if (!email || !pass) return
    setLoading('reg-btn', true)
    hideError('reg-error')
    try {
      const res = await send('AUTH_REGISTER', { name, email, password: pass })
      if (res?.success) showApp(res.user)
      else showError('reg-error', res?.error || 'Registration failed')
    } catch (err) { showError('reg-error', err.message) }
    setLoading('reg-btn', false)
  })

  document.getElementById('show-register')?.addEventListener('click', (e) => {
    e.preventDefault()
    document.getElementById('login-form').classList.add('hidden')
    document.getElementById('register-form').classList.remove('hidden')
  })

  document.getElementById('show-login')?.addEventListener('click', (e) => {
    e.preventDefault()
    document.getElementById('register-form').classList.add('hidden')
    document.getElementById('login-form').classList.remove('hidden')
  })

  const doLogout = async () => {
    await send('AUTH_LOGOUT')
    showAuthOverlay()
  }
  document.getElementById('logout-btn')?.addEventListener('click', doLogout)
  document.getElementById('logout-settings-btn')?.addEventListener('click', doLogout)
}

// ── Tab Management ──
function setupTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab))
  })
  document.querySelectorAll('.qa-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      if (btn.dataset.action === 'tab') switchTab(btn.dataset.tab)
      else if (btn.dataset.action === 'open-console') send('OPEN_CONSOLE', { tool: btn.dataset.tool })
    })
  })
}

function switchTab(tabName) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'))
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'))
  const btn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`)
  const panel = document.getElementById(`tab-${tabName}`)
  if (btn) btn.classList.add('active')
  if (panel) panel.classList.add('active')
}

function setupSubTabs() {
  document.querySelectorAll('.sub-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      const parent = btn.closest('.tab-panel')
      parent.querySelectorAll('.sub-tab').forEach(b => b.classList.remove('active'))
      parent.querySelectorAll('.sub-panel').forEach(p => p.classList.remove('active'))
      btn.classList.add('active')
      document.getElementById(`subtab-${btn.dataset.subtab}`)?.classList.add('active')
    })
  })
}

// ── Home / Dashboard ──
function setupHome() {
  // Nothing extra — data loads on showApp()
}

async function loadHomeData() {
  try {
    const res = await send('ANALYTICS_GET')
    if (res?.analytics) {
      const a = res.analytics
      document.getElementById('stat-leads').textContent     = a.leads_saved     || 0
      document.getElementById('stat-messages').textContent  = a.messages_sent   || 0
      document.getElementById('stat-tools').textContent     = a.tools_executed  || 0
      document.getElementById('stat-council').textContent   = a.council_queries || 0
    }
  } catch {}

  try {
    const res = await send('COUNCIL_HISTORY_GET')
    const list = document.getElementById('recent-council')
    if (res?.history?.length && list) {
      list.innerHTML = res.history.slice(0, 5).map(h => `
        <div class="recent-item">
          <span class="recent-text">${escHtml(h.prompt?.slice(0, 60) || '...')}</span>
          <span class="recent-meta">${timeAgo(h.ts)}</span>
        </div>
      `).join('')
    }
  } catch {}
}

async function updateServerStatus() {
  try {
    const res = await send('HEALTH_CHECK')
    const badge       = document.getElementById('server-badge')
    const statusBadge = document.getElementById('server-status-badge')
    const title       = document.getElementById('server-title')
    const body        = document.getElementById('server-body')
    const meta        = document.getElementById('server-meta')
    const card        = document.getElementById('server-card')

    if (res?.alive) {
      if (card) card.classList.remove('offline')
      if (badge) { badge.className = 'server-badge alive'; badge.textContent = 'local' }
      if (statusBadge) { statusBadge.className = 'server-badge alive'; statusBadge.textContent = 'online' }
      if (title) title.textContent = 'Desktop Server'
      if (body) body.textContent = '0nMCP is running locally — all AI execution is free.'
      if (meta) meta.innerHTML = `<span>Tools: ${res.tools || '1,554'}</span><span>Version: ${res.version || 'latest'}</span>`
    } else {
      if (card) card.classList.add('offline')
      if (badge) { badge.className = 'server-badge dead'; badge.textContent = 'offline' }
      if (statusBadge) { statusBadge.className = 'server-badge dead'; statusBadge.textContent = 'offline' }
      if (title) title.textContent = 'Server Offline'
      if (body) body.textContent = 'Start 0nMCP: run "0nmcp serve" in your terminal.'
      if (meta) meta.innerHTML = '<span>Cloud fallback active</span>'
    }
  } catch {}
}

// ── LinkedIn Tab ──
function setupLinkedIn() {
  // Profile updates from content script
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'PROFILE_CHANGED' && msg.profile) {
      currentProfile = msg.profile
      updateProfileCard(msg.profile)
    }
  })

  // Load existing profile
  send('PROFILE_GET').then(res => {
    if (res?.profile) { currentProfile = res.profile; updateProfileCard(res.profile) }
  }).catch(() => {})

  // Auto-fill snip URL
  chrome.storage.local.get(['linkedin_current_url'], (stored) => {
    if (stored.linkedin_current_url) {
      const el = document.getElementById('snip-url')
      if (el) el.value = stored.linkedin_current_url
    }
  })

  // Type buttons
  document.querySelectorAll('#type-grid .type-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#type-grid .type-btn').forEach(b => b.classList.remove('active'))
      btn.classList.add('active')
      selectedType = btn.dataset.type
      const ctxGroup = document.getElementById('post-context-group')
      if (ctxGroup) ctxGroup.style.display = selectedType === 'comment' ? 'block' : 'none'
    })
  })

  // Style buttons (post tab)
  document.querySelectorAll('#style-grid .style-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#style-grid .style-btn').forEach(b => b.classList.remove('active'))
      btn.classList.add('active')
      selectedStyle = btn.dataset.style
    })
  })

  // Rescrape
  document.getElementById('rescrape-btn')?.addEventListener('click', async () => {
    const res = await send('SCRAPE_PROFILE')
    if (res?.profile) { currentProfile = res.profile; updateProfileCard(res.profile); toast('Rescraped', 'success') }
  })

  // Save lead
  document.getElementById('save-lead-btn')?.addEventListener('click', async () => {
    if (!currentProfile) { toast('No profile to save', 'error'); return }
    const res = await send('LEAD_SAVE', { lead: currentProfile })
    if (res?.success) toast('Lead saved + synced to CRM', 'success')
    else toast('Error saving lead', 'error')
  })

  // Generate compose message
  document.getElementById('generate-btn')?.addEventListener('click', async () => {
    const btn = document.getElementById('generate-btn')
    btn.disabled = true
    btn.textContent = 'Generating (FREE)...'
    try {
      const topic = document.getElementById('compose-topic').value
      const postContent = document.getElementById('post-context')?.value
      const res = await send('AI_COMPOSE', { type: selectedType, profile: currentProfile, topic, tone: 'professional', postContent })
      if (res?.result) {
        document.getElementById('compose-output').classList.remove('hidden')
        const text = typeof res.result === 'string' ? res.result : res.result.text || JSON.stringify(res.result)
        document.getElementById('output-text').textContent = text
        document.getElementById('output-chars').textContent = `${text.length} chars`
      }
    } catch (err) { toast(err.message, 'error') }
    btn.disabled = false
    btn.textContent = 'Generate with 0nCore (FREE)'
  })

  document.getElementById('copy-output')?.addEventListener('click', () => {
    const text = document.getElementById('output-text').textContent
    navigator.clipboard.writeText(text)
    toast('Copied', 'success')
  })

  document.getElementById('regen-output')?.addEventListener('click', () => {
    document.getElementById('generate-btn').click()
  })

  // Generate post
  document.getElementById('generate-post-btn')?.addEventListener('click', async () => {
    const topic = document.getElementById('post-topic').value
    if (!topic) { toast('Enter a topic', 'error'); return }
    const btn = document.getElementById('generate-post-btn')
    btn.disabled = true
    btn.textContent = 'Generating (FREE)...'
    try {
      const res = await send('AI_POST', { style: selectedStyle, topic, tone: 'professional' })
      if (res?.result) {
        document.getElementById('post-output').classList.remove('hidden')
        const post = res.result.post || (typeof res.result === 'string' ? res.result : '')
        document.getElementById('post-text').textContent = post
        const hashtags = res.result.hashtags || []
        document.getElementById('hashtags-row').innerHTML = hashtags.map(h => `<span class="hashtag-pill">#${h}</span>`).join('')
      }
    } catch (err) { toast(err.message, 'error') }
    btn.disabled = false
    btn.textContent = 'Generate Post (FREE)'
  })

  document.getElementById('copy-post')?.addEventListener('click', () => {
    const text = document.getElementById('post-text').textContent
    navigator.clipboard.writeText(text)
    toast('Copied', 'success')
  })

  document.getElementById('regen-post')?.addEventListener('click', () => {
    document.getElementById('generate-post-btn').click()
  })

  // Leads tab
  document.getElementById('export-csv-btn')?.addEventListener('click', async () => {
    const res = await send('LEADS_GET')
    if (!res?.leads?.length) { toast('No leads', 'error'); return }
    const csv = 'Name,Title,Company,Location,LinkedIn URL,Saved\n' +
      res.leads.map(l => `"${l.name||''}","${l.title||l.headline||''}","${l.company||''}","${l.location||''}","${l.profileUrl||''}","${new Date(l.savedAt).toISOString()}"`).join('\n')
    downloadBlob(csv, `0ncore-leads-${Date.now()}.csv`, 'text/csv')
    toast('CSV exported', 'success')
  })

  document.getElementById('sync-crm-btn')?.addEventListener('click', async () => {
    const res = await send('LEADS_GET')
    if (!res?.leads?.length) { toast('No leads to sync', 'error'); return }
    toast(`Syncing ${res.leads.length} leads...`, 'success')
    for (const lead of res.leads) await send('CRM_SAVE', { profile: lead })
    toast('All leads synced to CRM', 'success')
  })

  // Leads search
  document.getElementById('leads-search')?.addEventListener('input', async (e) => {
    const q = e.target.value.toLowerCase()
    const res = await send('LEADS_GET')
    const filtered = (res?.leads || []).filter(l =>
      (l.name || '').toLowerCase().includes(q) || (l.company || '').toLowerCase().includes(q)
    )
    renderLeadsList(filtered)
  })

  // Load initial leads
  send('LEADS_GET').then(res => { if (res?.leads) renderLeadsList(res.leads) }).catch(() => {})
}

function updateProfileCard(profile) {
  const card = document.getElementById('profile-card')
  if (!profile?.name) { card?.classList.add('hidden'); return }
  card?.classList.remove('hidden')
  const nameEl    = document.getElementById('profile-name')
  const titleEl   = document.getElementById('profile-title')
  const companyEl = document.getElementById('profile-company')
  const targetEl  = document.getElementById('target-info')
  if (nameEl)    nameEl.textContent    = profile.name
  if (titleEl)   titleEl.textContent   = profile.title || profile.headline || ''
  if (companyEl) companyEl.textContent = profile.company || ''
  if (targetEl)  targetEl.innerHTML    = `<strong>${escHtml(profile.name)}</strong> — ${escHtml(profile.title || '')} ${profile.company ? `at ${escHtml(profile.company)}` : ''}`
}

function renderLeadsList(leads) {
  const list = document.getElementById('leads-list')
  if (!list) return
  if (!leads.length) { list.innerHTML = '<div class="empty-state">No leads saved yet.</div>'; return }
  list.innerHTML = leads.map(l => `
    <div class="lead-item">
      <div class="lead-name">${escHtml(l.name || 'Unknown')}</div>
      <div class="lead-meta">${escHtml(l.title || l.headline || '')} ${l.company ? `· ${escHtml(l.company)}` : ''}</div>
    </div>
  `).join('')
}

// ── Compose Tab (Voice-Trained) ──
function setupCompose() {
  // Style pills
  document.querySelectorAll('#compose-style-pills .pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('#compose-style-pills .pill').forEach(p => p.classList.remove('active'))
      pill.classList.add('active')
      activeCompStyle = pill.dataset.style
    })
  })

  // Generate button
  document.getElementById('create-generate')?.addEventListener('click', async () => {
    const topic = document.getElementById('create-topic')?.value.trim()
    if (!topic) return

    const btn = document.getElementById('create-generate')
    setLoading('create-generate', true)
    hideError('create-error')

    try {
      const res = await send('AI_POST', { style: activeCompStyle, topic, tone: 'professional' })
      if (res?.result) {
        const text = res.result.post || (typeof res.result === 'string' ? res.result : JSON.stringify(res.result))
        showDraftCard(text, topic)
        updateVoiceBadge()
      } else if (res?.error) {
        showError('create-error', res.error)
      }
    } catch (err) {
      showError('create-error', err.message || 'Generation failed')
    }
    setLoading('create-generate', false)
  })

  // Discard
  document.getElementById('create-discard')?.addEventListener('click', async () => {
    const text = document.getElementById('create-output')?.value
    if (text) await send('LOG_NO', { text })
    document.getElementById('create-draft')?.classList.add('hidden')
    if (document.getElementById('create-output')) document.getElementById('create-output').value = ''
    await reloadUIP()
  })

  // Queue
  document.getElementById('create-queue')?.addEventListener('click', async () => {
    const text    = document.getElementById('create-output')?.value || ''
    const original = document.getElementById('create-output')?.dataset.original || text
    const wasEdited = text !== original
    await send(wasEdited ? 'LOG_EDIT' : 'LOG_OK', { original, final: text, text })
    queue.push({ content: text, platform: 'linkedin', style: activeCompStyle, created: Date.now() })
    await send('QUEUE_SAVE', { queue })
    renderQueue()
    document.getElementById('create-draft')?.classList.add('hidden')
    toast('Queued', 'success')
    await reloadUIP()
  })

  // Post Now
  document.getElementById('create-post')?.addEventListener('click', async () => {
    const text     = document.getElementById('create-output')?.value || ''
    const original = document.getElementById('create-output')?.dataset.original || text
    const wasEdited = text !== original
    await send(wasEdited ? 'LOG_EDIT' : 'LOG_OK', { original, final: text, text })
    toContent({ type: 'DO_POST', text })
    document.getElementById('create-draft')?.classList.add('hidden')
    await reloadUIP()
  })

  // Load UIP
  reloadUIP()
}

function showDraftCard(text, topic) {
  const draftEl = document.getElementById('create-draft')
  const outputEl = document.getElementById('create-output')
  if (!draftEl || !outputEl) return
  outputEl.value = text
  outputEl.dataset.original = text
  draftEl.classList.remove('hidden')
}

async function reloadUIP() {
  try {
    const res = await send('VOICE_GET')
    if (res?.voice) uip = res.voice
    updateVoiceBadge()
  } catch {}
}

function updateVoiceBadge() {
  const badge = document.getElementById('create-voice-badge')
  if (!badge) return
  const count = uip.count || 0
  if (count >= 20)     badge.textContent = 'Voice dialed in'
  else if (count >= 5) badge.textContent = 'Getting warm'
  else if (count >= 1) badge.textContent = 'Learning...'
  else                 badge.textContent = 'Learning starts'
}

// ── Snip & Reply Tab ──
function setupSnipReply() {
  // Mode buttons
  document.querySelectorAll('.mode-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'))
      btn.classList.add('active')
      activeMode = btn.dataset.mode
    })
  })

  // Grab URL from current tab
  document.getElementById('snip-grab')?.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    if (!tab) return
    if (tab.url?.includes('linkedin.com')) {
      document.getElementById('snip-url').value = tab.url
    } else {
      try {
        const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => window.getSelection()?.toString() || '' })
        if (result) document.getElementById('snip-url').value = result
      } catch {}
    }
  })

  // Persona toggle
  document.getElementById('snip-persona-toggle')?.addEventListener('click', () => {
    const wrap   = document.getElementById('snip-persona-wrap')
    const toggle = document.getElementById('snip-persona-toggle')
    wrap.classList.toggle('hidden')
    toggle.textContent = wrap.classList.contains('hidden') ? 'edit' : 'hide'
  })

  // Generate
  document.getElementById('snip-generate')?.addEventListener('click', async () => {
    const input = document.getElementById('snip-url').value.trim()
    if (!input) return

    setLoading('snip-generate', true)
    document.getElementById('snip-error')?.classList.add('hidden')
    document.getElementById('snip-result')?.classList.add('hidden')

    const persona = document.getElementById('snip-persona')?.value || ''

    try {
      // Try 0ncore.com backend first (for users with social0n access)
      let handled = false
      try {
        const stored = await chrome.storage.local.get(['linkedin_post_content'])
        const postContent = stored.linkedin_post_content || ''
        if (activeMode === 'comment' && postContent) {
          const res = await send('AI_COMMENT', { postContent, authorName: '', tone: 'professional' })
          if (res?.result) {
            handleSnipResult(JSON.stringify({ author: '', hook: '', response: res.result }))
            handled = true
          }
        }
      } catch {}

      if (!handled) {
        // LinkedIn web search via background (Anthropic + web_search)
        const bgRes = await send('GENERATE_REPLY', { url: input, mode: activeMode, persona })
        if (bgRes?.success) {
          handleSnipResult(JSON.stringify(bgRes.data))
        } else {
          throw new Error(bgRes?.error || 'Generation failed')
        }
      }
    } catch (err) {
      const errEl = document.getElementById('snip-error')
      if (errEl) { errEl.textContent = err.message || 'Generation failed. Check your connection.'; errEl.classList.remove('hidden') }
    }
    setLoading('snip-generate', false)
  })

  // Copy
  document.getElementById('snip-copy')?.addEventListener('click', () => {
    const text = document.getElementById('snip-output')?.textContent || ''
    navigator.clipboard.writeText(text)
    toast('Copied', 'success')
  })

  // Insert
  document.getElementById('snip-insert')?.addEventListener('click', () => {
    const text = document.getElementById('snip-output')?.textContent || ''
    toContent({ type: '0n-insert-content', content: text })
  })
}

function handleSnipResult(raw) {
  let parsed = null
  try { const match = raw.match(/\{[\s\S]*\}/); if (match) parsed = JSON.parse(match[0]) } catch {}

  const resultEl     = document.getElementById('snip-result')
  const outputEl     = document.getElementById('snip-output')
  const authorBar    = document.getElementById('snip-author-bar')
  const resultHeader = document.getElementById('snip-result-header')

  if (parsed?.response) {
    if (outputEl) outputEl.textContent = parsed.response
    if (authorBar && parsed.author) {
      const authorEl = document.getElementById('snip-author')
      const hookEl   = document.getElementById('snip-hook')
      if (authorEl) authorEl.textContent = parsed.author
      if (hookEl)   hookEl.textContent   = parsed.hook ? ` · ${parsed.hook}` : ''
      authorBar.classList.remove('hidden')
    }
  } else {
    if (outputEl) outputEl.textContent = raw
    if (authorBar) authorBar.classList.add('hidden')
  }

  if (resultHeader) resultHeader.style.display = 'flex'
  if (resultEl) resultEl.classList.remove('hidden')

  // Alt mode buttons
  const altModes = document.getElementById('snip-alt-modes')
  if (altModes) {
    const modes = { comment: 'Comment', dm: 'DM', post: 'Post' }
    altModes.innerHTML = Object.entries(modes)
      .filter(([k]) => k !== activeMode)
      .map(([k, v]) => `<button class="btn btn-xs" data-alt="${k}">Try as ${v}</button>`)
      .join('')
    altModes.querySelectorAll('button').forEach(b => {
      b.addEventListener('click', () => {
        activeMode = b.dataset.alt
        document.querySelectorAll('.mode-btn').forEach(m => m.classList.toggle('active', m.dataset.mode === activeMode))
        document.getElementById('snip-generate').click()
      })
    })
  }
}

// ── Console Tab ──
function setupConsole() {
  document.querySelectorAll('.console-btn').forEach(btn => {
    btn.addEventListener('click', () => send('OPEN_CONSOLE', { tool: btn.dataset.console }))
  })

  document.getElementById('execute-tool-btn')?.addEventListener('click', async () => {
    const tool = document.getElementById('tool-name').value.trim()
    if (!tool) { toast('Enter a tool name', 'error'); return }

    let args = {}
    const argsText = document.getElementById('tool-args').value.trim()
    if (argsText) {
      try { args = JSON.parse(argsText) }
      catch { toast('Invalid JSON arguments', 'error'); return }
    }

    const btn = document.getElementById('execute-tool-btn')
    btn.disabled = true
    btn.textContent = 'Executing...'

    try {
      const res = await send('TOOL_EXECUTE', { tool, args })
      document.getElementById('tool-output').classList.remove('hidden')
      document.getElementById('tool-result-text').textContent =
        typeof res.result === 'string' ? res.result : JSON.stringify(res.result, null, 2)
      toast('Tool executed (FREE)', 'success')
    } catch (err) { toast(err.message, 'error') }

    btn.disabled = false
    btn.textContent = 'Execute Tool (FREE)'
  })

  document.getElementById('copy-tool-output')?.addEventListener('click', () => {
    const text = document.getElementById('tool-result-text').textContent
    navigator.clipboard.writeText(text)
    toast('Copied', 'success')
  })
}

// ── Council Tab ──
function setupCouncil() {
  const promptEl = document.getElementById('council-prompt')
  const sendBtn  = document.getElementById('council-send')
  const messages = document.getElementById('council-messages')

  async function submitCouncil() {
    const prompt = promptEl.value.trim()
    if (!prompt) return
    promptEl.value = ''
    sendBtn.disabled = true

    const empty = messages.querySelector('.empty-state')
    if (empty) empty.remove()

    messages.innerHTML += `<div class="user-msg">${escHtml(prompt)}</div>`

    const groupId  = `group-${Date.now()}`
    const providers = ['openai', 'gemini', 'grok', 'anthropic']
    const colors    = { openai: '#10a37f', gemini: '#4285f4', grok: '#ffffff', anthropic: '#cc9a80' }
    const names     = { openai: 'OpenAI', gemini: 'Gemini', grok: 'Grok', anthropic: 'Claude' }

    let groupHtml = `<div class="response-group" id="${groupId}">`
    providers.forEach((p, i) => {
      groupHtml += `
        <div class="ai-card loading" id="${groupId}-${p}">
          <div class="ai-card-header">
            <div class="ai-provider"><div class="provider-dot" style="background:${colors[p]}"></div><span class="provider-name">${names[p]}</span></div>
            <span class="duration-badge" id="${groupId}-${p}-dur">...</span>
          </div>
          <div class="ai-card-body"><span class="spinner"></span> Thinking...</div>
        </div>`
    })
    groupHtml += `</div>`
    messages.innerHTML += groupHtml
    scrollCouncil()

    const res = await send('ASK_ALL', {}, { prompt })
    if (res?.results) {
      for (const r of res.results) {
        const card = document.getElementById(`${groupId}-${r.provider}`)
        if (!card) continue
        card.classList.remove('loading')
        if (r.error) { card.classList.add('error'); card.querySelector('.ai-card-body').textContent = r.error }
        else card.querySelector('.ai-card-body').textContent = r.text || ''
        const dur = document.getElementById(`${groupId}-${r.provider}-dur`)
        if (dur) dur.textContent = r.duration ? `${(r.duration / 1000).toFixed(1)}s` : '--'
      }

      const successful = res.results.filter(r => !r.error && r.text)
      if (successful.length >= 2) {
        const synthPrompt = `Synthesize:\n\n${successful.map(r => `${names[r.provider]}: ${r.text?.slice(0, 500)}`).join('\n\n')}\n\nBest answer in 2-3 paragraphs.`
        const synthRes = await send('ASK_ONE', {}, { provider: successful[0].provider, prompt: synthPrompt })
        if (synthRes?.result?.text) {
          const group = document.getElementById(groupId)
          group.innerHTML += `
            <div class="ai-card synthesis-card">
              <div class="ai-card-header">
                <div class="ai-provider"><div class="provider-dot"></div><span class="provider-name">0n Synthesis</span></div>
              </div>
              <div class="ai-card-body">${escHtml(synthRes.result.text)}</div>
            </div>`
        }
      }
    } else if (res?.error) {
      toast(res.error, 'error')
    }

    sendBtn.disabled = false
    scrollCouncil()
  }

  function scrollCouncil() {
    const area = document.getElementById('council-chat-area')
    if (area) area.scrollTop = area.scrollHeight
  }

  sendBtn?.addEventListener('click', submitCouncil)
  promptEl?.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submitCouncil() } })
}

// ── Tasks Tab ──
function setupTasks() {
  renderTaskGrid()

  document.getElementById('task-cancel-btn')?.addEventListener('click', () => {
    taskRunner.currentTask = null
    taskRunner.stepIndex   = 0
    document.getElementById('task-list-view').classList.remove('hidden')
    document.getElementById('task-active-view').classList.add('hidden')
  })

  document.getElementById('task-prev-btn')?.addEventListener('click', () => {
    if (taskRunner.stepIndex > 0) {
      taskRunner.stepIndex--
      renderTaskStep()
    }
  })

  document.getElementById('task-next-btn')?.addEventListener('click', () => {
    if (!taskRunner.currentTask) return
    taskRunner.stepIndex++
    if (taskRunner.stepIndex >= taskRunner.currentTask.steps.length) {
      toast('Task complete!', 'success')
      taskRunner.currentTask = null
      taskRunner.stepIndex   = 0
      document.getElementById('task-list-view').classList.remove('hidden')
      document.getElementById('task-active-view').classList.add('hidden')
    } else {
      renderTaskStep()
    }
  })
}

function renderTaskGrid() {
  const grid = document.getElementById('task-grid')
  if (!grid) return
  grid.innerHTML = Object.entries(TASKS).map(([id, task]) => `
    <div class="task-card" data-task-id="${id}">
      <div class="task-card-name">${escHtml(task.name)}</div>
      <div class="task-card-desc">${escHtml(task.description)}</div>
      <div class="task-card-meta"><span class="task-badge">${escHtml(task.category)}</span><span class="task-steps">${task.steps.length} steps</span></div>
    </div>
  `).join('')

  grid.querySelectorAll('.task-card').forEach(card => {
    card.addEventListener('click', () => startTask(card.dataset.taskId))
  })
}

function startTask(taskId) {
  const task = TASKS[taskId]
  if (!task) return
  taskRunner.currentTask = { id: taskId, ...task }
  taskRunner.stepIndex   = 0
  document.getElementById('task-list-view').classList.add('hidden')
  document.getElementById('task-active-view').classList.remove('hidden')
  document.getElementById('task-active-title').textContent = task.name
  renderTaskStep()
}

function renderTaskStep() {
  const { currentTask, stepIndex } = taskRunner
  if (!currentTask) return
  const step     = currentTask.steps[stepIndex]
  const total    = currentTask.steps.length
  const pct      = Math.round(((stepIndex) / total) * 100)

  document.getElementById('task-progress-text').textContent = `Step ${stepIndex + 1} of ${total}`
  document.getElementById('task-progress-fill').style.width = `${pct}%`
  document.getElementById('task-step-instruction').textContent = step.instruction

  const codeEl = document.getElementById('task-step-code')
  if (step.code) {
    codeEl.textContent = step.code
    codeEl.classList.remove('hidden')
  } else {
    codeEl.classList.add('hidden')
  }

  const prevBtn = document.getElementById('task-prev-btn')
  const nextBtn = document.getElementById('task-next-btn')
  if (prevBtn) prevBtn.disabled = stepIndex === 0
  if (nextBtn) nextBtn.textContent = stepIndex >= total - 1 ? 'Finish' : 'Next'
}

// ── Queue Tab ──
function setupQueue() {
  renderQueue()
}

async function loadQueue() {
  try {
    const res = await send('QUEUE_GET')
    queue = res?.queue || []
  } catch {
    const stored = await chrome.storage.local.get('oc_queue')
    queue = stored.oc_queue || []
  }
  renderQueue()
}

function renderQueue() {
  const list = document.getElementById('queue-list')
  if (!list) return
  if (!queue.length) {
    list.innerHTML = '<div class="empty-state"><p>No items queued</p><span style="font-size:11px;color:var(--text-3)">Content you queue from Compose or Snip will appear here.</span></div>'
    return
  }
  list.innerHTML = queue.map((item, i) => `
    <div class="queue-item" data-index="${i}">
      <div class="queue-item-meta">
        <span class="queue-tag">${escHtml(item.platform || 'general')}</span>
        ${item.style ? `<span class="queue-tag queue-tag-muted">${escHtml(item.style)}</span>` : ''}
      </div>
      <div class="queue-item-text">${escHtml((item.content || '').slice(0, 150))}${(item.content || '').length > 150 ? '...' : ''}</div>
      <div class="queue-item-actions">
        <button class="btn btn-xs queue-copy" data-index="${i}">Copy</button>
        <button class="btn btn-xs btn-danger queue-delete" data-index="${i}">Delete</button>
      </div>
    </div>
  `).join('')

  list.querySelectorAll('.queue-copy').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.dataset.index)
      if (queue[idx]) { navigator.clipboard.writeText(queue[idx].content); toast('Copied', 'success') }
    })
  })

  list.querySelectorAll('.queue-delete').forEach(btn => {
    btn.addEventListener('click', async () => {
      const idx = parseInt(btn.dataset.index)
      queue.splice(idx, 1)
      await send('QUEUE_SAVE', { queue })
      renderQueue()
    })
  })
}

// ── Settings Tab ──
function setupSettings() {
  // Load council key status
  send('COUNCIL_CONFIG_GET').then(res => {
    if (res?.status) {
      for (const [p, info] of Object.entries(res.status)) {
        const dot = document.getElementById(`dot-${p}`)
        if (dot) dot.classList.toggle('active', info.hasKey)
      }
    }
  }).catch(() => {})

  // Load current settings
  send('SETTINGS_GET').then(res => {
    if (res?.settings) {
      const s = res.settings
      const groqEl      = document.getElementById('key-groq-direct')
      const anthropicEl = document.getElementById('key-anthropic-direct')
      const localUrlEl  = document.getElementById('local-url-input')
      const toneEl      = document.getElementById('voice-tone')
      const emojiEl     = document.getElementById('voice-emoji')
      const bannedEl    = document.getElementById('settings-banned')
      if (groqEl && s.groqKey)          groqEl.value           = s.groqKey
      if (anthropicEl && s.anthropicKey) anthropicEl.value      = s.anthropicKey
      if (localUrlEl && s.localServerPort) localUrlEl.value     = `http://localhost:${s.localServerPort}`
    }
  }).catch(() => {})

  // Load voice profile
  send('VOICE_GET').then(res => {
    if (res?.voice) {
      const tone  = document.getElementById('voice-tone')
      const emoji = document.getElementById('voice-emoji')
      if (tone && res.voice.tone)   tone.value  = res.voice.tone
      if (emoji && res.voice.emoji) emoji.value = res.voice.emoji
      if (res.voice.avoided?.length) {
        const bannedEl = document.getElementById('settings-banned')
        if (bannedEl) bannedEl.value = res.voice.avoided.join(', ')
      }
    }
  }).catch(() => {})

  // Save council keys
  document.getElementById('save-keys')?.addEventListener('click', async () => {
    const keys = {
      openai:    document.getElementById('key-openai').value.trim(),
      gemini:    document.getElementById('key-gemini').value.trim(),
      grok:      document.getElementById('key-grok').value.trim(),
      anthropic: document.getElementById('key-anthropic').value.trim(),
    }
    Object.keys(keys).forEach(k => { if (!keys[k]) delete keys[k] })
    await send('COUNCIL_CONFIG_SET', { keys })
    toast('API keys saved', 'success')
    for (const [p, key] of Object.entries(keys)) {
      const dot = document.getElementById(`dot-${p}`)
      if (dot) dot.classList.toggle('active', !!key)
    }
  })

  // Save direct AI keys
  document.getElementById('save-direct-keys')?.addEventListener('click', async () => {
    const res = await send('SETTINGS_GET')
    const settings = res?.settings || {}
    settings.groqKey      = document.getElementById('key-groq-direct').value.trim()
    settings.anthropicKey = document.getElementById('key-anthropic-direct').value.trim()
    await send('SETTINGS_SAVE', { settings })
    toast('Direct AI keys saved', 'success')
  })

  // Test connection
  document.getElementById('test-connection-btn')?.addEventListener('click', async () => {
    const url    = document.getElementById('local-url-input').value.trim()
    const result = document.getElementById('connection-result')
    result.textContent = 'Testing...'
    await send('CONFIG_SET_MODE', { mode: 'local', localUrl: url })
    const health = await send('HEALTH_CHECK')
    if (health?.alive) {
      result.textContent  = `Connected! ${health.tools || 0} tools, v${health.version || 'unknown'}`
      result.style.color  = 'var(--green)'
      updateServerStatus()
    } else {
      result.textContent = 'Server not reachable. Run: 0nmcp serve'
      result.style.color = 'var(--red)'
    }
  })

  // Save server URL
  document.getElementById('save-mode-btn')?.addEventListener('click', async () => {
    const url = document.getElementById('local-url-input').value.trim()
    await send('CONFIG_SET_MODE', { mode: 'local', localUrl: url })
    toast('Server URL saved', 'success')
  })

  // Save voice
  document.getElementById('save-voice-btn')?.addEventListener('click', async () => {
    const tone   = document.getElementById('voice-tone').value
    const emoji  = document.getElementById('voice-emoji').value
    const banned = document.getElementById('settings-banned').value
    const avoided = banned ? banned.split(',').map(s => s.trim()).filter(Boolean) : []
    const current = await send('VOICE_GET')
    const voice = { ...(current?.voice || {}), tone, emoji, avoided }
    await send('VOICE_SAVE', { voice })
    toast('Voice profile saved', 'success')
  })

  // Clear data
  document.getElementById('clear-data-btn')?.addEventListener('click', async () => {
    if (confirm('Clear all 0nCore data? This cannot be undone.')) {
      await chrome.storage.local.clear()
      showAuthOverlay()
    }
  })
}

// ── Helpers ──
function send(action, payload = {}, extra = {}) {
  return chrome.runtime.sendMessage({ action, payload, ...extra })
}

function toast(msg, type = 'info') {
  const el = document.getElementById('toast')
  if (!el) return
  el.textContent  = msg
  el.className    = `toast visible ${type}`
  clearTimeout(el._t)
  el._t = setTimeout(() => { el.className = 'toast hidden' }, 3000)
}

function hideLoading() {
  const el = document.getElementById('loading-screen')
  if (el) setTimeout(() => el.classList.add('hidden'), 500)
}

function setLoading(btnId, loading) {
  const btn = document.getElementById(btnId)
  if (!btn) return
  const text   = btn.querySelector('.btn-text')
  const loader = btn.querySelector('.btn-loader')
  btn.disabled = loading
  text?.classList.toggle('hidden', loading)
  loader?.classList.toggle('hidden', !loading)
}

function showError(id, msg) {
  const el = document.getElementById(id)
  if (el) { el.textContent = msg; el.classList.remove('hidden') }
}

function hideError(id) {
  const el = document.getElementById(id)
  if (el) el.classList.add('hidden')
}

function escHtml(str) {
  const div = document.createElement('div')
  div.textContent = str
  return div.innerHTML
}

function timeAgo(ts) {
  const diff = Date.now() - ts
  if (diff < 60000)    return 'now'
  if (diff < 3600000)  return `${Math.floor(diff / 60000)}m`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h`
  return `${Math.floor(diff / 86400000)}d`
}

async function toContent(payload) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    if (!tab?.id) return null
    return chrome.tabs.sendMessage(tab.id, payload)
  } catch { return null }
}

function downloadBlob(content, filename, mimeType) {
  const blob = new Blob([content], { type: mimeType })
  const url  = URL.createObjectURL(blob)
  const a    = document.createElement('a')
  a.href = url; a.download = filename; a.style.display = 'none'
  document.body.appendChild(a); a.click()
  document.body.removeChild(a); URL.revokeObjectURL(url)
}
