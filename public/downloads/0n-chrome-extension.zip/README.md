# 0nCore — AI Command Center (Chrome Extension)

Local-first AI command center providing LinkedIn tools, voice-trained content, multi-AI Council, and 1,554 tools via 0nMCP — all from your browser sidebar.

[![Spectra Assure Community Badge](https://secure.software/npm/badge/0nmcp)](https://secure.software/npm/packages/0nmcp)

**Version**: 4.0.0
**Manifest**: V3
**Files**: 186

## What it does

- Injects an AI command palette into LinkedIn, Twitter/X, Reddit, Dev.to, ProductHunt, GitHub, Medium, YouTube
- Sidebar UI for the multi-AI Council (Claude / GPT / Gemini / Grok)
- Voice-trained content generation
- VPIS (Velocity / Patterns / Intelligence / Signals) feed scanner
- social0n integration
- Background service worker for notifications + browser state
- 0nMCP tool access (1,554 tools)

## Permissions

`activeTab`, `storage`, `tabs`, `contextMenus`, `notifications`, `alarms`, `sidePanel`, `scripting`, `nativeMessaging`

## Powered by 0nMCP

Pairs with [0nMCP](https://www.npmjs.com/package/0nmcp) and 0nCore. Free on desktop.
